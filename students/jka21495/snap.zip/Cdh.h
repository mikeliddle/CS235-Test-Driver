#ifndef CDH_H
#define CDH_H
#include "Course.h"
class Cdh : public Course
{
public:
	Cdh();
	Cdh(string name, string dayIn, string timeIn)
		:day(dayIn), time(timeIn) {
		setCourseName(name);
	};
	~Cdh();
	string getDay();
	string getTime();
	void setDay(string day);
	void setTime(string time);
	string toString();
	friend std::ostream& operator<< (ostream& os, Cdh& myclass);
private:
	string day;
	string time;
};

#endif