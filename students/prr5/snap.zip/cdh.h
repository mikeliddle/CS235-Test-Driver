#ifndef CDH_H
#define CDH_H
#include <string>
using namespace std;

class Cdh : public Course
{
private:
	//	string course;
	string day;
	string time;
public:
	Cdh() : day(""), time("") { }
	Cdh(const string courseName,
		const string day,
		const string time)
	{
		setCourseName(courseName);
		this->day = day;
		this->time = time;
	}

	//	string getCourse() const { return this->course; }
	//	void setCourse(string course) { this->course = course; }

	string getDay() const { return this->day; }
	void setDay(string day) { this->day = day; }

	string getTime() const { return this->time; }
	void setTime(string time) { this->time = time; }

	string toString() const
	{
		stringstream out;
		out << "cdh(" << getCourseName();
		out << "," << this->day;
		out << "," << this->time << ")";
		return out.str();
	}

	friend std::ostream& operator<< (ostream& os, const Cdh& cdh)
	{
		os << cdh.toString();
		return os;
	}
};
#endif // CDH_H
