// SNAP
#include "SNAP.h"
#include "CDH.h"
#include "Course.h"
#include "CR.h"
#include "CSG.h"
#include <iostream>
#include <fstream>
#include <vector>

using namespace std;
int getObjectType(string in);
vector<string> getParameters(string in);
string getClassDays(string forClass);
string getClassroom(string forClass);
string getStudentName(string forID);
string getStudentAddress(string forID);
string getClassTime(string forClass);

vector<SNAP> snaps;
vector<CSG> csgs;
vector<CDH> cdhs;
vector<CR>  crs;

enum ObjectTypes { snap, csg, cdh, cr };

int main(int argc, char* argv[]) {
	if (argc < 3) {
		cout << "Please specify input and output files." << endl;
		return 1;
	}
	ifstream inStream(argv[1]);
	if (!inStream.is_open()) {
		cout << "File couldn't open." << endl;
		return 1;
	}
	ofstream outStream(argv[2]);
	outStream << "Input Strings:";
	for (string line; getline(inStream, line);) {
		outStream << endl << line;
		int objectType = 0;
		try {
			objectType = getObjectType(line);
		}
		catch (void* error) {
			outStream << " ** Undefined " << line;
			continue;
		}
		vector<string> args;
		switch (objectType) {
		case snap:
			args = getParameters(line);
			snaps.push_back(SNAP(args[0], args[1], args[2], args[3]));
			break;
		case csg:
			args = getParameters(line);
			csgs.push_back(CSG(args[0], args[1], args[2]));
			break;
		case cdh:
			args = getParameters(line);
			cdhs.push_back(CDH(args[0], args[1], args[2]));
			break;
		case cr:
			args = getParameters(line);
			crs.push_back(CR(args[0], args[1]));
			break;
		}
	}

	outStream << endl << endl << "Vectors:" << endl;
	for (auto x : snaps) {
		outStream << x << endl;
	}

	for (auto x : csgs) {
		outStream << x << endl;
	}

	for (auto x : cdhs) {
		outStream << x << endl;
	}

	for (auto x : crs) {
		outStream << x << endl;
	}

	outStream << endl << "Course Grades:" << endl;
	string oldCourse = "";
	for (auto x : csgs) {
		outStream << ((x.getCourseName() == oldCourse) ? "" : "\n") << x.getCourseName() << " " << getClassDays(x.getCourseName()) << ", " << getClassroom(x.getCourseName()) <<
			" " << getStudentName(x.getStudentID()) << " " << x.getStudentID() << ", " << x.getStudentGrade() << endl;
		oldCourse = x.getCourseName();
	}

	outStream << endl << "Student Schedules:" << endl;
	string oldName = "";
	for (auto x : snaps) {
		for (auto y : csgs) {
			if (x.getStudentID() == y.getStudentID()) {
				outStream << ((x.getStudentName() == oldName) ? "" : "\n") << x.getStudentName() << ", " << x.getStudentID() << ", " << x.getStudentAddress() << ", " << x.getStudentPhone() << ", " << y.getCourseName() << " " << getClassDays(y.getCourseName()) << " " <<
					getClassTime(y.getCourseName()) << ", " << getClassroom(y.getCourseName()) << endl;
				oldName = x.getStudentName();
			}
		}
	}
	cout << "File Write Complete." << endl;
	outStream.close();

}

//helper function. Pass it the entire line from the file and it will tell you what type of object to create
int getObjectType(string inputLine) {
	if ("snap(" == inputLine.substr(0, 5)) {
		return snap;
	}
	else if ("csg(" == inputLine.substr(0, 4)) {
		return csg;
	}
	else if ("cdh(" == inputLine.substr(0, 4)) {
		return cdh;
	}
	else if ("cr(" == inputLine.substr(0, 3)) {
		return cr;
	}
	else {
		throw ("Undefined symbol");
	}

}
//helper function. Pass it the entire line and it will return a vector of the comma-separated parameters
vector<string> getParameters(string in) {
	int index = 0;
	while (index <= in.size() && in[index] != '(') index++;
	vector<string> params;
	string temp = "";
	for (int x = index + 1; x < in.size(); x++) {
		if (in[x] == ',' || in[x] == ')') {
			params.push_back(temp);
			temp = "";
		}
		else {
			temp += in[x];
		}
	}

	return params;
}


//iterates through the cdh array to find what days a given class happens on
string getClassDays(string forClass) {
	string classDays;
	for (auto x : cdhs) {
		if (x.getCourseName() == forClass) {
			classDays += x.getClassDay();
		}
	}
	return classDays;
}

//iterates through the crs array to find the classroom for a given class
string getClassroom(string forClass) {
	for (auto x : crs) {
		if (x.getCourseName() == forClass) {
			return x.getClassroom();
		}
	}
}

//iterates through snaps to get a student name for a given ID
string getStudentName(string forID) {
	for (auto x : snaps) {
		if (x.getStudentID() == forID) {
			return x.getStudentName();
		}
	}
}

//iterates through snaps to get a student address for a given ID
string getStudentAddress(string forID) {
	for (auto x : snaps) {
		if (x.getStudentID() == forID) {
			return x.getStudentAddress();
		}
	}
}

//iterates through the cdh array to get the class time for a given class.
string getClassTime(string forClass) {
	for (auto x : cdhs) {
		if (x.getCourseName() == forClass) {
			return x.getClassTime();
		}
	}
}