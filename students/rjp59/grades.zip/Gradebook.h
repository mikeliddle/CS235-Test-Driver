#pragma once

#include <string>
class Gradebook
{
public:
	//Constructors
	Gradebook();
	Gradebook(std::string* students, int** scores, int numStudents, int numScores);

	//Destructor
	~Gradebook();

	//Methods
	const double calcAverage(int examNumber) const;
	const std::string getGradeBreakdownForExam(int examNumber) const;
	const std::string getGradeBreakdownForStudent(int studentNumber) const;
	const double calcClassAverage() const;
	const std::string getFinalGradeForStudent(int studentNumber) const;

	//Getters
	const int getNumStudents() const { return numStudents; }
	const int getNumScores() const { return numScores; }
	const int getNumLetterGrades() const { return NUM_LETTER_GRADES; }

private:

	//Attributes
	static const int NUM_LETTER_GRADES;
	std::string* students;
	int** scores;
	int numStudents;
	int numScores;

	//Methods
	const char letterGradeFromScore(double score, double avg) const;
	const int round(const double d) const;
	const std::string stringifyGrade(int score, char letter) const;



};

