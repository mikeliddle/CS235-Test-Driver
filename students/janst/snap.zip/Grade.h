#pragma once
#include <string>
#include <iostream>
#include <sstream>

class Grade
{
	std::string courseName;
	std::string days;
	std::string room;
	std::string studentName;
	std::string studentID;
	std::string gradeLetter;

public:
	Grade();

	Grade(std::string, std::string, std::string, std::string, std::string, std::string);

	friend std::ostream& operator<< (std::ostream& os, Grade& myclass)
	{
		os << myclass.toString();
		return os;
	}

	std::string toString();

	std::string getCourseName();

	std::string getStudentID();
};