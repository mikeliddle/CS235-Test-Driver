// Grades.cpp : Contains the functions to run the grades program.
// By Dot145

#include <iostream>
#include <string>
#include <vector>
#include <fstream>
#include <sstream>
#include <iomanip>
#include <cmath>
using namespace std;

#ifdef _MSC_VER
#define _CRTDBG_MAP_ALLOC
#include <crtdbg.h>
#define VS_MEM_CHECK _CrtSetDbgFlag(_CRTDBG_ALLOC_MEM_DF | _CRTDBG_LEAK_CHECK_DF);
#else
#define VS_MEM_CHECK
#endif

const int NUM_LETTER_GRADES = 5; //A, B, C, D, or E

//calculateGrade takes the student's score and the average score on that test and returns the letter grade (A, B, C, D, or E) associated with it.
char calculateGrade(double score, double avgScore) {
	double scoreDiff = score - avgScore;
	//if scoreDiff is between -5 and 5, inclusive, give a C.
	if (fabs(scoreDiff) <= 5) {
		return 'C';
	}
	//if scoreDiff is >5 but <15, give a B.
	else if (scoreDiff > 5 && scoreDiff < 15) {
		return 'B';
	}
	//if scoreDiff is <-5 but >-15, give a D.
	else if (scoreDiff < -5 && scoreDiff > -15) {
		return 'D';
	}
	//if scoreDiff is >=15, give an A.
	else if (scoreDiff >= 15) {
		return 'A';
	}
	//otherwise, scoreDiff is <=-15, so give an E.
	else {
		return 'E';
	}
	return '?'; //give up if nothing works :)
}

int main(int argc, char *argv[]) {
	VS_MEM_CHECK
	//check to make sure that the usage is correct
	if (argc != 3) {
		cerr << "Please provide the input file name and the output file name, in order." << endl;
		return 1;
	}

	//create streams for the input file, checking to make sure it can be opened
	ifstream inputStream(argv[1]);
	cout << "Input file: " << argv[1] << "." << endl;
	if (inputStream.fail()) {
		cerr << "Unable to open file: " << argv[1] << " for input." << endl;
		return 2;
	}

	//read the input file
	//read first line: # of students and scores. If an error is encountered, print out a message and stop.
	int numStudents;
	int numScores;
	inputStream >> numStudents >> numScores;
	if (inputStream.fail()) {
		cerr << "Error reading file." << endl;
		return 1;
	}

	//start reading the lines of students and scores
	//initialize the array of students and the 2d array of scores
	string *names = new string[numStudents];
	double **scores = new double*[numStudents];
	for (int i = 0; i < numStudents; i++) {
		scores[i] = new double[numScores];
	}

	//read lines from the file
	for (int i = 0; i < numStudents; i++) {
		//first two units are the student's name; store it in a string then have the names array at i point to that name.
		string firstName, lastName;
		inputStream >> firstName >> lastName;
		names[i] = firstName + " " + lastName;
		//get each score and put it in the scores array
		string restOfLine;
		getline(inputStream, restOfLine);
		stringstream ss;
		ss << restOfLine;
		for (int s = 0; s < numScores; s++) {
			ss >> scores[i][s];
			if (ss.fail()) {
				cerr << "Error processing file." << endl;
				return 3;
			}
		}
	}

	//calculate the average score for each exam
	double *avgScores = new double[numScores];
	for (int i = 0; i < numScores; i++) { //cycling through each test
		double avg = 0;
		for (int s = 0; s < numStudents; s++) { //get each student's score on the given test and add it to the cumulative sum
			avg += scores[s][i];
		}
		avg /= numStudents;
		avgScores[i] = avg;
	}

	//calculate each student's letter grade and store the # of occurrences for each letter
	int **letterGrades = new int*[numScores];
	for (int i = 0; i < numScores; i++) {
		letterGrades[i] = new int[NUM_LETTER_GRADES];
		for (int x = 0; x < NUM_LETTER_GRADES; x++) { //also initialize the counter for each score to 0
			letterGrades[i][x] = 0;
		}
	}

	//count the number of occurrences of each letter grade, store in 2d array
	for (int i = 0; i < numScores; i++) {
		for (int s = 0; s < numStudents; s++) {
			switch (calculateGrade(scores[s][i], avgScores[i])) {
				case 'A':
					letterGrades[i][0]++;
					break;
				case 'B':
					letterGrades[i][1]++;
					break;
				case 'C':
					letterGrades[i][2]++;
					break;
				case 'D':
					letterGrades[i][3]++;
					break;
				case 'E':
					letterGrades[i][4]++;
					break;
			}
		}
	}

	//BONUS STUFF: calculate the overall class total on all exams
	double classAverage = 0;
	for (int i = 0; i < numScores; i++) {
		classAverage += avgScores[i];
	}
	
	classAverage /= numScores;

	//BONUS 2: calculate each student's personal average
	double *personalAverages = new double[numStudents];
	for (int i = 0; i < numStudents; i++) {
		personalAverages[i] = 0; //initialize each average to 0
		for (int s = 0; s < numScores; s++) { //add up each score earned by the student
			personalAverages[i] += scores[i][s];
		}
		personalAverages[i] /= numScores; //divide by the number of scores
	}

	//start writing results to file.

	//write each student's name and their scores to the output file
	cout << "Output file: " << argv[2] << ".";
	ofstream outputStream(argv[2]);
	outputStream << "Exam Averages:" << endl;
	for (int i = 0; i < numScores; i++) {
		outputStream << "Exam " << (i+1) << " average = " << setprecision(1) << fixed << avgScores[i] << "   ";
		//output each score and the amount of occurrences
		outputStream << letterGrades[i][0] << "(A)   " << letterGrades[i][1] << "(B)   " << letterGrades[i][2] << "(C)   " << letterGrades[i][3] << "(D)   " << letterGrades[i][4] << "(E)" << endl;
	}

	//output each student's name and their scores
	outputStream << endl << "Student Exam Grades:" << endl;
	for (int i = 0; i < numStudents; i++) {
		outputStream << setw(20) << names[i] << " ";
		
		for (int s = 0; s < numScores; s++) {
			outputStream << fixed << setprecision(0) << setw(6) << scores[i][s] << "(" << calculateGrade(scores[i][s],avgScores[s]) << ")";
		}
		outputStream << endl;
	}

	//Bonus: output the average of all class exams
	outputStream << endl << "**BONUS**" << endl << "Class Average = " << setprecision(1) << classAverage << endl;

	//Bonus: output each student's average
	outputStream << "Student Final Exam Grade: " << endl;
	for (int i = 0; i < numStudents; i++) {
		outputStream << setw(20) << names[i] << setprecision(1) << setw(6) << personalAverages[i] << "("  << calculateGrade(personalAverages[i], classAverage) << ")" << endl;
	}

	//close the file output stream
	outputStream.close();

	//delete pointers to avoid memory leaks
	for (int i = 0; i < numStudents; i++) {
		delete[] scores[i];
	}
	for (int i = 0; i < numScores; i++) {
		delete[] letterGrades[i];
	}
	delete[] letterGrades;
	delete[] scores;
	delete[] names;
	delete[] avgScores;
	delete[] personalAverages;
	return 0;
}