#include "Snap.h"

Snap::Snap() {}

Snap::Snap(std::string a, std::string b, std::string c, std::string d)
{
	studentID = a;
	studentName = b;
	studentAddress = c;
	studentPhone = d;
}

std::string Snap::toString() const
{
	std::stringstream out;
	out << "snap(" << studentID << "," << studentName << "," << studentAddress << "," << studentPhone << ")";
	return out.str();
}

std::string Snap::getStudentID() {
	return studentID;
}

std::string Snap::getStudentName() {
	return studentName;
}

std::string Snap::getStudentAddress() {
	return studentAddress;
}

std::string Snap::getStudentPhone() {
	return studentPhone;
}