/*
 * Arena.h
 *
 *  Created on: Sep 1, 2016
 *      Author: mike.liddle
 */

#ifndef ARENA_H_
#define ARENA_H_

#include "Cleric.h"
#include "Robot.h"
#include "Archer.h"
#include "ArenaInterface.h"
#include "Fighter.h"
#include "sstream"

#include <iostream>
#include <string>
#include <vector>

class Arena: public ArenaInterface {
public:
	Arena();
	bool addFighter(string info);
	bool removeFighter(string name);
	FighterInterface* getFighter(string name);
	int getSize();
private:
	std::vector<Fighter*> fighters;
};

#endif /* ARENA_H_ */
