#ifndef CR_H
#define CR_H
#include "Course.h"

class Cr : public Course
{
public:
	Cr();
	Cr(string courseName, string roomNum) 
		: room(roomNum) {
		setCourseName(courseName);
	};
	string getRoom();
	void setRoom(string room);
	~Cr();
	string toString();
	friend std::ostream& operator<< (ostream& os, Cr& myclass);
private:
	string room;
};

#endif