#ifndef MYARRAY_H
#define MYARRAY_H
#include <string>
#include <sstream>
using namespace std;
template <typename T>
class MyArray
{
public:
	MyArray<T>(int max) {
		myArray = (T*)malloc(sizeof(T)*max);
		maxSize = max;
	}
	~MyArray<T>() {
		free(myArray);
	}

	class Iterator {
	public:
		void operator++() {
			if (mode == SEQ) {
				pointer++;
				index++;
			}
			else if (mode == PRIME) {
				index++;
				pointer++;
				while (!isPrime(*pointer) && index != size) {
					pointer++;
					index++;
				}
			}
			else if (mode == COMPOSITE) {
				index++;
				pointer++;
				while (isPrime(*pointer) && index != size) {
					pointer++;
					index++;
				}
			}
			else {
				index++;
				pointer++;
				int one = *(pointer - 2);
				int two = *(pointer - 1);
				while (*pointer != (one + two) && index != size) {
					one = two;
					two = *(pointer);
					pointer++;
					index++;
				}
			}
		}
		T operator*() {
			return *pointer;
		}

		bool operator != (const Iterator& i) {
			return pointer != i.pointer;
		}

		Iterator operator[](int index) {
			Iterator it = *this;
			it.pointer += index;
			return it;
		}

		Iterator(T* ptr, int inMode, int arraySize) {
			pointer = ptr;
			mode = inMode;
			size = arraySize;
			index = 0;
			if (mode == PRIME) {
				while (!isPrime(*pointer) && index != size) {
					pointer++;
					index++;
				}
			}
			else if (mode == COMPOSITE) {
				while (isPrime(*pointer) && index != size) {
					pointer++;
					index++;
				}
			}
			else if (mode == FIBONACCI) {
				int one = *pointer;
				int two = *(pointer + 1);
				pointer += 2;
				index += 2;
				while (*pointer != (one + two) && index != size) {
					one = two;
					two = *(pointer);
					pointer++;
					index++;
				}

			}
		}

		string toString() {
			stringstream output;
			output << "size=" << size << " index=" << index << " mode=" << mode << endl;
			return output.str();
		}

		friend std::ostream& operator<< (ostream& os, Iterator& it) {
			os << it.toString();
			return os;
		}
	private:
		T* pointer;
		int mode;
		int size;
		int index;
		bool isPrime(int num) {
			if (num == 2 || num == 3) {
				return true;
			}
			else if (num == 1 || num % 2 == 0) {
				return false;
			}
			else {
				for (int x = num / 2; x != 2; x--) {
					if (num % x == 0) return false;
				}
				return true;
			}
		}

	};


	void push_back(T object) {
		if (currentSize != maxSize) {
			myArray[currentSize] = object;
			currentSize++;
		}
	}

	string toString() {
		stringstream output;
		for (int x = 0; x < currentSize; x++) {
			output << myArray[x] << " ";
			if ((x + 1) % 10 == 0) output << endl;
		}
		return output.str();
	}

	friend std::ostream& operator<< (ostream& os, MyArray& arr) {
		os << arr.toString();
		return os;
	}

	Iterator begin(int mode = SEQ) {
		return Iterator(myArray, mode, currentSize);
	}

	Iterator end() {
		return Iterator(&myArray[currentSize], SEQ, currentSize);
	}

private:
	T* myArray;
	int maxSize = 0;
	int currentSize = 0;

};

#endif

