#ifndef MYARRAY_H
#define MYARRAY_H

template<typename T>
class MyArrayInterface
{
public:
	MyArrayInterface() {}
	~MyArrayInterface() {}
	virtual void push_back(T item) = 0;
	virtual string toString() const = 0;
	//class Iterator;
	//virtual Iterator begin() = 0;
};


template<typename T>
class MyArray : public MyArrayInterface<T>
{
private:
	int index_;
	int size_;
	int max_size_;
	T* array_;
public:
	MyArray() : index_(0), size_(0), max_size_(0), array_(NULL) {}
	MyArray(const int array_size)
	{
		index_ = 0;
		size_ = 0;
		max_size_ = array_size;
		array_ = (T*)malloc(array_size * sizeof(T));
	}
	~MyArray() { free(this->array_); }

	virtual void push_back(T item)
	{
		if (size_ < max_size_) array_[size_++] = item;
	};

	virtual string toString() const
	{
		stringstream out;
		out << "myArray";
		for (int i = 0; i < size_; i++)
		{
			out << ((i % 10) ? " " : "\n") << array_[i];
		}
		return out.str();
	}

	friend std::ostream& operator<< (ostream& os, const MyArray<T>& myArray)
	{
		os << myArray.toString();
		return os;
	}

	class Iterator
	{
	private:
		T* array_;
		int size_;
		int index_;
		int mode_;

		bool isPrime(int num)
		{
			int i;
			if (num < 2) return false;
			for (i = 2; i < num; i++)
			{
				if (num % i == 0) return false;
			}
			return true;
		}

		bool isFibonacci(int p)
		{
			if (p < 2) return false;
			if (array_[p + 0] == array_[p - 1] + array_[p - 2])
			{
				//cout << array_[p - 2] << "+" << array_[p - 1] << "=";
				return true;
			}
			return false;
		}

	public:
		Iterator(T* vec) :
			array_(vec), size_(MAX_ARRAY_SIZE), index_(0), mode_(0) {}
		Iterator(T* vec, int size) :
			array_(vec), size_(size), index_(0), mode_(0) {}
		Iterator(T* vec, int size, int pointer) :
			array_(vec), size_(size), index_(pointer), mode_(0) {}
		Iterator(T* vec, int size, int pointer, int mode) :
			array_(vec), size_(size), index_(pointer), mode_(mode)
		{
			switch (mode_)
			{
			default:
			case SEQUENTIAL:
				break;

			case PRIME:
				while ((index_ != size_) && !isPrime(array_[index_])) ++index_;
				break;

			case FIB:
				while ((index_ != size_) && !isFibonacci(index_)) ++index_;
				break;

			case COMPOSITE:
				while ((index_ != size_) && isPrime(array_[index_])) ++index_;
				break;
			}
		}

		bool operator!=(const Iterator& other) const
		{
			return !(*this == other);
		}

		bool operator==(const Iterator& other) const
		{
			return index_ == other.index_;
		}

		Iterator& operator+=(int i)
		{
			index_ += i;
			return *this;				// return updated iterator
		}

		Iterator& operator++()
		{
			switch (mode_)
			{
			default:
			case SEQUENTIAL:
				if (index_ != size_) ++index_;
				break;

			case PRIME:
				while ((index_ != size_) && !isPrime(array_[++index_]));
				break;

			case FIB:
				while ((index_ != size_) && !isFibonacci(++index_));
				break;

			case COMPOSITE:
				while ((index_ != size_) && isPrime(array_[++index_]));
				break;
			}
			return *this;				// return updated iterator
		}

		T& operator*() const				// dereference iterator
		{
			return array_[index_];
		}

		T& operator[](int i) const		// dereference iterator
		{
			return array_[index_ + i];
		}

		string toString() const
		{
			stringstream out;
			out << "size=" << size_;
			out << " index=" << index_;
			out << " mode=" << mode_;
			return out.str();
		}

		friend std::ostream& operator<< (ostream& os, const Iterator& iter)
		{
			os << iter.toString();
			return os;
		}
	};

	virtual Iterator begin()
	{
		return MyArray<T>::Iterator(array_, size_, 0);
	}
	Iterator begin(myMode mode)
	{
		return MyArray<T>::Iterator(array_, size_, 0, mode);
	}
	Iterator end()
	{
		return MyArray<T>::Iterator(array_, size_, size_);
	}

};
#endif // MYARRAY_H
