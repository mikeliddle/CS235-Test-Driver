#include "Cr.h"

const string DEFAULT_ROOM = "666";

Cr::Cr()
{
	Course();
	this->room = DEFAULT_ROOM;
}


string Cr::getRoom()
{
	return this->room;
}

void Cr::setRoom(string room)
{
	this->room = room;
}

Cr::~Cr()
{
}

string Cr::toString()
{
	return "cr(" + getCourseName() + "," + getRoom() + ")";
}

std::ostream & operator<<(ostream & os, Cr & myclass)
{
	os << myclass.toString();
	return os;
}
