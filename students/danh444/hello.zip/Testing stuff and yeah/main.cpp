//
//  main.cpp
//  Testing stuff and yeah
//
//  Created by Daniel Hutchings on 1/10/18.
//  Copyright © 2018 Daniel Hutchings. All rights reserved.
//

#include <iostream>

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
