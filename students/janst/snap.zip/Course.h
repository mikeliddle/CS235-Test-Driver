#pragma once
#include <iostream>
#include <fstream>
#include <string>
#include <sstream>
class Course {
protected:
	std::string courseName;

public:
	Course();

	Course(std::string);

	virtual std::string toString();

	friend std::ostream& operator<< (std::ostream& os, Course& myclass)//remove const
	{
		os << myclass.toString();
		return os;
	}

	virtual std::string getCourseName() const final;

};


