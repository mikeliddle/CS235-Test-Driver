#include "Cdh.h"

const string DEFAULT_DAY = "Sunday";
const string DEFAULT_TIME = "6:66";

Cdh::Cdh()
{
	Course::Course();
	this->day = DEFAULT_DAY;
	this->time = DEFAULT_TIME;
}



Cdh::~Cdh()
{
}

string Cdh::getDay()
{
	return this->day;;
}

string Cdh::getTime()
{
	return this->time;
}

void Cdh::setDay(string day)
{
	this->day = day;
}

void Cdh::setTime(string time)
{
	this->time = time;
}

string Cdh::toString()
{
	return "cdh(" + getCourseName() + "," + getDay() + "," + getTime() + ")";
}

std::ostream & operator<<(ostream & os, Cdh & myclass)
{
	os << myclass.toString();
	return os;
}
