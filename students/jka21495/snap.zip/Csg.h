#ifndef CSG_H
#define CSG_H
#include "Course.h"
class Csg : public Course
{
public:
	Csg();
	Csg(string name, string ID, string grade)
		:studentID(ID), studentGrade(grade) {
		setCourseName(name);
	};
	~Csg();
	string getStudentID();
	string getStudentGrade();
	void setStudentID(string studentID);
	void setStudentGrade(string studentGrade);
	string toString();
	friend std::ostream& operator<< (ostream& os, Csg& myclass);
private:
	string studentID;
	string studentGrade;
};

#endif