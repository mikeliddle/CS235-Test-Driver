#include <iostream>
#include <fstream>
#include <string>
#include <iomanip>
#include <sstream>
#include "Gradebook.h"

#ifdef _MSC_VER
#define _CRTDBG_MAP_ALLOC  
#include <crtdbg.h>
#include "Source.h"
#define VS_MEM_CHECK _CrtSetDbgFlag(_CRTDBG_ALLOC_MEM_DF | _CRTDBG_LEAK_CHECK_DF);
#else
#define VS_MEM_CHECK
#endif

const std::string printExamAverages(const Gradebook& gbook) {
	std::stringstream ss;
	const int EXAM_NUM = 3, PREC = 1;

	ss << "Exam Averages:" << std::endl;
	for (int i = 0; i < gbook.getNumScores(); i++) {
		ss << "Exam";
		ss << std::setw(EXAM_NUM) << i + 1;
		ss << " average =" << std::fixed << std::setprecision(PREC) << gbook.calcAverage(i);
		ss << gbook.getGradeBreakdownForExam(i) << std::endl;
	}
	
	return ss.str();
}

const std::string printStudentExamGrades(const Gradebook& gbook) {
	std::stringstream ss;

	ss << "Student Exam Grades:" << std::endl;
	for (int i = 0; i < gbook.getNumStudents(); i++) {
		ss << gbook.getGradeBreakdownForStudent(i) << std::endl;
	}

	return ss.str();
}

const std::string printBonusInformation(const Gradebook& gbook) {
	std::stringstream ss;
	const int PREC = 1;

	ss << "**BONUS**" << std::endl;
	ss << "Class Average = " << std::fixed << std::setprecision(PREC) << gbook.calcClassAverage() << std::endl;
	ss << "Student Final Exam Grade:" << std::endl;
	for (int i = 0; i < gbook.getNumStudents(); i++) {
		ss << gbook.getFinalGradeForStudent(i) << (i < gbook.getNumStudents() - 1 ? "\n" : "");
	}

	return ss.str();
}

int main(int argc, char** argv) {

	VS_MEM_CHECK

	if (argc != 3) {
		std::cerr << "invalid number of args" << std::endl;
		return 1;
	}

	std::ifstream ifs(argv[1]); //first argument is the file to read in
	std::ofstream ofs(argv[2]); //second argument is the file to write to

	if (!ifs || !ofs) {
		std::cerr << "invalid args" << std::endl;
		return 1;
	}

	//read in the dimensions for the 2d score array
	int numStudents, numScores;
	ifs >> numStudents >> numScores;

	//create an array to hold student names and a 2d array to hold scores
	std::string *students = new std::string[numStudents];
	int** scores = new int*[numStudents];
	for (int i = 0; i < numStudents; i++) {
		scores[i] = new int[numScores];
	}

	//read in student names and scores
	std::string firstName, lastName;
	int score;
	for (int i = 0; i < numStudents; i++) {
		ifs >> firstName >> lastName;
		students[i] = firstName + " " + lastName;
		for (int j = 0; j < numScores; j++) {
			ifs >> score;
			scores[i][j] = score;
		}
	}

	//create the gradebook
	Gradebook gbook(students, scores, numStudents, numScores);

	
	//begin output
	ofs << printExamAverages(gbook) << std::endl;
	ofs << printStudentExamGrades(gbook) << std::endl;
	ofs << printBonusInformation(gbook) << std::endl;
	

	//begin output
	//ofs << gbook.stringifyExamAverages() << std::endl;

	//clean up
	delete[] students;
	for (int i = 0; i < numStudents; i++) {
		delete[] scores[i];
	}
	delete[] scores;

	//system("pause");
	return 0;
}