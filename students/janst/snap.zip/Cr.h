#pragma once
#include "Course.h"

class Cr: virtual public Course {
protected:
	std::string room;
	std::string toString() override;

public:
	Cr();

	Cr(std::string, std::string);

	friend std::ostream& operator<< (std::ostream& os, Cr& myclass)//remove const
	{
		os << myclass.toString();
		return os;
	}

	std::string getRoom();

};
