#include "CSG.h"



CSG::CSG(string name, string ID, string grade) : Course(name)
{
	studentID = ID;
	studentGrade = grade;
}


CSG::~CSG()
{
}

string CSG::toString() {
	stringstream out;
	out << "csg(" << courseName << "," << studentID << "," << studentGrade << ")";
	return out.str();
}