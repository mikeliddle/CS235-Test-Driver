#include "Snap.h"

const string DEFAULT_STUDENT_ID = "666";
const string DEFAULT_STUDENT_NAME = "Satan";
const string DEFAULT_STUDENT_ADDRESS = "667 Michael Jackson Ave.";
const string DEFAULT_STUDENT_PHONE = "666-666-6666";

Snap::Snap()
{
	studentID = DEFAULT_STUDENT_ID;
	studentName = DEFAULT_STUDENT_NAME;
	studentAddress = DEFAULT_STUDENT_ADDRESS;
	studentPhone = DEFAULT_STUDENT_PHONE;
}


Snap::~Snap()
{
}

string Snap::getStudentID() const
{
	return this->studentID;
}

string Snap::getStudentName() const
{
	return this->studentName;
}

string Snap::getStudentAddress() const
{
	return this->studentAddress;
}

string Snap::getStudentPhone() const
{
	return this->studentPhone;
}

void Snap::setStudentID(const string studentID)
{
	this->studentID = studentID;
}

void Snap::setStudentName(const string studentName)
{
	this->studentName = studentName;
}

void Snap::setStudentAddress(const string studentAddress)
{
	this->studentAddress = studentAddress;
}

void Snap::setStudentPhone(const string studentPhone)
{
	this->studentPhone = studentPhone;
}

string Snap::toString() const
{
	return "snap(" + studentID + "," + studentName + "," + studentAddress + "," + studentPhone + ")";
}

std::ostream & operator<<(ostream & os, Snap & myclass)
{
	os << myclass.toString();
	return os;
}
