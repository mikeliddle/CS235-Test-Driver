#include <iostream>
#include <fstream>
#include <string>
#include <sstream>
#include <iomanip>

#ifdef _MSC_VER
#define _CRTDBG_MAP_ALLOC  
#include <crtdbg.h>
#define VS_MEM_CHECK _CrtSetDbgFlag(_CRTDBG_ALLOC_MEM_DF | _CRTDBG_LEAK_CHECK_DF);
#else
#define VS_MEM_CHECK
#endif

using namespace std;
int num_of_files;
string file_name;

int num_of_students;
int num_of_exams;




void outputFinalGrades(ofstream &out, int* gradesArray[], string studentArray[])
{
	float student_exam_sum;
	float student_average;
	float class_exam_sum = 0;
	float class_average = 0;

	for (int j = 0; j < num_of_students; j++)
	{
		student_exam_sum = 0;
		student_average = 0;
		for (int i = 0; i < num_of_exams; i++)
		{
			student_exam_sum += gradesArray[j][i];
		}
		student_average = student_exam_sum / num_of_exams;
		class_exam_sum += student_average;


		
	}
	class_average = class_exam_sum / num_of_students;
	out << "Class Average = " << class_average << endl << endl;

	for (int j = 0; j < num_of_students; j++)
	{
		student_exam_sum = 0;
		student_average = 0;

		out << studentArray[j] << "  ";

		for (int i = 0; i < num_of_exams; i++)
		{
			student_exam_sum += gradesArray[j][i];
		}
		student_average = student_exam_sum / num_of_exams;

		if (class_average - 5 <= student_average && student_average <= class_average + 5)
		{
			out << student_average << "(C)" << endl;
			
		}

		else if (class_average + 5 < student_average && student_average < class_average + 15)
		{
			out << student_average << "(B)" << endl;
			
		}

		else if (class_average - 5 > student_average && student_average > class_average - 15)
		{
			out << student_average << "(D)" << endl;
			
		}
		else if (class_average + 15 <= student_average)
		{
			out << student_average << "(A)" << endl;
			
		}

		else if (class_average - 15 >= student_average)
		{
			out << student_average << "(E)" << endl;
			
		}

	}

	out << endl << endl;
}




void outputExamAverages(ofstream &out, int* letterGradesArray[], float classAveragesArray[], int& As, int& Bs, int& Cs, int& Ds, int& Es)
{

	out << "Exam Averages:" << endl;
	for (int j = 0; j < num_of_exams; j++)
	{
		out << "Exam  " << j + 1 << " " << "average =" << fixed << setprecision(1) << classAveragesArray[j] << "  ";
		for (int i = 0; i < 5; i++)
		{
			switch (i)
			{
			case 0: out << letterGradesArray[j][i] << "(A)   ";
				break;
			case 1: out << letterGradesArray[j][i] << "(B)   ";
				break;
			case 2: out << letterGradesArray[j][i] << "(C)   ";
				break;
			case 3: out << letterGradesArray[j][i] << "(D)   ";
				break;
			case 4: out << letterGradesArray[j][i] << "(E)   ";
				break;
			}

		}
			out << endl;
	}

	out << endl << endl;
}




void outputStudentExamGrades(ofstream &out, int* letterGradesArray[], int* gradesArray[], string studentArray[], float classAveragesArray[], int& As, int& Bs, int& Cs, int& Ds, int& Es)
{

	out << "Student Exam Grades:" << endl;
	for (int j = 0; j < num_of_students; j++)
	{
		out << studentArray[j] << "     ";
		for (int i = 0; i < num_of_exams; i++)
		{
			
			if (classAveragesArray[i] - 5 <= gradesArray[j][i] && gradesArray[j][i] <= classAveragesArray[i] + 5)
			{
				out << gradesArray[j][i] << "(C)" << " ";
				Cs++;
				letterGradesArray[i][2] += 1;
			}
			
			else if (classAveragesArray[i] + 5 < gradesArray[j][i] && gradesArray[j][i] < classAveragesArray[i] + 15)
			{
				out << gradesArray[j][i] << "(B)" << " ";
				Bs++;
				letterGradesArray[i][1] += 1;
			}

			else if (classAveragesArray[i] - 5 > gradesArray[j][i] && gradesArray[j][i] > classAveragesArray[i] - 15)
			{
				out << gradesArray[j][i] << "(D)" << " ";
				Ds++;
				letterGradesArray[i][3] += 1;
			}
			else if (classAveragesArray[i] + 15 <= gradesArray[j][i])
			{
				out << gradesArray[j][i] << "(A)" << " ";
				As++;
				letterGradesArray[i][0] += 1;
			}
			
			else if (classAveragesArray[i] - 15 >= gradesArray[j][i])
			{
				out << gradesArray[j][i] << "(E)" << " ";
				Es++;
				letterGradesArray[i][4] += 1;
			}

			
		}
		out << endl; 
	}
	out << endl << endl;
	 outputExamAverages(out, letterGradesArray, classAveragesArray, As, Bs, Cs, Ds, Es);
}




double calculateClassAverages(int* gradesArrays[], int collumn, float classAveragesArray[])
{
	 
	float class_sum = 0;
	float class_average;
	for (int j = 0; j < num_of_exams; j++)
	{
		for (int i = 0; i < num_of_students; i++)
		{
			class_sum += gradesArrays[i][j];
		}
		class_average = class_sum / num_of_students;
		classAveragesArray[j] = class_average;
		class_sum = 0;
	}
	return NULL;
}




void readData(ifstream& in, ofstream& out)
{
	string current_line;
	string first_name;
	string last_name;
	string student_name;
	stringstream ss;

	int As = 0;
	int Bs = 0;
	int Cs = 0;
	int Ds = 0;
	int Es = 0;
	

	 in >> num_of_students >> num_of_exams;

	 string *studentArray = new string[num_of_students];
	 float *classAveragesArray = new float[num_of_exams];
	 int **gradesArray = new int*[num_of_students];
	 int **letterGradesArray = new int*[num_of_exams];

	 for (int i = 0; i < num_of_students; ++i)
		 {
			 gradesArray[i] = new int[num_of_exams];
		 }

	 for (int i = 0; i < num_of_exams; ++i)
	 {
		 letterGradesArray[i] = new int[5]; //always 5 letter grades
	 }
	 for (int j = 0; j < num_of_exams; j++)
	 {
		 for (int i = 0; i < 5; i++)
		 {
			  letterGradesArray[j][i] = 0;   //set num of letter grades to 0
		 }
	 }




	 for (int j = 0; j < num_of_students; j++)
	 {
		 getline(in, current_line);  //skips the rest of the line

		 while (getline(in, current_line))
		 {
			 ss << current_line << endl;
		 }
		 ss >> first_name;
		 ss >> last_name;
		 student_name = first_name + " " + last_name;
		 studentArray[j] = student_name;

		 for (int i = 0; i < num_of_exams; i++)
		 {
			 ss >> gradesArray[j][i];
		 }
	 }
	 calculateClassAverages (gradesArray, 0, classAveragesArray);
	 outputStudentExamGrades(out,letterGradesArray, gradesArray, studentArray, classAveragesArray, As, Bs, Cs, Ds, Es);
	 outputFinalGrades(out, gradesArray, studentArray);

	   /*
		for (int i = 0; i < num_of_students; i++)
		{
			delete[] studentArray[i];
		}
		*/
		 delete [] studentArray; // delete arrays
		 delete[] classAveragesArray;

		 for (int i = 0; i < num_of_students; ++i)
		 {
			 delete[] gradesArray[i];
		 }
		 delete[] gradesArray;

		 for (int i = 0; i < num_of_exams; ++i)
		 {
			 delete[] letterGradesArray[i];
		 }
		 delete[] letterGradesArray;
	 
}




int main(int argc, char *argv[])
{
	 VS_MEM_CHECK
	if (argc < 3)
	{
		cerr << "Please provide name of input and output files \n";
		return 0;
	}

	ifstream in (argv[1]);
	ofstream out(argv[2]);
	
	readData(in, out);

	return 0;
}
