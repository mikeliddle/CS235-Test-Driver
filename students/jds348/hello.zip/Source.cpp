#include<iostream>

using namespace std;

int main() {
	cout << "hello World" << endl;

	system("PAUSE");
	return 1;
}