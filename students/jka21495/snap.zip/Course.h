#ifndef COURSE_H
#define COURSE_H
#include <string>

using namespace std;

class Course
{
public:
	Course();
	Course(string courseName);
	string getCourseName();
	void setCourseName(const string courseName);
	~Course();
	virtual string toString();
	friend std::ostream& operator<< (ostream& os, Course& myclass);
private:
	string courseName;
};

#endif