#include "Schedule.h"

Schedule::Schedule() 
{
	courseName = "";
}

Schedule::Schedule(std::string a, std::string b, std::string c, std::string d, std::string e, std::string f, std::string g, std::string h) : Snap(b, c, d, e), Cdh(a, f, g), Cr(a, h), Course(a){}

//Ex. Carlie Brown, 12345, Manager, 555-1234, CS101 MWF 9AM, 1170 TMCB
std::string Schedule::toString() {
	std::stringstream ss;
	if (courseName == ""){}
	else
		ss <<  studentName << ", " << studentID << ", " << studentAddress << ", " << studentPhone << ", " << getCourseName() << " " << day << " " << time << " " << room;
	return ss.str();
}
