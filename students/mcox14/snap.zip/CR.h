#ifndef CR_H
#define CR_H
#include "Course.h"
class CR : public Course
{
public:
	CR(string name, string room);
	~CR();

	string getClassroom() {
		return classroom;
	}

	string toString();

private:
	string classroom;
};

#endif