//Iterator
#include <iostream>
#include <fstream>
#include "MyArray.h"
#ifdef _MSC_VER
#define _CRTDBG_MAP_ALLOC  
#include <crtdbg.h>
#define VS_MEM_CHECK _CrtSetDbgFlag(_CRTDBG_ALLOC_MEM_DF | _CRTDBG_LEAK_CHECK_DF);
#else
#define VS_MEM_CHECK;
#endif
using namespace std;

enum Modes {SEQ, PRIME, COMPOSITE, FIBONACCI};

int main(int argc, char* argv[]) {
	VS_MEM_CHECK;
	if (argc < 3) {
		cout << "Please provide an input and output file." << endl;
		return 1;
	}
	ifstream inStream(argv[1]);
	if (!inStream.is_open()) {
		cout << "Error opening file." << endl;
		return 1;
	}
	ofstream outStream(argv[2]);
	MyArray<int>* myArray = new MyArray<int>(500);

	int nextNum;
	while (inStream >> nextNum) {
		myArray->push_back(nextNum);
	}
	outStream << "myArray" << endl << *myArray;
	MyArray<int>::Iterator it = myArray->begin(SEQ);
	outStream << endl << "SEQUENTIAL" << endl;
	outStream << "iter1: " << it.toString();
	for (; it != myArray->end(); ++it) {
		outStream << *it << " ";
	}
	outStream << endl;
	outStream << endl << "PRIME" << endl;
	it = myArray->begin(PRIME);
	outStream << "iter2: " << it.toString();
	for (; it != myArray->end(); ++it) {
		outStream << *it << " ";
	}
	outStream << endl;
	outStream << endl << "COMPOSITE" << endl;
	it = myArray->begin(COMPOSITE);
	outStream << "iter3: " << it.toString();
	for (; it != myArray->end(); ++it) {
		outStream << *it << " ";
	}
	outStream << endl;
	outStream << endl << "FIBONACCI" << endl;
	it = myArray->begin(FIBONACCI);
	outStream << "iter4: " << it.toString();
	for (; it != myArray->end(); ++it) {
		outStream << *it << "=" << *it[-2] << "+" << *it[-1] << " ";
	}
	outStream << endl;
	delete myArray;
}