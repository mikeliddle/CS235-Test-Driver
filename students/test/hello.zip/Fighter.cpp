#include "Fighter.h"
#include <string>
#include <iostream>

/*
 * Fighter.cpp
 *
 *  Created on: Sep 1, 2016
 *      Author: mike.liddle
 */
Fighter::Fighter() {
	this->name = "";
	this->maxHP = 0;
	this->strength = 0;
	this->speed = 0;
	this->magic = 0;
}

Fighter::Fighter(string name, int maxHP, int strength, int speed, int magic) {
	this->name = name;
	this->maxHP = maxHP;
	this->strength = strength;
	this->currentHP = maxHP;
	this->speed = speed;
	this->magic = magic;
}

/*
 *	getName()
 *
 *	Returns the name of this Fighter.
 */
std::string Fighter::getName() {
	return name;
}

/*
 *	getMaximumHP()
 *
 *	Returns the maximum hit points of this Fighter.
 */
int Fighter::getMaximumHP() {
	return maxHP;
}

/*
 *	getCurrentHP()
 *
 *	Returns the current hit points of this Fighter.
 */
int Fighter::getCurrentHP() {
	return currentHP;
}

/*
 *	getStrength()
 *
 *	Returns the strength stat of this Fighter.
 */
int Fighter::getStrength() {
	return strength;
}

/*
 *	getSpeed()
 *
 *	Returns the speed stat of this Fighter.
 */
int Fighter::getSpeed() {
	return speed;
}

/** getMagic()
 *
 *	Returns the magic stat of this Fighter.
 */
int Fighter::getMagic() {
	return magic;
}

/**	takeDamage(int)
 *
 *	Reduces the Fighter's current hit points by an amount equal to the given
 *	damage minus one fourth of the Fighter's speed.  This method must reduce
 *	the Fighter's current hit points by at least one.  It is acceptable for
 *	this method to give the Fighter negative current hit points.
 *
 *	Examples:
 *		damage=10, speed=7		=> damage_taken=9
 *		damage=10, speed=9		=> damage_taken=8
 *		damage=10, speed=50		=> damage_taken=1
 */
void Fighter::takeDamage(int damage) {
	int damageToTake = (damage - (speed / 4));
	if (damageToTake >= 1){
		currentHP -= damageToTake;
	} else {
		currentHP -= 1;
	}
}

/*
 *	regenerate()
 *
 *	Increases the Fighter's current hit points by an amount equal to one sixth of
 *	the Fighter's strength.  This method must increase the Fighter's current hit
 *	points by at least one.  Do not allow the current hit points to exceed the
 *	maximum hit points.
 *
 *	Cleric:
 *	Also increases a Cleric's current mana by an amount equal to one fifth of the
 *	Cleric's magic.  This method must increase the Cleric's current mana by at
 *	least one.  Do not allow the current mana to exceed the maximum mana (again, 5 times its magic).
 */
void Fighter::regenerate() {
	int regHP = (strength / 6);
	if (currentHP + regHP >= maxHP){
		currentHP = maxHP;
	} else if (regHP < 1){
		currentHP += 1;
	} else {
		currentHP += strength/6;
	}
}

void Fighter::reset() {
	currentHP = Fighter::maxHP;
}

/** int getDamage(){
  return 1;
} */

/**  bool useAbility(){
  return false;
} */
