/*
 * Fighter.h
 *
 *  Created on: Sep 1, 2016
 *      Author: mike.liddle
 */
#ifndef FIGHTER_H_
#define FIGHTER_H_

#include "FighterInterface.h"

class Fighter: public FighterInterface {
public:
	Fighter();
	Fighter(string name, int maxHP, int strength, int speed, int magic);
	string getName();
	int getMaximumHP();
	int getCurrentHP();
	int getStrength();
	int getSpeed();
	int getMagic();
	virtual int getDamage() = 0;
	void takeDamage(int damage);
	void reset();
	void regenerate();
  	virtual bool useAbility() = 0;
protected:
	string name;
	int maxHP;
	int currentHP;
	int strength;
	int speed;
	int magic;
	char type;
};

#endif /* FIGHTER_H_ */
