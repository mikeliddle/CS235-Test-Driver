
#include <iostream>
#include <fstream>
#include <string>
#include <sstream>
#include <vector>
#include <limits>
#include "MyArray.h"

#ifdef _MSC_VER
#define _CRTDBG_MAP_ALLOC  
#include <crtdbg.h>
#define VS_MEM_CHECK _CrtSetDbgFlag(_CRTDBG_ALLOC_MEM_DF | _CRTDBG_LEAK_CHECK_DF);
#else
#define VS_MEM_CHECK;
#endif

//using namespace std;
using std::string;
using std::ifstream;
using std::ofstream;
using std::istringstream;

using std::cerr;
using std::endl;
using std::cout;

bool fib(int a, int b, int c)
{
	if (a + b == c)
	{
		return true;
	}
	return false;
}

bool isPrime(int n)
{
	for (int i = 2; i < n; i++)
	{
		if (n % i == 0)
		{
			return false;
		}
	}
	if (n == 1)
	{
		return false;
	}
	return true;
}

int main(int argc, char* argv[])
{
	VS_MEM_CHECK;
	if (argc < 3)
	{
		cerr << "Please provide name of input and output files\n";
		return 1;
	}
	cout << "Input file: " << argv[1] << endl;
	ifstream in(argv[1]);
	if (!in)
	{
		cerr << "Unable to open " << argv[1] << " for input\n";
		return 1;
	}
	cout << "Output file: " << argv[2] << endl;
	ofstream out(argv[2]);
	if (!out)
	{
		in.close();
		cerr << "Unable to open " << argv[2] << " for output\n";
	}
	try
	{
		MyArray<int> myArray;//template definition for ints
		int temp;
		while (in >> std::skipws >> temp)
		{
			myArray.push_back(temp);
		}
		out << "myArray" << endl << myArray << endl;

		out << endl << "SEQUENTIAL" << endl;
		//use iterators
		MyArray<int>::Iterator iter1 = myArray.begin();
		out << "iter1: " << "size=" << myArray.getSize() << " index=" << 0 << " mode=" << 0 << endl;
		for (iter1 = myArray.begin(); iter1 != myArray.end(); ++iter1)
			out << *iter1 << " ";
		out << endl;

		out << endl << "PRIME" << endl;

		//find first index
		int index = 0;
		int i = 0;
		MyArray<int>::Iterator iter5 = myArray.begin();
		for (iter5 = myArray.begin(); iter5 != myArray.end(); ++iter5)
		{
			if (isPrime(*iter5))
			{
				index = i;
				break;
			}
			i++;
		}
		MyArray<int>::Iterator iter2 = myArray.begin();
		out << "iter2: " << "size=" << myArray.getSize() << " index=" << index << " mode=" << 1 << endl;
		for (iter2 = myArray.begin(); iter2 != myArray.end(); ++iter2)
			if (isPrime(*iter2))
			{
				out << *iter2 << " ";
			}
		out << endl;

		out << endl << "COMPOSITE" << endl;

		i = 0;
		index = 0;
		MyArray<int>::Iterator iter7 = myArray.begin();
		for (iter7 = myArray.begin(); iter7 != myArray.end(); ++iter7)
		{
			if (!isPrime(*iter7))
			{
				index = i;
				break;
			}
			i++;
		}

		MyArray<int>::Iterator iter3 = myArray.begin();
		out << "iter3: " << "size=" << myArray.getSize() << " index=" << index << " mode=" << 2 << endl;
		for (iter3 = myArray.begin(); iter3 != myArray.end(); ++iter3)
			if (!isPrime(*iter3))
			{
				out << *iter3 << " ";
			}
		out << endl;

		out << endl << "FIBINOCCI" << endl;

		index = 0;
		i = 0;
		MyArray<int>::Iterator iter6 = myArray.begin();
		for (iter6 = myArray.begin(); iter6 != myArray.end(); ++iter6)
		{
			if (i > 1)
			{
				if (fib(iter6[i - 2], iter6[i - 1], iter6[i]))
				{
					index = i;
					break;
				}
			}
			i++;
		}

		MyArray<int>::Iterator iter4 = myArray.begin();
		out << "iter4: " << "size=" << myArray.getSize() << " index=" << index << " mode=" << 3 << endl;
		i = 0;
		for (iter4 = myArray.begin(); iter4 != myArray.end(); ++iter4)
		{
			if (i > 1)
			{
				if (fib(iter4[i - 2], iter4[i - 1], iter4[i]))
				{
					out << *iter4 << "=" << iter4[i - 2] << "+" << iter4[i - 1] << " ";
				}
			}
			i++;
		}

	}
	catch (...)
	{
		cerr << "Exception Occured";
	}
	return 0;
}