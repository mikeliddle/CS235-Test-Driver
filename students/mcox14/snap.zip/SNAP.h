#ifndef SNAP_H
#define SNAP_H
#include <string>
#include <sstream>

using namespace std;
class SNAP
{
public:
	SNAP(string ID, string name, string address, string phone);
	~SNAP();

	friend std::ostream& operator<< (ostream& os, SNAP& snap) {
		os << snap.toString();
		return os;
	}
	string getStudentID() {
		return studentID;
	}
	string getStudentName() {
		return studentName;
	}
	string getStudentAddress() {
		return studentAddress;
	}
	string getStudentPhone() {
		return studentPhone;
	}
	string toString();
private:
	string studentID;
	string studentName;
	string studentAddress;
	string studentPhone;

};

#endif

