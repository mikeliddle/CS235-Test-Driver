#pragma once
#include "Course.h"

class Cdh : virtual public Course {
protected:
	std::string day;
	std::string time;
	std::string toString() override;

public:
	Cdh();

	Cdh(std::string, std::string, std::string);

	friend std::ostream& operator<< (std::ostream& os, Cdh& myclass)
	{
		os << myclass.toString();
		return os;
	}

	std::string getDay();

	std::string getTime();
};