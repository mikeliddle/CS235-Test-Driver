#include "Course.h"



Course::Course(string name = "")
{
	courseName = name;
}


Course::~Course()
{
}
