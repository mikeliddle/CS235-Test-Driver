/*
 * Arena.cpp
 *
 *  Created on: Sep 1, 2016
 *      Author: mike.liddle
 */

#include "Arena.h"

Arena::Arena() {
//	fighters = new std::vector<Fighter*>;
}

/*
 *	addFighter(std::string)
 *
 *	Adds a new fighter to the collection of fighters in the arena. Do not allow
 *	duplicate names.  Reject any std::string that does not adhere to the format
 *	outlined in the lab specs.
 *
 *	Return true if a new fighter was added; false otherwise.
 */
bool Arena::addFighter(string info) {
	string name, type, dump;
	Fighter* newFighter;
	int maxHP, strength, speed, magic;
	stringstream ss(info);
	if (ss >> name >> type >> maxHP >> strength >> speed >> magic) {
		if (maxHP <= 0 || strength <= 0 || speed <= 0 || magic <=0){
			return false;
		}
		if (ss >> dump){
			return false;
		}
		
		for (int i = 0; i < fighters.size(); i++) {
			if (fighters.at(i)->getName() == name) {
				return false;
			}
		}

		if (type == "C") {	
			newFighter = new Cleric(name, maxHP, strength, speed, magic);
		} else if (type == "A") {
			newFighter = new Archer(name, maxHP, strength, speed, magic);
		} else if (type == "R") {
			newFighter = new Robot(name, maxHP, strength, speed, magic);
		} else {
			return false;
		}
	} else {
		return false;
	}
	fighters.push_back(newFighter);
	return true;
}

/*
 *	removeFighter(std::string)
 *
 *	Removes the fighter whose name is equal to the given name.  Does nothing if
 *	no fighter is found with the given name.
 *
 *	Return true if a fighter is removed; false otherwise.
 */
bool Arena::removeFighter(string name) {
	int i = 0;
	for (Fighter* tempFighter: fighters) {
		if (tempFighter->getName() == name) {
			fighters.erase(fighters.begin() + i); //change tempFighter to it's index.
			return true;
		}
	i++;
	}
	return false;
}

/*
 *	getFighter(std::string)
 *
 *	Returns the memory address of a fighter whose name is equal to the given
 *	name.  Returns NULL if no fighter is found with the given name.
 *
 *	Return a memory address if a fighter is found; NULL otherwise.
 */
FighterInterface* Arena::getFighter(string name) {
	Fighter* tempFighter;
	for (int i = 0; i < fighters.size(); i++) {
		if (fighters.at(i)->getName() == name) {
			tempFighter = fighters.at(i);
			return tempFighter;
		}
	}
	return 0;
}

/*
 *	getSize()
 *
 *	Returns the number of fighters in the arena.
 *
 *	Return a non-negative integer.
 */
int Arena::getSize() {
	return fighters.size();
}
