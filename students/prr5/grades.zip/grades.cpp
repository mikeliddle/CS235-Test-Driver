/** Lab 01 - Grades	2018-01-06
Program to assign grades to exam scores
*/

#include <iostream>
#include <fstream>
#include <string>
#include <sstream>
#include <limits>
#include <iomanip>      // setprecision

using namespace std;

#define TEST_NUM	1
#define CONSOLE		1
#define DEBUG		1

#define DEBUGX(x) cout << x;

#ifdef _MSC_VER
#define _CRTDBG_MAP_ALLOC  
#include <crtdbg.h>
#define VS_MEM_CHECK _CrtSetDbgFlag(_CRTDBG_ALLOC_MEM_DF | _CRTDBG_LEAK_CHECK_DF);
#else
#define VS_MEM_CHECK
#endif

typedef struct
{
	char* input;
	char* output;
} Tests;

Tests tests[] = { { "lab01_in_00.txt", "lab01_out_00.txt" },
{ "lab01_in_01.txt", "lab01_out_01.txt" },
{ "lab01_in_02.txt", "lab01_out_02.txt" },
{ "lab01_in_03.txt", "lab01_out_03.txt" },
{ "lab01_in_04.txt", "lab01_out_04.txt" },
{ "lab01_in_05.txt", "lab01_out_05.txt" }
};

/** Function to assign a grade based on the average
@param score The score the student achieved
@param average The average for this exam
@return The grade
*/
string assign_grade(double score, double average)
{
	if (score < (average - 15)) return "F";
	if (score >(average + 15)) return "A";

	if (score < (average - 5)) return "D";
	if (score >(average + 5)) return "B";

	return "C";
}

/** Compute the average for an exam
@param exam The index of the exam in the array
@param num_students The number of students
*/
double compute_average(double** scores, int exam, int num_students)
{
	double sum = 0.0;
	for (int i = 0; i < num_students; i++)
		sum += scores[i][exam];
	return sum / num_students;
}


/** main
@param argc 3
@param argv[1]	input file
@param argv[2]	output file
@return 0
*/
int main(int argc, char* argv[])
{
	VS_MEM_CHECK
	//_crtBreakAlloc = 213;

	/** Two dimensional array of scores
	NOTE: Since C++ does not support dynamic two dimensional
	arrays, we allocate an array of pointers to pointers.
	*/
	double** scores;

#if 0
	if (argc < 3)
	{
		cerr << "Please provide name of input and output files\n";
		return 1;
	}

	cout << "Input file: " << argv[1] << endl;
	ifstream in(argv[1]);
	if (!in)
	{
		cerr << "Unable to open " << argv[1] << " for input\n";
		return 1;
	}
	cout << "Output file: " << argv[2] << endl;
	ofstream out(argv[2]);
	if (!out)
	{
		in.close();
		cerr << "Unable to open " << argv[2] << " for output\n";
	}
#else
	cout << endl << "Input File: " << tests[TEST_NUM].input;
	ifstream in(tests[TEST_NUM].input);

	cout << endl << "Output File: " << tests[TEST_NUM].output << endl;
	std::ostream& out = (CONSOLE) ? std::cout : *(new std::ofstream(tests[TEST_NUM].output));
#endif

	int num_students;
	int num_exams;
	in >> num_students >> num_exams;
	// Skip the rest of the line
	in.ignore(numeric_limits<int>::max(), '\n');

	// Allocate space for grades;
	scores = new double*[num_students];
	for (int i = 0; i < num_students; i++)
	{
		scores[i] = new double[num_exams];
	}
	// Allocate space for student names
	string* name = new string[num_students];

	// Read in student names and grades
	out << "Student Scores:" << endl;
	for (int i = 0; i < num_students; i++)
	{
		string line;
		getline(in, line);

		// get the student's name
		// Find the end of the student's name (first space before the first number)
		size_t p = 0;
		while (!isdigit(line[p])) ++p;	// line[p] is the first digit
		while (isspace(line[--p])) {}	// line[p] is last non-space before first digit
		++p;
		// line[p] is character after the last non-space before first digit
		name[i] = line.substr(0, p);

		// get the rest of the line
		string rest = line.substr(p);
		// Put this into an istringstream
		istringstream iss(rest);
		for (int j = 0; j < num_exams; j++)
		{
			iss >> scores[i][j];
		}
		// output input
		out << setw(20) << name[i] << " ";
		for (int j = 0; j < num_exams; j++)
		{
			out << setprecision(6) << setw(6) << scores[i][j];
		}
		out << endl;
	}

	// Compute the average for each exam
	out << endl << "Exam Averages:";
	double* averages = new double[num_exams];
	for (int i = 0; i < num_exams; i++)
	{
		averages[i] = compute_average(scores, i, num_students);
		out << endl << "Exam " << setw(2) << (i + 1) << " average = " << setprecision(1) << fixed << averages[i];

		int grades[5] = { 0, 0, 0, 0, 0 };
		for (int j = 0; j < num_students; j++)
		{
			if (assign_grade(scores[j][i], averages[i]) == "A") grades[0]++;
			else if (assign_grade(scores[j][i], averages[i]) == "B") grades[1]++;
			else if (assign_grade(scores[j][i], averages[i]) == "C") grades[2]++;
			else if (assign_grade(scores[j][i], averages[i]) == "D") grades[3]++;
			else if (assign_grade(scores[j][i], averages[i]) == "F") grades[4]++;
		}
		out << setw(5) << grades[0] << "(A)";
		out << setw(5) << grades[1] << "(B)";
		out << setw(5) << grades[2] << "(C)";
		out << setw(5) << grades[3] << "(D)";
		out << setw(5) << grades[4] << "(F)";
	}

	// Assign a grade for each exam and output
	out << endl << endl << "Student Exam Grades:";
	for (int i = 0; i < num_students; i++)
	{
		out << endl << setw(20) << name[i] << " ";
		for (int j = 0; j < num_exams; j++)
		{
			out << fixed << setprecision(0) << setw(6) << scores[i][j] << "(";
			out << assign_grade(scores[i][j], averages[j]) << ")";
		}
	}

	// output student average score/grade
	double* student_average = new double[num_students];
	double class_average = 0;
	for (int i = 0; i < num_students; i++)
	{
		student_average[i] = 0;
		for (int j = 0; j < num_exams; j++)
		{
			student_average[i] += scores[i][j];
		}
		student_average[i] /= num_exams;
		class_average += student_average[i];
	}
	class_average /= num_students;
	out << endl << endl << "Class Average = " << fixed << setprecision(1) << class_average;
	out << endl << "Student Final Exam Grade:";

	for (int i = 0; i < num_students; i++)
	{
		out << endl << setw(20) << name[i] << " ";
		out << fixed << setw(6) << setprecision(1) << student_average[i] << "(";
		out << assign_grade(student_average[i], class_average) << ")";
	}
	out << endl;

	// free new'd stuff - NO MEMORY LEAKS
	for (int i = 0; i < num_students; i++)
	{
		delete[] scores[i];
	}
	delete[] name;
	delete[] scores;
	delete averages;
	delete student_average;

	// close files (no memory leaks)
	if (&out != &std::cout)
	{
		//out->close();
		delete(&out);
	}
	in.close();

	return 0;
}
