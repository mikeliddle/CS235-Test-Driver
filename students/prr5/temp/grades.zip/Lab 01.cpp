/** Program to assign grades to exam scores */

#include <iostream>
#include <fstream>
#include <string>
#include <sstream>
#include <limits>

using std::string;
using std::ifstream;
using std::ofstream;
using std::istringstream;
using std::cerr;
using std::endl;
using std::cout;

#include <stdio.h>
#include <conio.h>
#include <stdlib.h>
#include <direct.h>

#define _CRTDBG_MAP_ALLOC  
#include <stdlib.h>  
#include <crtdbg.h> 


void PrintFullPath(char * partialPath)
{
	char full[_MAX_PATH];
	if (_fullpath(full, partialPath, _MAX_PATH) != NULL)
		printf("Full path is: %s\n", full);
	else
		printf("Invalid path\n");
}

/** Two dimensional array of scores
NOTE: Since C++ does not support dynamic
two dimensional arrays, we allocate
an array of pointers to pointers.
*/
double** scores;

/** Function to assign a grade based on the average
@param score The score the student achieved
@param average The average for this exam
@return The grade
*/
string assign_grade(double score, double average)
{
	if (average - 5 <= score && score <= average + 5)
		return "C";
	if (average - 15 <= score && score < average - 5)
		return "D";
	if (score < average - 15)
		return "F";
	if (average + 5 < score && score <= average + 15)
		return "B";
	return "A";
}

/** Compute the average for an exam
@param exam The index of the exam in the array
@param num_students The number of students
*/
double compute_average(int exam, int num_students)
{
	double sum = 0.0;
	for (int i = 0; i < num_students; i++)
		sum += scores[i][exam];
	return sum / num_students;
}


int main(int argc, char* argv[])
{
	PrintFullPath(".\\");
	if (argc < 3)
	{
		cerr << "Please provide name of input and output files\n";
		return 1;
	}

	cout << "Input file: " << argv[1] << endl;
	ifstream in(argv[1]);
	if (!in)
	{
		cerr << "Unable to open " << argv[1] << " for input\n";
		return 1;
	}
	ofstream out(argv[2]);
	if (!out)
	{
		cerr << "Unable to open " << argv[2] << " for output\n";
	}

	int num_students;
	int num_exams;
	in >> num_students >> num_exams;
	// Skip the rest of the line
	in.ignore(std::numeric_limits<int>::max(), '\n');
	// Allocate space for grades;
	scores = new double*[num_students];
	for (int i = 0; i < num_students; i++)
	{
		scores[i] = new double[num_exams];
	}
	// Allocate space for student names
	string* name = new string[num_students];

	// Read in student names and grades
	for (int i = 0; i < num_students; i++)
	{
		string line;
		getline(in, line);
		// Find the end of the student's name (first space before the first number)
		size_t p = 0;
		while (!isdigit(line[p])) ++p;
		// line[p] is the first digit
		while (isspace(line[--p])) {}
		// line[p] is last non-space before first digit
		++p;
		// line[p] is character after the last non-space before first digit
		// get the student's name
		name[i] = line.substr(0, p);
		// get the rest of the line
		string rest = line.substr(p);
		// Put this into an istringstream
		istringstream iss(rest);
		for (int j = 0; j < num_exams; j++)
		{
			iss >> scores[i][j];
		}
	}
	// Compute the average for each exam
	double* averages = new double[num_exams];
	for (int i = 0; i < num_exams; i++)
	{
		averages[i] = compute_average(i, num_exams);
		cout << "Exam " << i << " average = " << averages[i] << endl;
	}

	// Assign a grade for each exam and output
	for (int i = 0; i < num_students; i++)
	{
		out << name[i] << " ";
		for (int j = 0; j < num_exams; j++)
		{
			out << scores[i][j] << "(";
			out << assign_grade(scores[i][j], averages[j]) << ") ";
		}
		out << endl;
	}

	// free new'd stuff
	for (int i = 0; i < num_students; i++)
	{
		delete[] scores[i];
	}
	delete[] name;
	delete[] scores;

	out.close();
	in.close();

	_CrtDumpMemoryLeaks(); 
	return 0;
}
