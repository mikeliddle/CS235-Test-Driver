//Accepts RGB color values and returns the hexadecimal equivalent

#include <iostream>
#include <sstream>
#include <string>

using namespace std;

string colorConversion(int val) {
	int firstVal = 0;
	int secVal = 0;
	string hexFirst = "";
	string hexSec = "";
	string output = "";

	while (val > 0) {
		if (val % 16 == 0) {
			firstVal = val / 16;
			break;
		}
		else {
			secVal += 1;
			val -= 1;
		}
	}

	switch (firstVal) {
		case 10:
			hexFirst = "a";
			break;
		case 11:
			hexFirst = "b";
			break;
		case 12:
			hexFirst = "c";
			break;
		case 13:
			hexFirst = "d";
			break;
		case 14:
			hexFirst = "e";
			break;
		case 15:
			hexFirst = "f";
			break;
		default:
			hexFirst += firstVal;
			break;
	}

	switch (secVal) {
		case 10:
			hexSec = "a";
			break;
		case 11:
			hexSec = "b";
			break;
		case 12:
			hexSec = "c";
			break;
		case 13:
			hexSec = "d";
			break;
		case 14:
			hexSec = "e";
			break;
		case 15:
			hexSec = "f";
			break;
		default:
			hexSec += secVal;
			break;
	}
	
	output += hexFirst;
	output += hexSec;

	return output;
}

string receiveInput() {
	string rgbInput = "";
	string hexCode = "#";
	int firstComma = 0;
	int secondComma = 0;
	int redVal = 0;
	int greenVal = 0;
	int blueVal = 0;

	cout << "Please enter your rgb color [no spaces] (xxx,xxx,xxx): ";
	cin >> rgbInput;

	firstComma = rgbInput.find(',');
	secondComma = rgbInput.find(',', firstComma+1);

	istringstream(rgbInput.substr(1, firstComma)) >> redVal;
	istringstream(rgbInput.substr(firstComma + 1, secondComma)) >> greenVal;
	istringstream(rgbInput.substr(secondComma + 1, rgbInput.size() - 1)) >> blueVal;
	cout << redVal << " " << greenVal << " " << blueVal << endl;

	hexCode += colorConversion(redVal);
	hexCode += colorConversion(greenVal);
	hexCode += colorConversion(blueVal);

	return hexCode;
}

int main() {
	cout << receiveInput() << endl;

	return 0;
}
