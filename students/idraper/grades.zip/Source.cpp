/*
Isaac Draper, Section 2, draper.isaac@byu.net
Description: Code takes in two arguments to main, file to input and file to output. Program processes file input and formats data in file output.
*/

#include <iostream>
#include <string>
#include <iomanip>
#include <fstream>

#ifdef _MSC_VER
#define _CRTDBG_MAP_ALLOC  
#include <crtdbg.h>
#define VS_MEM_CHECK _CrtSetDbgFlag(_CRTDBG_ALLOC_MEM_DF | _CRTDBG_LEAK_CHECK_DF);
#else
#define VS_MEM_CHECK
#endif

using namespace std;

const string getLetterGrade(int score, double avg);
const int determineLetterGrade(int score, double avg);

int main(int argc, char *argv[])
{
	// enable memory leak check
	VS_MEM_CHECK;

	// initialize variables and static arrays
	int numStudents = 0;
	int numExams = 0;
	double classAverage = 0.0;
	string firstName = "";
	string lastName = "";

	if (argc < 3)
	{
		cerr << "Please provide name of input and output files\n";
		system("PAUSE");
		return 1;
	}
	cout << "Input file: " << argv[1] << endl;
	ifstream in(argv[1]);
	if (!in)
	{
		cerr << "Unable to open " << argv[1] << " for input\n";
		system("PAUSE");
		return 1;
	}
	cout << "Output file: " << argv[2] << endl;
	ofstream out(argv[2]);
	if (!out)
	{
		in.close();
		cerr << "Unable to open " << argv[2] << " for output\n";
	}
	
	// Get the number of students and exams from top of input file
	in >> numStudents;
	in >> numExams;

	// create the dynamic arrays
	string *students = new string[numStudents];			// single array
	double *averageScores = new double[numExams];		// single array
	double *studentAverage = new double[numStudents];	// single array
	int **numLetterGrades = new int*[numExams];			// double array
	int **examScores = new int*[numStudents];			// double array

	// initialize students average to 0
	for (int i = 0; i < numStudents; ++i)
	{
		studentAverage[i] = 0;
	}

	// initialize average scores to 0
	for (int i = 0; i < numExams; ++i)
	{
		averageScores[i] = 0;
	}
	
	// instantiate letter grades and initialaize all values to 0
	for (int i = 0; i < numExams; i++)
	{
		numLetterGrades[i] = new int[5];

		for (int n = 0; n < 5; n++)
		{
			numLetterGrades[i][n] = 0;
		}
	}

	// instantiate scores array to hold exam scores
	for (int i = 0; i < numStudents; ++i)
	{
		examScores[i] = new int[numExams];
	}

	// read all data from input file
	for (int student = 0; student < numStudents; student++)
	{
		in >> firstName;
		in >> lastName;
		students[student] = firstName + " " + lastName;

		for (int exam = 0; exam < numExams; exam++)
		{
			in >> examScores[student][exam];
			averageScores[exam] += examScores[student][exam];
		}
	}

	// populate data for average scores and number of letter grades
	for (int exam = 0; exam < numExams; exam++)
	{
		averageScores[exam] /= numStudents;
		classAverage += averageScores[exam];

		for (int student = 0; student < numStudents; student++)
		{
			numLetterGrades[exam][determineLetterGrade(examScores[student][exam], averageScores[exam])]++;
			studentAverage[student] += examScores[student][exam];
		}
	}
	classAverage /= numExams;

	// calculate student averages
	for (int student = 0; student < numStudents; student++)
	{
		studentAverage[student] /= numExams;
	}

	out << "Exam Averages" << endl;

	// output exam data to output file
	for (int exam = 0; exam < numExams; exam++)
	{
		out << left << setfill(' ') << setw(6) << "Exam";
		out << left << setfill(' ') << setw(2) << (exam + 1);
		out << left << setfill(' ') << setw(10) << "average = ";
		out << left << setfill(' ') << setw(8) << fixed << setprecision(1) << averageScores[exam];
		
		out << left << setfill(' ') << setw(2) << numLetterGrades[exam][0];
		out << left << setfill(' ') << setw(7) << "(A)";

		out << left << setfill(' ') << setw(2) << numLetterGrades[exam][1];
		out << left << setfill(' ') << setw(7) << "(B)";

		out << left << setfill(' ') << setw(2) << numLetterGrades[exam][2];
		out << left << setfill(' ') << setw(7) << "(C)";

		out << left << setfill(' ') << setw(2) << numLetterGrades[exam][3];
		out << left << setfill(' ') << setw(7) << "(D)";

		out << left << setfill(' ') << setw(2) << numLetterGrades[exam][4];
		out << left << setfill(' ') << setw(7) << "(F)";

		out << endl;
	}

	out << endl;
	out << "Student Exam Grades:" << endl;

	// output student data to output file
	for (int student = 0; student < numStudents; student++)
	{
		out << right << setfill(' ') << setw(20) << students[student];

		for (int exam = 0; exam < numExams; exam++)
		{
			out << right << setfill(' ') << setw(7) << examScores[student][exam];
			out << right << setfill(' ') << setw(3) << getLetterGrade(examScores[student][exam], averageScores[exam]);
		}

		out << endl;
	}

	out << endl;
	out << "Class Average = " << classAverage << endl;

	for (int student = 0; student < numStudents; student++)
	{
		out << right << setfill(' ') << setw(20) << students[student];
		out << right << setfill(' ') << setw(7) << studentAverage[student];
		out << right << setfill(' ') << setw(3) << getLetterGrade(studentAverage[student], classAverage);
		out << endl;
	}

	// clear up all memory
	for (int i = 0; i < numStudents; ++i)
	{
		delete[] examScores[i];
	}
	for (int i = 0; i < numExams; i++)
	{
		delete[] numLetterGrades[i];
	}
	delete[] examScores;
	delete[] numLetterGrades;
	delete[] students;
	delete[] averageScores;
	delete[] studentAverage;

	return 0;
}

// returns array position (eg A = 0, F = 4)
const int determineLetterGrade(int score, double avg)
{
	if (abs(score - avg) >= 15)
	{
		if (score - avg >= 15)
		{
			return 0;
		}
		else
		{
			return 4;
		}
	}
	else if (abs(score - avg) > 5)
	{
		if (score - avg > 5)
		{
			return 1;
		}
		else
		{
			return 3;
		}
	}
	else
	{
		return 2;
	}
}

const string getLetterGrade(int score, double avg)
{
	int grade = determineLetterGrade(score, avg);
	if (grade == 0)
	{
		return "(A)";
	}
	else if (grade == 1)
	{
		return "(B)";
	}
	else if (grade == 2)
	{
		return "(C)";
	}
	else if (grade == 3)
	{
		return "(D)";
	}
	else
	{
		return "(F)";
	}
}