#include "MyArray.h"
#include <stdexcept>
#include <sstream>
const int MAX_LENGTH = 30000;


MyArray::MyArray()
{
	array = new int[MAX_LENGTH];
	size = 0;
	currentMode = SEQUENTIAL;
}


MyArray::~MyArray()
{
	delete[] array;
}

void MyArray::push_back(int insert)
{
	array[size++] = insert;
}

string MyArray::toString() const
{
	std::stringstream ss;
	int lineCounter = 0;
	for (int i = 0; i < size; i++) {
		ss << array[i];
		lineCounter++;
		if (i < size - 1 && lineCounter != 10) {
			ss << " ";
		}
		if (lineCounter == 10) {
			lineCounter = 0;
			ss << "\n";
		}
	}
	return ss.str();
}

MyArray::Iterator MyArray::begin()
{
	Iterator itr(array, size, 0, incrementMode());
	if (!itr.isValidIndex()) {
		++itr;
	}
	return itr;
}

MyArray::Iterator MyArray::end()
{
	return Iterator(array, size, size, currentMode);
}

MyArray::Mode MyArray::incrementMode()
{
	switch (currentMode) {
	case SEQUENTIAL:
		currentMode = PRIME;
		return SEQUENTIAL;
	case PRIME:
		currentMode = COMPOSITE;
		return PRIME;
	case COMPOSITE:
		currentMode = FIBINOCCI;
		return COMPOSITE;
	case FIBINOCCI:
		currentMode = SEQUENTIAL;
		return FIBINOCCI;
	default:
		return SEQUENTIAL;
	}
}

std::ostream & operator<<(std::ostream & os, MyArray::Iterator & myclass)
{
	os << myclass.toString();
	return os;
}

std::ostream & operator<<(std::ostream & os, MyArray & myclass)
{
	os << myclass.toString();
	return os;
}

MyArray::Iterator::Iterator()
{
}

MyArray::Iterator::Iterator(int * array, int size, int index, Mode mode)
{
	this->array = array;
	this->size = size;
	this->index = index;
	this->mode = mode;
}

MyArray::Iterator::~Iterator()
{
}

string MyArray::Iterator::toString() const
{
	std::stringstream ss;
	ss << "size=" << size << " index=" << index << " mode=" << mode;
	return ss.str();
}

bool isPrime(int num) {
	if (num == 1) {
		return false;
	}
	bool flag = true;
	for (int i = 2; i <= num / 2; i++) {
		if (num % i == 0) {
			flag = false;
			break;
		}
	}
	return flag;
}
bool MyArray::Iterator::isValidIndex()
{
	if (index > size) {
		throw std::out_of_range("too big");
	}
	int oneBehind = 0;
	int twoBehind = 0;
	switch (mode) {
	case SEQUENTIAL:
		return true;
	case PRIME:
		if (isPrime(array[index])) {
			return true;
		}
		return false;
	case COMPOSITE:
		if (isPrime(array[index])) {
			return false;
		}
		return true;
	case FIBINOCCI:
		if (index > 0) oneBehind = array[index - 1];
		if (index > 1) twoBehind = array[index - 2];
		if (array[index] == oneBehind + twoBehind) {
			return true;
		}
		return false;
	default:
		return true;
	}
}

void MyArray::Iterator::operator++()
{
	do {
		index++;
	} while (index < size && !isValidIndex());
}

void MyArray::Iterator::operator--()
{
	index--;
}

int MyArray::Iterator::operator*()
{
	if (index < 0) return 0;
	return array[index];
}

bool MyArray::Iterator::operator==(const Iterator & that)
{
	if (this->array != that.array) return false;
	if (this->index != that.index) return false;
	return true;
}

bool MyArray::Iterator::operator!=(const Iterator & that)
{
	return !(*this==that);
}

int & MyArray::Iterator::operator[](const int ind)
{
	return array[index + ind];
}

