#include <iostream>
#include <string>

using namespace std;

int main() {
	string name;

	cout << "Enter your name" << endl;
	getline(cin, name);
	cout << endl;
	cout << "Hello " << name << ", have a great day.";
	cout << endl;

	return 0;
}