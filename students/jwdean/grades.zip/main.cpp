/*
Unnamed Programmer
Description: This program gets the exam scores of a class from a text file and prints
in another text file exam avergaes, the students exam scores and grades and the students
final grades.
*/

#include <iostream>
#include <fstream>
#include <string>
#include <sstream>
#include <iomanip>
#include <limits>

using namespace std;

#ifdef _MSC_VER
#define _CRTDBG_MAP_ALLOC  
#include <crtdbg.h>
#define VS_MEM_CHECK _CrtSetDbgFlag(_CRTDBG_ALLOC_MEM_DF | _CRTDBG_LEAK_CHECK_DF);
#else
#define VS_MEM_CHECK
#endif

int main(int argc, char* argv[])
{
	VS_MEM_CHECK	// check for memory leaks

	int numStudents = 0;
	int numExams = 0;
	string* students;
	int** scores;
	char** grades;
	string line;
	double total = 0.0;
	double grandTotal = 0.0;
	double average = 0.0;
	double endAverage = 0.0;
	int numA = 0;
	int numB = 0;
	int numC = 0;
	int numD = 0;
	int numE = 0;
	char grade = '*';
	
	//opens input file and output file using command line arguments
	if (argc < 3)
	{
		cerr << "Please provide name of input and output files";
		return 1;
	}
	cout << "Input file: " << argv[1] << endl;
	ifstream in(argv[1]);
	if (!in)
	{
		cerr << "Unable to open " << argv[1] << " for input";
		return 1;
	}
	cout << "Output file: " << argv[2] << endl;
	ofstream out(argv[2]);
	if (!out)
	{
		in.close();
		cerr << "Unable to open " << argv[2] << " for output";
	}
	in >> numStudents >> numExams;
	in.ignore(numeric_limits<streamsize>::max(), '\n');

	//declares dynamic arrays for exam scores and exam grades
	students = new string[numStudents];
	scores = new int*[numStudents];
	for (int i = 0; i < numStudents; ++i) 
	{
		scores[i] = new int[numExams];
	}
	grades = new char*[numStudents];
	for (int i = 0; i < numStudents; ++i) 
	{
		grades[i] = new char[numExams];
	}

	//reads exam scores in from text file
	for (int i = 0; i < numStudents; ++i)
	{
		getline(in, line);
		size_t p = 0;
		while (!isdigit(line[p]))
		{
			++p;
		}
		string numbers = line.substr(p);
		istringstream iss(numbers);
		students[i] = line.substr(0, p - 2);
		for (int j = 0; j < numExams; ++j) 
		{
			iss >> scores[i][j];
		}
	}

	//outputs the exam averages and calculates how many students earned each grade
	out << "Exam Averages:" << endl;
	for (int i = 0; i < numExams; ++i)
	{
		total = 0.0;
		numA = 0;
		numB = 0;
		numC = 0;
		numD = 0;
		numE = 0;
		for (int j = 0; j < numStudents; ++j)
		{
			total += scores[j][i];
		}
		average = total / numStudents;
		grandTotal += average;
		out << fixed << setprecision(1);
		out << "Exam  " << i + 1 << " average =" << average;
		for (int j = 0; j < numStudents; ++j)
		{
			if (scores[j][i] > average + 15)
			{
				grades[j][i] = 'A';
				numA++;
			}
			else if (scores[j][i] > average + 5)
			{
				grades[j][i] = 'B';
				numB++;
			}
			else if (scores[j][i] < average - 15)
			{
				grades[j][i] = 'E';
				numE++;
			}
			else if (scores[j][i] < average - 5)
			{
				grades[j][i] = 'D';
				numD++;
			}
			else 
			{
				grades[j][i] = 'C';
				numC++;
			}
		}
		out << setw(5) << numA << "(A)";
		out << setw(5) << numB << "(B)";
		out << setw(5) << numC << "(C)";
		out << setw(5) << numD << "(D)";
		out << setw(5) << numE << "(E)";
		out << endl;
	}

	//outputs students exam scores and grades on each exam
	out << endl << "Student Exam Grades:" << endl;
	for (int i = 0; i < numStudents; ++i)
	{
		out << setw(20) << students[i];
		for (int j = 0; j < numExams; ++j)
		{
			out << fixed << setprecision(0) << setw(6) << scores[i][j] << "(" << grades[i][j] << ")";
		}
		out << endl;
	}
	
	//outputs students final averages and grades
	endAverage = grandTotal / numExams;
	out << endl << "**BONUS**" << endl;
	out << fixed << setprecision(1) << "Class Average = " << endAverage << endl;
	out << "Student Final Exam Grade:" << endl;
	for (int i = 0; i < numStudents; ++i) 
	{
		out << setw(20) << students[i] << " ";
		total = 0.0;
		for (int j = 0; j < numExams; ++j)
		{
			total += scores[i][j];
		}
		average = total / numExams;
		if (average > endAverage + 15)
		{
			grade = 'A';
		}
		else if (average > endAverage + 5)
		{
			grade = 'B';
		}
		else if (average < endAverage - 15)
		{
			grade = 'E';
		}
		else if (average < endAverage - 5)
		{
			grade = 'D';
		}
		else
		{
			grade = 'C';
		}
		out << " " << average << "(" << grade << ")" << endl;
	}

	//clear memory
	for (int i = 0; i < numStudents; ++i)
	{
		delete[] grades[i];
	}
	delete[] grades;
	for (int i = 0; i < numStudents; ++i)
	{
		delete[] scores[i];
	}
	delete[] scores;
	delete[] students;

	return 0;
}