#include <iostream>

int main() {
	std::cout << "Hello World" << std::endl;
	system("pause");
	return 0;
}