#ifndef CR_H
#define CR_H
#include <string>
using namespace std;

class Cr : public Course
{
private:
	//	string course;
	string room;
public:
	Cr() : room("") { }
	Cr(const string courseName,
		const string room)
	{
		setCourseName(courseName);
		this->room = room;
	}

	//	string getCourse() const { return this->course; }
	//	void setCourse(string course) { this->course = course; }

	string getRoom() const { return this->room; }
	void setRoom(string room) { this->room = room; }

	string toString() const
	{
		stringstream out;
		out << "cr(" << getCourseName();
		out << "," << this->room << ")";
		return out.str();
	}

	friend std::ostream& operator<< (ostream& os, const Cr& cr)
	{
		os << cr.toString();
		return os;
	}
};
#endif // CR_H
