#ifndef SCHOOL_H
#define SCHOOL_H

#include <vector>
#include <set>
#include "Cdh.h"
#include "Course.h"
#include "Cr.h"
#include "Snap.h"
#include "Csg.h"

class School
{
public:
	School();
	~School();
	void addCdh(Cdh cdh);
	void addCourse(Course course);
	void addCr(Cr cr);
	void addSnap(Snap snap);
	void importStrings(const vector<string>& lines);
	string processLine(string line);
	void initializeCourses();
	string getVectors() const;
	string getCourseGrades() const;
	string getSchedules() const;

private:
	vector<vector<string>> vectors;
	vector<Cdh> cdhs;
	vector<Csg> csgs;
	vector<Course> courses;
	vector<Cr> crs;
	vector<Snap> snaps;
	set<string> courseNames;

	void createObject(vector<string> line);
	void createObjects();
	string getCourseDays(Course course) const;
	string getCourseTime(Course course) const;
	string getStudentName(string studentId) const;
	string getCourseRoom(Course course) const;
	vector<Csg> getCsgsFor(Course course) const;
	vector<Course> getCoursesFor(string studentId) const;
};

#endif