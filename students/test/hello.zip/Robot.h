/*
 * Robot.h
 *
 *  Created on: Sep 2, 2016
 *      Author: mike.liddle
 */

#ifndef ROBOT_H_
#define ROBOT_H_

#include "Fighter.h"

class Robot: public Fighter {
public:
	Robot(string name, int maxHP, int strength, int speed, int magic);
	int getDamage();
	bool useAbility();
	void reset();
private:
	int damageBonus;
	int energy;
	int maxEnergy;
};

#endif /* ROBOT_H_ */
