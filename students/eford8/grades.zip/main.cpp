
#ifdef _MSC_VER
#define _CRTDBG_MAP_ALLOC
#include <crtdbg.h>
#define VS_MEM_CHECK _CrtSetDbgFlag(_CRTDBG_ALLOC_MEM_DF | _CRTDBG_LEAK_CHECK_DF);
#else
#define VS_MEM_CHECK
#endif
#include <iostream>
#include <string>
#include <fstream>
#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <iomanip>
#include <math.h>
#include <limits>
using namespace std;

//takes in the average and the individual grade and determines its grade
char const LetterGrade (double average, int grade)
{
   if (average - grade <= 5 && average - grade >= -5)
   {
      return 'C';
   }
   else if (grade - average < 15 )
   {
      return 'B';
   }
   else if (average - grade < 15 )
   {
      return 'D';
   }
   else if (grade > average)
   {
      return 'A';
   }
   else
   {
      return 'E';
   }
}

int main(int argc, const char * argv[])
{
   VS_MEM_CHECK               // enable memory leak check
   if (argc < 3)
   {
      cerr << "Please provide name of input and output files";
      return 1;
   }
   cout << "Input file: " << argv[1] << endl;
   ifstream in(argv[1]);
   if (!in)
   {
      cerr << "Unable to open " << argv[1] << " for input";
      return 1;
   }
   cout << "Output file: " << argv[2] << endl;
   ofstream out(argv[2]);
   if (!out)
   {
      in.close();
      cerr << "Unable to open " << argv[2] << " for output";
   }
 
   int num_students;
   int num_exams;
   string first_name;
   string last_name;
   in >> num_students >> num_exams;
   // Skip the rest of the line
   cin.ignore(numeric_limits<streamsize>::max(), '\n');
   int rows = num_students;
   int cols = num_exams;
   int **myArray = new int*[rows];
   for(int i = 0; i < rows; ++i)
   {
      myArray[i] = new int[cols];
   }
   char **letterGrades = new char*[rows];
   for(int i = 0; i < rows; ++i)
   {
      letterGrades[i] = new char[cols];
   }
   string *names  = new string[num_students];
   
   //input all the values into the grades array and in the names array
   for (int i = 0; i < rows; i++)
   {
      in >> first_name >> last_name;
      names[i] = first_name +  " " + last_name;
      for (int j = 0; j < cols; j++)
      {
         in >> myArray[i][j];
      }
      // Skip the rest of the line
      cin.ignore(numeric_limits<streamsize>::max(), '\n');
   }
   
   //Display Exam Averages
   out << "Exam Averages:" << endl;
   int supremeTotal = 0;
   for (int i = 0; i < cols; i++)
   {
      int total = 0;
      for (int j = 0; j < rows; j++)
      {
         total += myArray[j][i];
         supremeTotal += myArray[j][i];
      }
      double average = total / (num_students * 1.0);
      out << "Exam" << "\t" << i + 1 << " average =" << fixed << setprecision(1) << average;
      int A = 0;
      int B = 0;
      int C = 0;
      int D = 0;
      int E = 0;
      for (int k = 0; k < rows; k++)
      {
         letterGrades[k][i] = LetterGrade(average, myArray[k][i]);
         if (letterGrades[k][i] == 'A')
         {
            A++;
         }
         else if (letterGrades[k][i] == 'B')
         {
            B++;
         }
         else if (letterGrades[k][i] == 'C')
         {
            C++;
         }
         else if (letterGrades[k][i] == 'D')
         {
            D++;
         }
         else
         {
            E++;
         }
      }
      out << "\t" << A << "(A)\t";
      out << "\t" << B << "(B)\t";
      out << "\t" << C << "(C)\t";
      out << "\t" << D << "(D)\t";
      out << "\t" << E << "(E)\t";
      out << endl;
   }
   //display student exam grades and their letter grades
   out << "Student Exam Grades:" << endl;
   for (int i = 0; i < rows; i++)
   {
      out << setw(20) << names[i];
      for (int j = 0; j < cols; j++)
      {
         out << setw(10) << myArray[i][j] << "(" << letterGrades[i][j] << ")";
      }
      out << endl;
   }
   
   // display the bonus work
   out << "**BONUS**" << endl;
   double supremeAverage = supremeTotal / (num_exams * num_students);
   out << "Class Average = " << setprecision(1) << supremeAverage << endl;
   out << "Student Final Exam Grade:" << endl;
   for (int i = 0; i < rows; i++)
   {
      int total = 0;
      for (int j = 0; j < cols; j++)
      {
         total += myArray[i][j];
      }
      double average = total / (num_exams * 1.0);
      out << setw(20) << names[i];
      out << setw(10) << average << "(" << LetterGrade(supremeAverage, average) << ")" << endl;
   }
   
   int* leak = new int;
   delete leak;
   return 0;
}

