/*
 * Archer.h
 *
 *  Created on: Sep 2, 2016
 *      Author: mike.liddle
 */

#ifndef ARCHER_H_
#define ARCHER_H_

#include "Fighter.h"

class Archer: public Fighter {
public:
	Archer(string name, int maxHP, int strength, int speed, int magic);
	int getDamage();
	bool useAbility();
	void reset();
private:
	int initialSpeed;
};

#endif /* ARCHER_H_ */
