#ifndef COURSE_H
#define COURSE_H
#include <string>
#include <sstream>

using namespace std;

class Course
{
public:
	Course(string name);
	~Course();

	friend std::ostream& operator<< (ostream& os, Course& course) {
		os << course.toString();
		return os;
	}

	string getCourseName() {
		return courseName;
	}

	virtual string toString() = 0;

protected:
	string courseName;
};

#endif