#include <iostream>
#include <fstream>
#include <iomanip>
#include <sstream>
using namespace std;

int main(int argc, const char* argv[])
{
    int numStudents = 0;
    int numExams = 0;
    int numAs = 0;
    int numBs = 0;
    int numCs = 0;
    int numDs = 0;
    int numEs = 0;
    double averageScore = 0.0;
    double averageScoreStudent = 0.0;
    string inputLine;
    string scoresLine;
    
    cout << "Input file: " << argv[1] << endl;
    ifstream in(argv[1]);
    if (!in)
    {
        cerr << "Unable to open " << argv[1] << " for input" << endl;
        return 1;
    }
    
    in >> numStudents >> numExams;
    string* listStudents = new string[numStudents];
    int** testScores = new int*[numStudents];
    in.ignore();
    
    for (int i = 0; i < numStudents; ++i)
    {
        getline(in, inputLine);
        size_t p = 0;
        while (!isdigit(inputLine[p])) ++p;
        listStudents[i] = inputLine.substr(0, p);
        
        testScores[i] = new int[numExams];
        scoresLine = inputLine.substr(p);
        istringstream inSS(scoresLine);
        for (int j = 0; j < numExams; ++j)
        {
            inSS >> testScores[i][j];
        }
    }
    
    cout << fixed << setprecision(1);
    double* testAverages = new double[numExams];
    
    for (int i = 0; i < numExams; ++i)
    {
        for (int j = 0; j < numStudents; ++j)
        {
            averageScore = averageScore + testScores[j][i];
        }
        averageScore = averageScore / numStudents;
        testAverages[i] = averageScore;
        averageScore = 0;
    }
    
    char** letterGrades = new char*[numStudents];
    for (int i = 0; i < numStudents; ++i)
    {
        letterGrades[i] = new char[numExams];
        for (int j = 0; j < numExams; ++j)
        {
            if (testScores[i][j] <= (testAverages[j] - 15))
            {
                letterGrades[i][j] = 'E';
            }
            else if (testScores[i][j] < (testAverages[j] - 5))
            {
                letterGrades[i][j] = 'D';
            }
            else if ((testScores[i][j] >= (testAverages[j] - 5)) && (testScores[i][j] <= (testAverages[j] + 5)))
            {
                letterGrades[i][j] = 'C';
            }
            else if (testScores[i][j] >= (testAverages[j] + 15))
            {
                letterGrades[i][j] = 'A';
            }
            else if (testScores[i][j] > (testAverages[j] + 5))
            {
                letterGrades[i][j] = 'B';
            }
        }
    }
    
    ofstream out(argv[2]);
    if (!out)
    {
        in.close();
        cerr << "Unable to open " << argv[2] << " for output";
    }
    
    out << "Exam Averages:" << endl;
    for (int i = 0; i < numExams; ++i)
    {
        for (int j = 0; j < numStudents; ++j)
        {
            if (letterGrades[j][i] == 'A')
            {
                ++numAs;
            }
            if (letterGrades[j][i] == 'B')
            {
                ++numBs;
            }
            if (letterGrades[j][i] == 'C')
            {
                ++numCs;
            }
            if (letterGrades[j][i] == 'D')
            {
                ++numDs;
            }
            if (letterGrades[j][i] == 'E')
            {
                ++numEs;
            }
        }
        out << fixed << setprecision(1) << "Exam " << i << " average =" << testAverages[i] << setw(5) << numAs << "(A)" << setw(5)
            << numBs << "(B)" << setw(5) << numCs << "(C)" << setw(5) << numDs << "(D)" << setw(5) << numEs << "(E)" << endl;
        
        numAs = 0;
        numBs = 0;
        numCs = 0;
        numDs = 0;
        numEs = 0;
    }
    
    out << endl;
    
    out << "Student Exam Grades:" << endl;
    for (int i = 0; i < numStudents; ++i)
    {
        out << setw(20) << listStudents[i];
        for (int j = 0; j < numExams; ++j)
        {
            out << setw(6) << testScores[i][j] << "(" << letterGrades[i][j] << ")";
        }
        out << endl;
    }
    
    out << endl;
    out << "**BONUS**" << endl;
    averageScore = 0;
    double* studentAverages = new double[numStudents];
    char* averageLetterGrade = new char[numStudents];
    
    for (int i = 0; i < numStudents; ++i)
    {
        for (int j = 0; j < numExams; ++j)
        {
            averageScore = averageScore + testScores[i][j];
            averageScoreStudent = averageScoreStudent + testScores[i][j];
        }
        studentAverages[i] = averageScoreStudent / numExams;
        averageScoreStudent = 0.0;
    }
    averageScore = averageScore / (numStudents * numExams);
    
    for (int i = 0; i < numStudents; ++i)
    {
        if (studentAverages[i] <= (averageScore - 15))
        {
            averageLetterGrade[i] = 'E';
        }
        else if (studentAverages[i] < (averageScore - 5))
        {
            averageLetterGrade[i] = 'D';
        }
        else if ((studentAverages[i] >= (averageScore - 5)) && (studentAverages[i] <= (averageScore + 5)))
        {
            averageLetterGrade[i] = 'C';
        }
        else if (studentAverages[i] >= (averageScore + 15))
        {
            averageLetterGrade[i] = 'A';
        }
        else if (studentAverages[i] > (averageScore + 5))
        {
            averageLetterGrade[i] = 'B';
        }
    }
    
    out << "Class Average = " << averageScore << endl;
    out << "Student Final Exam Grade:" << endl;
    for (int i = 0; i < numStudents; ++i)
    {
        out << setw(20) << listStudents[i] << "  " << studentAverages[i] << "(" << averageLetterGrade[i] << ")" << endl;
    }
    for (int i = 0; i < numStudents; ++i)
    {
        delete testScores[i];
    }
    return 0;
}
