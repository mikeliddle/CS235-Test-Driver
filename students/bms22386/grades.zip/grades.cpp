//The Product of Cheesecake

#include<iostream>
#include<fstream>
#include<string>
#include<sstream>
#include<iomanip>
using namespace std;

#ifdef _MSC_VER
#define _CRTDBG_MAP_ALLOC  
#include <crtdbg.h>
#define VS_MEM_CHECK _CrtSetDbgFlag(_CRTDBG_ALLOC_MEM_DF | _CRTDBG_LEAK_CHECK_DF);
#else
#define VS_MEM_CHECK
#endif

int main(int argc, char* argv[])
{
	VS_MEM_CHECK;
	//opening files
	if (argc < 3)
	{
		cerr << "Please provide name of input and output files";
		return 1;
	}
	cout << "Input file: " << argv[1] << endl;
	ifstream in(argv[1]);
	if (!in)
	{
		cerr << "Unable to open " << argv[1] << " for input";
		return 1;
	}
	cout << "Output file: " << argv[2] << endl;
	ofstream out(argv[2]);
	if (!out)
	{
		in.close();
		cerr << "Unable to open " << argv[2] << " for output";
	}

	//storing the number of students and exams
	int num_stu;
	int num_exam;
	const int MAX_LENGTH = 2140000000;

	in >> num_stu >> num_exam;
	in.ignore(MAX_LENGTH, '\n');

	//storing student names and exam scores
	string line;
	string* names = new string[num_stu];
	double** scores = new double*[num_stu];

	for (int s = 0; s < num_stu; s++)
	{
		scores[s] = new double[num_exam];
		getline(in, line);
		unsigned int p = 0;
		while (!isdigit(line[p])) ++p;
		names[s] = line.substr(0, p - 2);

		line = line.substr(p);
		istringstream iss(line);
		for (int x = 0; x < num_exam; x++) iss >> scores[s][x];
	}

	//outputing exam averages
	out << "Exam Averages:\n" << fixed << setprecision(1);
	double* average = new double[num_exam];
	const int NUM_GRADE_LETTERS = 5;
	int numOfGrade[NUM_GRADE_LETTERS] = {0};
	char gradeLetters[NUM_GRADE_LETTERS] = {'A','B','C','D','E'};

	for (int x = 0; x < num_exam; x++)
	{
		average[x] = 0;
		for (int s = 0; s < num_stu; s++) average[x] += scores[s][x];
		average[x] /= num_stu;

		for (int s = 0; s < num_stu; s++)
		{
			if (scores[s][x] >= average[x] + 15) numOfGrade[0]++;
			else if (scores[s][x] > average[x] + 5) numOfGrade[1]++;
			else if (scores[s][x] >= average[x] - 5) numOfGrade[2]++;
			else if (scores[s][x] > average[x] - 15) numOfGrade[3]++;
			else numOfGrade[4]++;
		}
		out << "Exam  " << x << " average =" << average[x];
		for (int g = 0; g < NUM_GRADE_LETTERS; g++)
		{
			out << setw(5) << numOfGrade[g] << "(" << gradeLetters[g] << ")";
			numOfGrade[g] = 0;
		}
		out << endl;
	}
	
	//outputting student's grades
	out << "\nStudent Exam Grades:\n" << setprecision(0);
	for (int s = 0; s < num_stu; s++)
	{
		out << setw(20) << names[s];
		for (int x = 0; x < num_exam; x++)
		{
			out << setw(6) << scores[s][x];
			if (scores[s][x] >= average[x] + 15) out << "(" << gradeLetters[0] << ")";
			else if (scores[s][x] > average[x] + 5) out << "(" << gradeLetters[1] << ")";
			else if (scores[s][x] >= average[x] - 5) out << "(" << gradeLetters[2] << ")";
			else if (scores[s][x] > average[x] - 15) out << "(" << gradeLetters[3] << ")";
			else out << "(" << gradeLetters[4] << ")";
		}
		out << endl;
	}

	//outputting class average and student final grades
	out << "\n**BONUS**\n";
	double classAverage = 0.0;
	for (int x = 0; x < num_exam; x++) classAverage += average[x];
	classAverage /= num_exam;
	out << setprecision(1) << "Class Average = " << classAverage;

	out << "\nStudent Final Exam Grade:";
	for (int s = 0; s < num_stu; s++)
	{
		double studentAverage = 0.0;
		for (int x = 0; x < num_exam; x++) studentAverage += scores[s][x];
		studentAverage /= num_exam;

		out << endl << setw(20) << names[s] << setw(6) << studentAverage;
		if (studentAverage >= classAverage + 15) out << "(" << gradeLetters[0] << ")";
		else if (studentAverage > classAverage + 5) out << "(" << gradeLetters[1] << ")";
		else if (studentAverage >= classAverage - 5) out << "(" << gradeLetters[2] << ")";
		else if (studentAverage > classAverage - 15) out << "(" << gradeLetters[3] << ")";
		else out << "(" << gradeLetters[4] << ")";
	}

	//closing files and clearing memory leaks
	in.close();
	out.close();
	delete[] names;
	for (int s = 0; s < num_stu; s++) delete[] scores[s];
	delete[] scores;
	delete[] average;

	return 0;
}