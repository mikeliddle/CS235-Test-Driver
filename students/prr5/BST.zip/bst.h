#ifndef BST_H
#define BST_H

template<typename T>
struct Node
{
	T data;
	Node<T>* left;
	Node<T>* right;
	Node<T>(T d) : left(NULL), right(NULL) { this->data = d; }
	//Node<T>(T d) { this->data = d; this->left = NULL; this->right = NULL; }
};


/** A binary tree node with data, left and right child pointers */
template<typename T>
class BST
{
private:
	Node<T>* root;

	/** Output nodes at a given level */
	bool outLevel(Node<T>* root, int level, stringstream& out) const
	{
		if (root == NULL) return false;
		if (level == 0)
		{
			out << " " << root->data;
			if ((root->left != NULL) || (root->right != NULL)) return true;
			return false;
		}
		bool left = outLevel(root->left, level - 1, out);
		bool right = outLevel(root->right, level - 1, out);
		return left || right;
	} // end outLevel()

	/** Recursive delete subtree beginning with node */
	void deleteTree(Node<T>* node)
	{
		if (node == NULL) return;

		// first delete both subtrees
		deleteTree(node->left);
		deleteTree(node->right);

		// then delete the node
		//cout << endl << "Deleting node: " << node->data;
		delete(node);
	} // end deleteSubTree

	/** Recursive insert data node into BST */
	bool insert(Node<T>*& node, const T& data)
	{
		if (node == NULL)
		{
			node = new Node<T>(data);
			return true;
		}
		if (data == node->data) return false;
		if (data < node->data)
		{
			return insert(node->left, data);
		}
		return insert(node->right, data);
	} // end insert

	/** Recursive replace node in BST */
	void replace_parent(Node<T>*& oldNode, Node<T>*& newNode)
	{
		if (newNode->right != NULL)
		{
			replace_parent(oldNode, newNode->right);
		}
		else
		{
			oldNode->data = newNode->data;
			oldNode = newNode;
			newNode = oldNode->left;

		}
		return;
	} // end replace_parent

	/** Recursive delete node in BST */
	bool remove(Node<T>*& node, const T& data)
	{
		if (node == NULL)
		{
			return false;
		}
		if (data < node->data)
		{
			return remove(node->left, data);
		}
		if (data > node->data)
		{
			return remove(node->right, data);
		}
		// node found
		Node<T>* oldNode = node;
		if (node->left == NULL)
		{
			node = node->right;
		}
		else if (node->right == NULL)
		{
			node = node->left;
		}
		else
		{
			replace_parent(oldNode, oldNode->left);
		}
		delete oldNode;
		return true;
	} // end remove

public:
	BST() { this->root = NULL; }
	~BST() { clearTree(); }
	bool addNode(const T& data) { return insert(this->root, data); }
	bool removeNode(const T& data) { return remove(this->root, data); }
	bool clearTree() { deleteTree(root); root = NULL;  return true; }

	/** Return a level order traversal of a BST as a string */
	string toString() const
	{
		stringstream out;
		if (root == NULL) out << " Empty";
		else
		{
			int level = -1;
			do
			{
				out << endl << "  " << ++level << ":";
			} while (outLevel(root, level, out));
		}
		return out.str();
	} // end toString()

	/** Override insertion operator to insert BST string */
	friend std::ostream& operator<< (ostream& os, const BST<T>& bst)
	{
		os << bst.toString();
		return os;
	} // end operator<<

};

#endif	// BST_H
