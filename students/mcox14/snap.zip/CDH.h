#ifndef CDH_H
#define CDH_H
#include "Course.h"
class CDH : public Course
{
public:
	CDH(string name, string day, string time);
	~CDH();
	string getClassDay() {
		return classDay;
	}

	string getClassTime() {
		return classTime;
	}

	string toString();

private:
	string classDay;
	string classTime;
};
#endif
