#include <iostream>
#include <string>
#include <sstream>
#include <fstream>

#define TEST_NUM	1
#define CONSOLE		1
#define DEBUG		1
#define MAX_ARRAY_SIZE	1000
enum myMode { SEQUENTIAL, PRIME, COMPOSITE, FIB };

using namespace std;
#include "myArray.h"

#ifdef _MSC_VER
#define _CRTDBG_MAP_ALLOC  
#include <crtdbg.h>
#define VS_MEM_CHECK _CrtSetDbgFlag(_CRTDBG_ALLOC_MEM_DF | _CRTDBG_LEAK_CHECK_DF);
#else
#define VS_MEM_CHECK;
#endif

typedef struct
{
	char* input;
	char* output;
} Tests;

Tests tests[] = { { "lab03_in_00.txt", "lab03_out_00.txt" },
{ "lab03_in_01.txt", "lab03_out_01.txt" },
{ "lab03_in_02.txt", "lab03_out_02.txt" },
{ "lab03_in_03.txt", "lab03_out_03.txt" }
};

int main(int argc, char * argv[])
{
	VS_MEM_CHECK;
	MyArray<int> numbers(MAX_ARRAY_SIZE);
#if 0
	if (argc < 3)
	{
		cerr << "Please provide name of input and output files\n";
		return 1;
	}
	cout << "Input File: " << argv[1] << endl;
	ifstream in(argv[1]);
	if (!in)
	{
		cerr << "Unable to open " << argv[1] << " for input\n";
		return 1;
	}
	cout << "Output File: " << argv[2] << endl;
	ofstream out(argv[2]);
	if (!out)
	{
		in.close();
		cerr << "Unable to open " << argv[2] << " for output\n";
	}
#else
	cout << "Input File: " << tests[TEST_NUM].input << endl;
	ifstream in(tests[TEST_NUM].input);

	cout << "Output File: " << tests[TEST_NUM].output << endl;
	std::ostream& out = (CONSOLE) ? std::cout : *(new std::ofstream(tests[TEST_NUM].output));
	out << endl << endl;
#endif

	int i;
	while (in >> i)
	{
		numbers.push_back(i);
	}
	out << numbers << endl << endl;

	out << "SEQUENTIAL" << endl;
	MyArray<int>::Iterator iter1 = numbers.begin();
	out << "iter1: " << iter1 << endl;
	for (; iter1 != numbers.end(); ++iter1)
		out << *iter1 << ' ';
	out << endl << endl;

	out << "PRIME" << endl;
	MyArray<int>::Iterator iter2 = numbers.begin(PRIME);
	out << "iter2: " << iter2 << endl;
	for (; iter2 != numbers.end(); ++iter2)
		out << *iter2 << ' ';
	out << endl << endl;

	out << "COMPOSITE" << endl;
	MyArray<int>::Iterator iter3 = numbers.begin(COMPOSITE);
	out << "iter3: " << iter3 << endl;
	for (; iter3 != numbers.end(); ++iter3)
		out << *iter3 << ' ';
	out << endl << endl;

	out << "FIBINOCCI" << endl;
	MyArray<int>::Iterator iter4 = numbers.begin(FIB);
	out << "iter4: " << iter4 << endl;
	for (; iter4 != numbers.end(); ++iter4)
		out << *iter4 << "=" << iter4[-2] << "+" << iter4[-1] << ' ';
	out << endl << endl;

	return 0;
}