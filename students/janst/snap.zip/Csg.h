#pragma once
#include "Course.h"

class Csg : virtual public Course {
	std::string studentID;
	std::string studentGrade;
	std::string toString() override;

public:
	Csg();

	Csg(std::string, std::string, std::string);

	friend std::ostream& operator<< (std::ostream& os, Csg& myclass)
	{
		os << myclass.toString();
		return os;
	}

	std::string getStudentID();

	std::string getStudentGrade();
};