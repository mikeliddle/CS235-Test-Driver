//
//  main.cpp
//  HelloWorld
//
//  Created by Andrew Neville on 8/31/16.
//  Copyright © 2016 Andrew Neville. All rights reserved.
//

#include <iostream>

using namespace std;

int main() {
    cout << "Enter a one-word greeting: ";
    string greeting;
    cin >> greeting;
    cout << greeting << endl;
    return 0;
}
