#include "School.h"
#include <sstream>
#include <set>

School::School()
{
}


School::~School()
{
}

void School::addCdh(Cdh cdh)
{
	cdhs.push_back(cdh);
}

void School::addCourse(Course course)
{
	courses.push_back(course);
}

void School::addCr(Cr cr)
{
	crs.push_back(cr);
}

void School::addSnap(Snap snap)
{
	snaps.push_back(snap);
}

void School::importStrings(const vector<string>& lines)
{
	for (int i = 0; i < lines.size(); i++) {
		vector<string> arguments;
		string nextArg = "";
		for (int j = 0; j < lines.at(i).length(); j++) {
			if (lines.at(i).at(j) == '.') continue;
			if (lines.at(i).at(j) == '(' || lines.at(i).at(j) == ')' || lines.at(i).at(j) == ',') {
				if (nextArg != "");
					arguments.push_back(nextArg);
				nextArg = "";
			}
			else {
				nextArg.push_back(lines.at(i).at(j));
			}
		}
		vectors.push_back(arguments);
	}
	createObjects();
}

string School::processLine(string line)
{
	vector<string> arguments;
	string nextArg = "";
	for (int j = 0; j < line.length(); j++) {
		if (line.at(j) == '.') continue;
		if (line.at(j) == '(' || line.at(j) == ')' || line.at(j) == ',') {
			if (nextArg != "");
			arguments.push_back(nextArg);
			nextArg = "";
		}
		else {
			nextArg.push_back(line.at(j));
		}
	}
	try {
		createObject(arguments);
		vectors.push_back(arguments);
		return line;
	}
	catch (string message) {
		return line + " ** " + message + " " + line;
	}
	
}

void School::initializeCourses()
{
	for (string name : courseNames) {
		courses.push_back(Course(name));
	}
}

string School::getVectors() const
{
	stringstream ss;
	for (Snap snap : snaps) {
		ss << snap << "\n";
	}
	for (Csg csg : csgs) {
		ss << csg << "\n";
	}
	for (Cdh cdh : cdhs) {
		ss << cdh << "\n";
	}
	for (Cr cr : crs) {
		ss << cr << "\n";
	}
	//for (vector<string> vec : vectors) {
	//	for (int i = 0; i < vec.size(); i++) {
	//		if (i == 0) {
	//			ss << vec.at(i) << "(";
	//		}
	//		else if (i == vec.size() - 1) {
	//			ss << vec.at(i) << ")";
	//		}
	//		else {
	//			ss << vec.at(i) << ",";
	//		}
	//	}
	//	ss << "\n";
	//}
	return ss.str();
}

string School::getCourseGrades() const
{
	stringstream out;
	for (Course course : courses) {
		string courseName = course.getCourseName();
		string room = getCourseRoom(course);
		string days = getCourseDays(course);
		vector<Csg> grades = getCsgsFor(course);
		for (Csg csg : grades) {
			string studentName = getStudentName(csg.getStudentID());
			out << courseName << " " << days << ", " << room << " " << studentName << " " << csg.getStudentID() << ", " << csg.getStudentGrade() << "\n";
		}
		if (grades.size() > 0) out << "\n";
	}
	return out.str();
}

string School::getSchedules() const
{
	stringstream out;
	for (Snap snap : snaps) {
		string studentName = snap.getStudentName();
		string studentId = snap.getStudentID();
		string address = snap.getStudentAddress();
		string phone = snap.getStudentPhone();
		vector<Course> studentCourses = getCoursesFor(studentId);
		for (Course course : studentCourses) {
			string days = getCourseDays(course);
			string room = getCourseRoom(course);
			string time = getCourseTime(course);
			out << studentName << ", " << studentId << ", " << address << ", " << phone << ", "
				<< course.getCourseName() << " " << days << " " << time << ", " << room << "\n";
		}
		if (studentCourses.size() > 0) {
			out << "\n";
		}
	}
	return out.str();
}

string School::getCourseDays(Course course) const
{
	stringstream ss;
	for (Cdh cdh : cdhs) {
		if (cdh.getCourseName() == course.getCourseName()) {
			ss << cdh.getDay();
		}
	}
	return ss.str();
}

string School::getCourseTime(Course course) const
{
	for (Cdh cdh : cdhs) {
		if (cdh.getCourseName() == course.getCourseName()) {
			return cdh.getTime();
		}
	}
	return "No time";
}

string School::getStudentName(string studentId) const
{
	for (Snap snap : snaps) {
		if (snap.getStudentID() == studentId) {
			return snap.getStudentName();
		}
	}
	return "No name";
}

string School::getCourseRoom(Course course) const
{
	for (Cr cr : crs) {
		if (cr.getCourseName() == course.getCourseName()) {
			return cr.getRoom();
		}
	}
	return "No room";
}

vector<Csg> School::getCsgsFor(Course course) const
{
	vector<Csg> courseGrades;
	for (Csg csg : csgs) {
		if (csg.getCourseName() == course.getCourseName()) {
			courseGrades.push_back(csg);
		}
	}
	return courseGrades;
}

vector<Course> School::getCoursesFor(string studentId) const
{
	vector<Course> studentCourses;
	for (Csg csg : csgs) {
		if (csg.getStudentID() == studentId) {
			studentCourses.push_back(Course(csg.getCourseName()));
		}
	}
	return studentCourses;
}



void School::createObject(vector<string> line)
{
	if (line.size() < 1) {
		throw string("Undefined");
	}
	else if (line.at(0) == "snap") {
		if (line.size() != 5) {
			throw string("Undefined");
		}
		else {
			snaps.push_back(Snap(line.at(1), line.at(2), line.at(3), line.at(4)));
		}
	}
	else if (line.at(0) == "cr") {
		if (line.size() != 3) {
			throw string("Undefined");
		}
		else {
			crs.push_back(Cr(line.at(1), line.at(2)));
			courseNames.insert(line.at(1));
		}
	}
	else {
		if (line.size() != 4) {
			throw string("Undefined");
		}
		else if (line.at(0) == "cdh") {
			cdhs.push_back(Cdh(line.at(1), line.at(2), line.at(3)));
			courseNames.insert(line.at(1));
		}
		else if (line.at(0) == "csg") {
			csgs.push_back(Csg(line.at(1), line.at(2), line.at(3)));
			courseNames.insert(line.at(1));
		}
		else {
			throw string("Undefined");
		}
	}
}

void School::createObjects()
{
	set<string> courseNames;
	for (int i = 0; i < vectors.size(); i++) {
		if (vectors.at(i).size() < 1) {
			vectors.erase(vectors.begin() + i);
			i--;
		}
		else if (vectors.at(i).at(0) == "snap") {
			if (vectors.at(i).size() != 5) {
				vectors.erase(vectors.begin() + i);
				i--;
			}
			else {
				snaps.push_back(Snap(vectors.at(i).at(1), vectors.at(i).at(2), vectors.at(i).at(3), vectors.at(i).at(4)));
			}
		}
		else if (vectors.at(i).at(0) == "cr") {
			if (vectors.at(i).size() != 3) {
				vectors.erase(vectors.begin() + i);
				i--;
			}
			else {
				crs.push_back(Cr(vectors.at(i).at(1), vectors.at(i).at(2)));
				courseNames.insert(vectors.at(i).at(1));
			}
		}
		else {
			if (vectors.at(i).size() != 4) {
				vectors.erase(vectors.begin() + i);
				i--;
			}
			else if (vectors.at(i).at(0) == "cdh") {
				cdhs.push_back(Cdh(vectors.at(i).at(1), vectors.at(i).at(2), vectors.at(i).at(3)));
				courseNames.insert(vectors.at(i).at(1));
			}
			else if (vectors.at(i).at(0) == "csg") {
				csgs.push_back(Csg(vectors.at(i).at(1), vectors.at(i).at(2), vectors.at(i).at(3)));
				courseNames.insert(vectors.at(i).at(1));
			}
			else {
				vectors.erase(vectors.begin() + i);
				i--;
			}
		}
	}
	for (string name : courseNames) {
		courses.push_back(Course(name));
	}
}
