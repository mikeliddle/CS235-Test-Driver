#pragma once
#include <string>
#include <iostream>
#include <sstream>

class Snap {

protected:
	std::string studentID;
	std::string studentName;
	std::string studentAddress;
	std::string studentPhone;



public:
	Snap();

	Snap(std::string, std::string, std::string, std::string);

	std::string toString() const;

	friend std::ostream& operator<< (std::ostream& os, Snap& myclass)//remove const
	{
		os << myclass.toString();
		return os;
	}

	std::string getStudentID();
	std::string getStudentName();
	std::string getStudentAddress();
	std::string getStudentPhone();

};