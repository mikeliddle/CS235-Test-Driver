/*
Created by James Peterson ^^
Sec 002
*/

#include <iostream>

using namespace std;

int main() {

	cout << "Hello World!" << endl;

	//system("pause");
	return 0;
}