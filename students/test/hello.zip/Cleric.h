/*
 * Cleric.h
 *
 *  Created on: Sep 2, 2016
 *      Author: mike.liddle
 */

#ifndef CLERIC_H_
#define CLERIC_H_

#include "Fighter.h"

class Cleric: public Fighter {
public:
	Cleric(string name, int maxHP, int strength, int speed, int magic);
	int getDamage();
	bool useAbility();
	void reset();
	void regenerate();
private:
	int maxMana;
	int mana;
};

#endif /* CLERIC_H_ */
