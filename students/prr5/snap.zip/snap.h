#ifndef SNAP_H
#define SNAP_H
#include <string>
using namespace std;

class Snap
{
private:
	string studentId;
	string studentName;
	string studentAddress;
	string studentPhone;
public:
	Snap() : studentId(""), studentName(""), studentAddress(""), studentPhone("") { }
	Snap(const string studentId,
		const string studentName,
		const string studentAddress,
		const string studentPhone)
	{
		this->studentId = studentId;
		this->studentName = studentName;
		this->studentAddress = studentAddress;
		this->studentPhone = studentPhone;
	}
	~Snap() = default;

	string getStudentName() const { return this->studentName; }
	void setStudentName(string name) { this->studentName = studentName; }

	string getStudentId() const { return this->studentId; }
	void setStudentId(string studentId) { this->studentId = studentId; }

	string getStudentAddress() const { return this->studentAddress; }
	void setStudentAddress(string studentAddress) { this->studentId = studentAddress; }

	string getStudentPhone() const { return this->studentPhone; }
	void setStudentPhone(string studentPhone) { this->studentPhone = studentPhone; }

	string toString() const
	{
		stringstream out;
		out << "snap(" << this->studentId;
		out << "," << this->studentName;
		out << "," << this->studentAddress;
		out << "," << this->studentPhone << ")";
		return out.str();
	}

	friend std::ostream& operator<< (ostream& os, const Snap& snap)
	{
		os << snap.toString();
		return os;
	}
};
#endif // SNAP_H
