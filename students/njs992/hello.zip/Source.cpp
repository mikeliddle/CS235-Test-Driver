#include <iostream>

int main() {
	std::cout << "Hello World...\r\n";

	return 0;
}