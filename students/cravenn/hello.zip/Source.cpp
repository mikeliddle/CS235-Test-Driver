/* Nathan Craven
Test the functionality of lab submissions and memory leak debugging.*/

#include <iostream>

using namespace std;

#ifdef _MSC_VER
#define _CRTDBG_MAP_ALLOC
#include <crtdbg.h>
#define VS_MEM_CHECK _CrtSetDbgFlag(_CRTDBG_ALLOC_MEM_DF | _CRTDBG_LEAK_CHECK_DF);
#else
#define VS_MEM_CHECK;
#endif

int main(int argc, char* argv[]) {
	VS_MEM_CHECK	// Check for memory leaks

	cout << "Hello World!" << endl;

	cout << "argc = " << argc << endl;
	if (argc > 1) {
		cout << "argv[1] = " << argv[1] << endl;
	}
	if (argc > 2) {
		cout << "arv[2] = " << argv[2] << endl;
	}

	int* leak = new int;

	delete leak;

	return 0;
}