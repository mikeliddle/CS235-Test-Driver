/** Program to assign grades to exam scores */

#include <iostream>
#include <fstream>
#include <string>
#include <sstream>
#include <limits>
#include <cmath>
#include <iomanip>
#include <map>
#include <vector>

using std::string;
using std::ifstream;
using std::ofstream;
using std::istringstream;
using std::cerr;
using std::endl;
using std::cout;


//void PrintFullPath(char * partialPath)
//{
//	char full[_MAX_PATH];
//	if (_fullpath(full, partialPath, _MAX_PATH) != NULL)
//		printf("Full path is: %s\n", full);
//	else
//		printf("Invalid path\n");
//}

/** Two dimensional array of scores
NOTE: Since C++ does not support dynamic
two dimensional arrays, we allocate
an array of pointers to pointers.
*/
double** scores;


int** letterGrades;


/** Function to assign a grade based on the average
@param score The score the student achieved
@param average The average for this exam
@return The grade
*/
string assign_grade(double score, double average, int num_exam)
{       string letterGrade = "";
        int letterIndex = 0;
        if (average - 5 <= score && score <= average + 5)
        {
                letterGrade = "C";
                letterIndex = 2;
        }
        else if (average - 15 <= score && score < average - 5)
        {
                letterGrade = "D";
                letterIndex = 3;
        }
        else if (score < average - 15)
        {
                letterGrade = "F";
                letterIndex = 4;
        }
        else if (average + 5 < score && score <= average + 15)
        {
                letterGrade = "B";
                letterIndex = 1;
        }
        else
        {
            letterGrade = "A";
            letterIndex = 0;
        }
        letterGrades[num_exam][letterIndex]++;
        return letterGrade;
}


/** Compute the average for an exam
@param exam The index of the exam in the array
@param num_students The number of students
*/
double compute_average(int exam, int num_students)
{
    cout<< "exam: " << exam << " numstudents: " << num_students <<endl;
        double sum = 0.0;
        for (int i = 0; i < num_students; i++){
                sum += scores[i][exam];
        cout<< scores[i][exam] << endl;}
        return sum / num_students;
}

string printTotals(int i, std::map<int, std::vector<int>> my_map)
{
    std::stringstream ss;
    ss << my_map[i][0] << "(A)" << std::setw(5) << my_map[i][1] << "(B)" << std::setw(5) << my_map[i][2] << "(C)" << std::setw(5) << my_map[i][3] << "(D)" << std::setw(5) << my_map[i][4] << "(F)";
    return ss.str();
}


int main(int argc, char* argv[]){
    //PrintFullPath(".\\");
    if (argc < 3)
    {
            cerr << "Please provide name of input and output files\n";
            return 1;
    }

    cout << "Input file: " << argv[1] << endl;
    ifstream in(argv[1]);
    if (!in)
    {
            cerr << "Unable to open " << argv[1] << " for input\n";
            return 1;
    }
    ofstream out(argv[2]);
    if (!out)
    {
            cerr << "Unable to open " << argv[2] << " for output\n";
    }
    std::map<int, std::vector<int>> gradeDistribution;
    int num_students;
    int num_exams;
    in >> num_students >> num_exams;
    // Skip the rest of the line
    in.ignore(std::numeric_limits<int>::max(), '\n');
    // Allocate space for grades;
    scores = new double*[num_students];
    letterGrades = new int*[num_exams];
    cout << "scores: " << &scores <<endl;

    for (int i = 0; i < num_students; i++)
    {
            scores[i] = new double[num_exams];
            cout << "score"<< i << ": " << &scores[i] <<endl;

    }
    //Allocate space for 5 letter types of letter types
    for (int i = 0; i < num_exams; i++){
            letterGrades[i] = new int[5];//0 corresponds to "A"...F
            for(int j = 0; j < 5; j++)
            {
                letterGrades[i][j] = 0;
            }
    }

    // Allocate space for student names
    string* names = new string[num_students];
    cout << "names: " << &names <<endl;
    // Read in student names and grades
    for (int i = 0; i < num_students; i++)
    {
            string line;
            getline(in, line);
            // Find the end of the student's name (first space before the first number)
            size_t p = 0;
            while (!isdigit(line[p])) ++p;
            // line[p] is the first digit
            while (isspace(line[--p])) {}
            // line[p] is last non-space before first digit
            ++p;
            // line[p] is character after the last non-space before first digit
            // get the student's name
            names[i] = line.substr(0, p);
            // get the rest of the line
            string rest = line.substr(p);
            // Put this into an istringstream
            istringstream iss(rest);
            for (int j = 0; j < num_exams; j++)
            {
                    iss >> scores[i][j];
            }
    }
    // Compute the average for each exam
    double* averages = new double[num_exams];
    cout << "averages: " << &averages <<endl;

    for (int i = 0; i < num_exams; i++)
    {       cout<< i << endl;
            cout<< "numexams: " << num_exams <<endl;
            averages[i] = compute_average(i, num_students);//FIXED (was passing in num_exams)
            cout << "Exam " << i << " average = " << averages[i] << endl;
    }



    // Output exam averages formatted
    out << "Exam Averages:" <<endl;
    for (int i = 0; i < num_exams; i++)
    {
            out << "Exam " << std::right << std::setw(3) << i + 1 << " average = ";
	    //int toInt = (int) round(averages[i]);//don't round anymore setprecision to 1
	    //out << toInt << " ";
	    out << std::fixed << std::setprecision(1) << averages[i] << "  ";
	    for(int k = 0; k < 5; k++)
	    {
	    	gradeDistribution[i].push_back(0);
	    }
	    for(int j = 0; j < num_students; j++)
	    {
		std::string my_grade = assign_grade(scores[j][i], averages[i], i);
	        if(my_grade == "A")
		{
			gradeDistribution[i][0] = gradeDistribution[i][0] + 1;
		}
		else if(my_grade == "B")
		{
			gradeDistribution[i][1] = gradeDistribution[i][1] + 1;
		}
		else if(my_grade == "C")
		{
			gradeDistribution[i][2] = gradeDistribution[i][2] + 1;
		}
		else if(my_grade == "D")
		{
			gradeDistribution[i][3] = gradeDistribution[i][3] + 1;
		}
		else if(my_grade == "F")
		{
			gradeDistribution[i][4] = gradeDistribution[i][4] + 1;
		}
	    }

	    out << std::setw(5) << printTotals(i, gradeDistribution);
            out << endl;
    }

    // Assign a grade for each exam and output formatted
    out << endl;
    out << "Student Exam Grades:" <<endl;
    for (int i = 0; i < num_students; i++)
    {
            out.width(20); out << std::right << names[i] << " ";
            for (int j = 0; j < num_exams; j++)
            {
                    out << std::setprecision(0) << std::setw(5) << scores[i][j] << "(";
                    out << assign_grade(scores[i][j], averages[j], j) << ") ";
            }
            out << endl;
    }

    // free new'd stuff
    for (int i = 0; i < num_students; i++)
    {
            delete[] scores[i];
    }
    delete[] names;
    delete[] scores;
    delete[] averages;
    out.close();
    in.close();
    return 0;
}
