#include <string>

using namespace std;

class Snap
{
public:
	Snap();
	Snap(const string idIn, const string nameIn, const string addressIn, const string phoneIn) :
		studentID(idIn), studentName(nameIn), studentAddress(addressIn), studentPhone(phoneIn) {};
	~Snap();
	string getStudentID() const;
	string getStudentName() const;
	string getStudentAddress() const;
	string getStudentPhone() const;
	void setStudentID(const string studentID);
	void setStudentName(const string studentName);
	void setStudentAddress(const string studentAddress);
	void setStudentPhone(const string studentPhone);
	string toString() const;
	friend std::ostream& operator<< (ostream& os, Snap& myclass);
private:
	string studentID;
	string studentName;
	string studentAddress;
	string studentPhone;
};

