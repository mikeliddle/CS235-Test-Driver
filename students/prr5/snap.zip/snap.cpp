//	L02-SNAP	2018-01-06
#include <iostream>
#include <fstream>
#include <string>
#include <sstream>
#include <limits>
#include <iomanip>      // std::setprecision
#include <vector>

#ifdef _MSC_VER
#define _CRTDBG_MAP_ALLOC  
#include <stdlib.h>
#include <crtdbg.h>
//#define VS_MEM_CHECK cout<<"Hello "<<_MSC_VER<<" "<<_CrtSetDbgFlag(_CRTDBG_REPORT_FLAG | _CRTDBG_CHECK_ALWAYS_DF | _CRTDBG_ALLOC_MEM_DF | _CRTDBG_LEAK_CHECK_DF)<<endl;
#define VS_MEM_CHECK _CrtSetDbgFlag(_CRTDBG_ALLOC_MEM_DF | _CRTDBG_LEAK_CHECK_DF);
//	VS_MEM_CHECK;				// enable memory leak check
//	_CrtSetBreakAlloc(xxxx);	// break @memory allocation xxxx
#else
#define VS_MEM_CHECK;
#endif

#define TEST_NUM	1
#define CONSOLE		1
#define DEBUG		1

using namespace std;
#include "course.h"
#include "snap.h"
#include "csg.h"
#include "cdh.h"
#include "cr.h"

typedef struct
{
	char* input;
	char* output;
} Tests;

Tests tests[] = {
	{ "lab02_in_00.txt", "lab02_out_00.txt" },
	{ "lab02_in_01.txt", "lab02_out_01.txt" },
	{ "lab02_in_02.txt", "lab02_out_02.txt" }
};

/** main
@param argc 3
@param argv[1]	input file
@param argv[2]	output file
@return 0
*/
int main(int argc, char* argv[])
{
	VS_MEM_CHECK;

#if (CONSOLE == 0)
	if (argc < 3)
	{
		cerr << "Please provide name of input and output files\n";
		return 1;
	}

	cout << "Input file: " << argv[1] << endl;
	ifstream in(argv[1]);
	if (!in)
	{
		cerr << "Unable to open " << argv[1] << " for input\n";
		return 1;
	}
	cout << "Output file: " << argv[2] << endl;
	ofstream out(argv[2]);
	if (!out)
	{
		in.close();
		cerr << "Unable to open " << argv[2] << " for output\n";
	}
#else
	cout << endl << "Input File: " << tests[TEST_NUM].input;
	ifstream in(tests[TEST_NUM].input);

	cout << endl << "Output File: " << tests[TEST_NUM].output;
	std::ostream& out = (CONSOLE) ? std::cout : *(new std::ofstream(tests[TEST_NUM].output));
#endif

	//	BEGIN;
	cout << endl << "Create vectors for Snaps, Csgs, Cdhs, and Crs" << endl << endl;
	vector<Snap> snaps;
	vector<Csg> csgs;
	vector<Cdh> cdhs;
	vector<Cr> crs;
	Snap* snap = new Snap();		// create memory leak
									//cout << endl << *snap;

	out << "Input Strings:";
	for (string line; getline(in, line);)	// Pass through all lines of code 
	{
		if (line.size() == 0) continue;
		out << endl << line;
		//		istringstream iss(line);
		//		iss >> code;
		try
		{
			if ("snap(" == line.substr(0, 5))
			{
				// snap('12345','C. Brown','12 Apple St.','555-1234').
				string studentId = line.substr(5, line.find(',') - 5);
				line = line.substr(line.find(',') + 1);
				string studentName = line.substr(0, line.find(','));
				line = line.substr(line.find(',') + 1);
				string studentAddress = line.substr(0, line.find(','));
				line = line.substr(line.find(',') + 1);
				string studentPhone = line.substr(0, line.find(')'));
				snaps.push_back(Snap(studentId, studentName, studentAddress, studentPhone));
			}

			else if ("csg(" == line.substr(0, 4))
			{
				// csg('CS101','12345','A').
				string courseName = line.substr(4, line.find(',') - 4);
				line = line.substr(line.find(',') + 1);
				string studentId = line.substr(0, line.find(','));
				line = line.substr(line.find(',') + 1);
				string studentGrade = line.substr(0, line.find(')'));
				csgs.push_back(Csg(courseName, studentId, studentGrade));
			}

			else if ("cdh(" == line.substr(0, 4))
			{
				// cdh('CS101','M','9AM').
				string courseName = line.substr(4, line.find(',') - 4);
				line = line.substr(line.find(',') + 1);
				string date = line.substr(0, line.find(','));
				line = line.substr(line.find(',') + 1);
				string time = line.substr(0, line.find(')'));
				cdhs.push_back(Cdh(courseName, date, time));
			}

			else if ("cr(" == line.substr(0, 3))
			{
				// cr('CS101','Turing Aud.').
				string courseName = line.substr(3, line.find(',') - 3);
				line = line.substr(line.find(',') + 1);
				string room = line.substr(0, line.find(')'));
				crs.push_back(Cr(courseName, room));
			}
			else
			{
				throw line;
			}
		}
		catch (string error)
		{
			out << " ** Undefined " << error;
		}
	}
	in.close();

	out << endl << endl << "Vectors:" << endl;
	for (unsigned int i = 0; i < snaps.size(); i++)
	{
		out << snaps[i] << endl;
	}

	for (unsigned int i = 0; i < csgs.size(); i++)
	{
		out << csgs[i] << endl;
	}

	for (unsigned int i = 0; i < cdhs.size(); i++)
	{
		out << cdhs[i] << endl;
	}

	for (unsigned int i = 0; i < crs.size(); i++)
	{
		out << crs[i] << endl;
	}

	out << endl << "Course Grades:" << endl;

	// CS101 MWF 1170 TMCB C. Brown A
	// CS101 MWF 1170 TMCB C. V. Van Pelt B
	// CS101 MWF 1170 TMCB C. Snoopy A-

	string startCourse = "";
	for (unsigned int i = 0; i < csgs.size(); i++)
	{
		if (startCourse != csgs[i].getCourseName())
		{
			out << endl;
			startCourse = csgs[i].getCourseName();
		}
		for (unsigned int j = 0; j < snaps.size(); j++)
		{
			if (csgs[i].getStudentId() == snaps[j].getStudentId())
			{
				out << csgs[i].getCourseName() << " ";
				for (unsigned k = 0; k < cdhs.size(); k++)
				{
					if (csgs[i].getCourseName() == cdhs[k].getCourseName())
					{
						out << cdhs[k].getDay();
					}
				}
				for (unsigned k = 0; k < crs.size(); k++)
				{
					if (csgs[i].getCourseName() == crs[k].getCourseName())
					{
						out << ", " << crs[k].getRoom();
					}
				}
				out << " " << snaps[j].getStudentName();
				out << " " << snaps[j].getStudentId();
				out << ", " << csgs[i].getStudentGrade();
				out << endl;
			}
		}
	}

	out << endl << "Student Schedules:" << endl;

	// Charles, 12345, 236 Apple, 321 - 7654, CS142 TTh 9:00am, 100 HFAC
	// Charles, 12345, 236 Apple, 321 - 7654, PHIL150 MWF 10:00am, 202 SWKT

	string startStudent = "";
	for (unsigned int i = 0; i < snaps.size(); i++)
	{
		if (startStudent != snaps[i].getStudentName())
		{
			out << endl;
			startStudent = snaps[i].getStudentName();
		}
		for (unsigned int j = 0; j < csgs.size(); j++)
		{
			if (snaps[i].getStudentId() == csgs[j].getStudentId())
			{
				out << snaps[i].getStudentName();
				out << ", " << snaps[i].getStudentId();
				out << ", " << snaps[i].getStudentAddress();
				out << ", " << snaps[i].getStudentPhone();
				out << ", " << csgs[j].getCourseName();
				out << " ";
				string time = "";
				for (unsigned k = 0; k < cdhs.size(); k++)
				{
					if (cdhs[k].getCourseName() == csgs[j].getCourseName())
					{
						out << cdhs[k].getDay();
						time = cdhs[k].getTime();
					}
				}
				out << " " << time;
				for (unsigned k = 0; k < crs.size(); k++)
				{
					if (crs[k].getCourseName() == csgs[j].getCourseName())
					{
						out << ", " << crs[k].getRoom();
					}
				}
				out << endl;
			}
		}
	}
#if !CONSOLE
	out.close();
#endif
	//	_CrtDumpMemoryLeaks();
	return 0;
}
