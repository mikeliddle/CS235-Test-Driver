#include "Csg.h"

const string DEFAULT_STUDENT_ID = "666";
const string DEFAULT_STUDENT_GRADE = "F+";

Csg::Csg()
{
	Course::Course();
	this->studentID = DEFAULT_STUDENT_ID;
	this->studentGrade = DEFAULT_STUDENT_GRADE;
}


Csg::~Csg()
{
}

string Csg::getStudentID()
{
	return this->studentID;
}

string Csg::getStudentGrade()
{
	return this->studentGrade;
}

void Csg::setStudentID(string studentID)
{
	this->studentID = studentID;
}

void Csg::setStudentGrade(string studentGrade)
{
	this->studentGrade = studentGrade;
}

string Csg::toString()
{
	return "csg(" + getCourseName() + "," + studentID + "," + studentGrade + ")";
}

std::ostream & operator<<(ostream & os, Csg & myclass)
{
	os << myclass.toString();
	return os;
}
