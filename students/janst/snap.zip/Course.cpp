#include "Course.h"

Course::Course() {}

Course::Course(std::string courseName)
{
	this->courseName = courseName;
}

std::string Course::toString() 
{
	return "";
}

std::string Course::getCourseName() const
{
	return courseName;
}



