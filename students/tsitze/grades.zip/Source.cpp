#include <iostream>
#include <iomanip>
#include <vector>
#include <string>
#include <cstdlib>
#include <fstream>
#include <sstream>

using namespace std;

#ifdef _MSC_VER												
#define _CRTDBG_MAP_ALLOC  
#include <crtdbg.h>
#define VS_MEM_CHECK _CrtSetDbgFlag(_CRTDBG_ALLOC_MEM_DF | _CRTDBG_LEAK_CHECK_DF);
#else
#define VS_MEM_CHECK;
#endif

void AverageScore(vector< vector<int> > examScores, string** grades, string** finalGrade, float** studentAverageScore, float** examAverages, int** numExamScores, float& classAverage, int numExams, int numStudents) {
	int numScores = 5;
	int averFinal = 0;
	double total1;
	double total2 = 0;

	for (int i = 0; i < numExams; i++) {		
		total1 = 0;
		for (int j = 0; j < numStudents; j++) {
			total1 += examScores[j][i];				
			total2 += examScores[j][i];
		}
		examAverages[i][0] = total1 / numStudents;			//average score for each individual exam among all the students
		
	}
	classAverage = total2 / (numExams * numStudents);			//average class score among all the exams
	


	for (int i = 0; i < numStudents; i++) {
		total1 = 0;
		for (int j = 0; j < numExams; j++) {
			total1 += examScores[i][j];
		}
		studentAverageScore[i][0] = total1 / numExams;		//final average student score among all the exams.
		averFinal += studentAverageScore[i][0];
	}
	averFinal = averFinal / numStudents;					//average combined score among all the students

	for (int i = 0; i < numExams; i++) {					//individual exam score for each student
		int averageS = examAverages[i][0];
		int score;

		for (int j = 0; j < numStudents; j++) {
			score = examScores[j][i];

			if (score > averageS + 15) {
				numExamScores[i][0]++;
				grades[j][i] = "A";
			}
			else if (score <= averageS + 15 && score > averageS + 5) {
				numExamScores[i][1]++;
				grades[j][i] = "B";
			}
			else if (score <= averageS + 5 && score > averageS - 5) {
				numExamScores[i][2]++;
				grades[j][i] = "C";
			}
			else if (score > averageS - 15 && score <= averageS - 5) {
				numExamScores[i][3]++;
				grades[j][i] = "D";
			}
			else if (score <= averageS - 15) {
				numExamScores[i][4]++;
				grades[j][i] = "F";
			}			
		}
	}



	for (int i = 0; i < numStudents; i++) {					//final combined grade for each student
		int fScore = studentAverageScore[i][0];
	
		if (fScore > averFinal + 15) {
			finalGrade[i][0] = "A";
		}
		else if (fScore <= averFinal + 15 && fScore > averFinal + 5) {
			finalGrade[i][0] = "B";
		}
		else if (fScore <= averFinal + 5 && fScore > averFinal - 5) {
			finalGrade[i][0] = "C";
		}
		else if (fScore > averFinal - 15 && fScore <= averFinal - 5) {
			finalGrade[i][0] = "D";
		}
		else if (fScore <= averFinal - 15) {
			finalGrade[i][0] = "F";
		}
	}
}



int main(int argc, char* argv[])	{
	VS_MEM_CHECK														// check for memory leaks

	if (argc < 3)	{
		cerr << "Please provide name of input and output files\n";
		return 1;
	}
	cout << "Input file: " << argv[1] << endl;							//read from designated input file
	ifstream exam(argv[1]);
	if (!exam)	{
		cerr << "Unable to open " << argv[1] << " for input\n";
		return 1;
	}



	stringstream ss;
	string temp;
	int numStudents;
	int numExams;

	getline(exam, temp);		//gather the first line and send to the appropriate variable type
	ss << temp;
	ss >> numStudents;
	ss >> numExams;
	ss.str(string());			//clear the ss variable for future use
	ss.clear();

	//Dynamic String and number arrays
	vector< vector<int> > examScores(numStudents, vector<int>(numExams));
	string *student = new string[numStudents];
	string **grades = new string*[numStudents];
	string **finalGrade = new string*[numStudents];
	float **examAverages = new float*[numExams];
	float **studentAverageScore = new float*[numStudents];
	int **numExamScores = new int*[numExams];

	//initialize the 2d arrays
	for (int i = 0; i < numStudents; ++i)	{
		grades[i] = new string[numExams];
		finalGrade[i] = new string[1];
		studentAverageScore[i] = new float[1];
	}
	for (int i = 0; i < numExams; ++i) {
		examAverages[i] = new float[1];
		numExamScores[i] = new int[5];
		for (int j = 0; j < 5; j++) {
			numExamScores[i][j] = 0;
		}
	}



	for (int stud = 0; stud < numStudents; stud++) {			//put the first and last names into a string array
		string temp;
		string fName;
		string lName;
		string name_;
		int examScore;

		cin.sync();
		getline(exam, temp);
		ss << temp;
		ss >> fName;
		ss >> lName;
		name_ = fName + " " + lName;
		student[stud] = name_;

		for (int score = 0; score < numExams; score++) {		//put the individual scores into a double array
			ss >> examScore;
			examScores[stud][score] = examScore;
		}
		ss.str(string());
		ss.clear();
	}



	float classAverage = 0;
	AverageScore(examScores, grades, finalGrade, studentAverageScore, examAverages, numExamScores, classAverage, numExams, numStudents);		//calculate all the scores and store the values
	
	cout << "Output file: " << argv[2] << endl;					//output scores to a .txt file
	ofstream exam_(argv[2]);
	if (!exam_) {
		exam.close();
		cerr << "Unable to open " << argv[2] << " for output\n";
	}



	exam_ << fixed << setprecision(1);
	exam_ << "Exam Averages:" << endl;
	
	for (int i = 0; i < numExams; i++) {
		exam_ << "Exam  " << i + 1 << " average = " << examAverages[i][0]
			<< "    " << numExamScores[i][0] << "(A)"
			<< "    " << numExamScores[i][1] << "(B)"
			<< "    " << numExamScores[i][2] << "(C)"
			<< "    " << numExamScores[i][3] << "(D)"
			<< "    " << numExamScores[i][4] << "(F)" << endl;
	}



	exam_ << endl << "Student Exam Grades:" << endl;
	for (int i = 0; i < numStudents; i++) {

		exam_ << setw(20) << right << student[i];

		for (int j = 0; j < numExams; j++) {

			exam_ << setw(7) << right << examScores[i][j] << "(" << grades[i][j] << ")";
		}
			exam_ << endl;
	}



	exam_ << endl << "Class Average = " << classAverage << endl;
	exam_ << "Student Final Exam Grade:" << endl;
	for (int i = 0; i < numStudents; i++) {
		exam_ << setw(20) << student[i]
			<< setw(7) << right << studentAverageScore[i][0] << "(" << finalGrade[i][0] <<")"
			<< endl;
	}
	

	//clear allocated memory
	for (int i = 0; i < numStudents; ++i) {
		delete[] grades[i];
		delete[] finalGrade[i];
		delete[] studentAverageScore[i];
	}
	delete[] student;
	delete[] grades;
	delete[] finalGrade;
	delete[] studentAverageScore;
	for (int i = 0; i < numExams; ++i) {
		delete[] examAverages[i];
		delete[] numExamScores[i];
	}
	delete[] examAverages;
	delete[] numExamScores;
	return 0;
}