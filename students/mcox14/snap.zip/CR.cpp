#include "CR.h"



CR::CR(string name = "", string room = "") : Course(name)
{
	classroom = room;
}


CR::~CR()
{
}

string CR::toString() {
	stringstream out;
	out << "cr(" << courseName << "," << classroom << ")";
	return out.str();
}