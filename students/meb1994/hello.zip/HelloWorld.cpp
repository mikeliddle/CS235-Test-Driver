#include <iostream>
#include <string>

using namespace std;

int main() {
   string myString = "Hello World";

   cout << myString;

   return 0;
}