#include "Cr.h"

Cr::Cr() {}

Cr::Cr(std::string courseName, std::string room) : Course(courseName)// there must be an explicit "this->" before "room = room"
{
	this->room = room;
}

//Ex. cr(CS101, 1170 TMCB)
std::string Cr::toString() {
	return "cr(" + courseName + "," + room + ")";
}

std::string Cr::getRoom()
{
	return room;
}