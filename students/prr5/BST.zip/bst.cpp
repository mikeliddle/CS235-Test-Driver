// Recursive C program for level order traversal of Binary Tree
#include <iostream>
#include <string>
#include <sstream>
#include <fstream>
#include <stdlib.h>
#include <iomanip>
using namespace std;
#include "bst.h"

#define TEST_NUM	5
#define CONSOLE		1
#define DEBUG		1

#define DEBUGX(x) cout << x;

#ifdef _MSC_VER
#define _CRTDBG_MAP_ALLOC  
#include <crtdbg.h>
#define VS_MEM_CHECK _CrtSetDbgFlag(_CRTDBG_ALLOC_MEM_DF | _CRTDBG_LEAK_CHECK_DF);
#else
#define VS_MEM_CHECK
#endif

typedef struct
{
	char* input;
	char* output;
} Tests;

Tests tests[] = { { (char*)"lab08_in_00.txt", (char*)"lab08_out_00.txt" },
{ (char*)"lab08_in_01.txt", (char*)"lab08_out_01.txt" },
{ (char*)"lab08_in_02.txt", (char*)"lab08_out_02.txt" },
{ (char*)"lab08_in_03.txt", (char*)"lab08_out_03.txt" },
{ (char*)"lab08_in_04.txt", (char*)"lab08_out_04.txt" },
{ (char*)"lab08_in_05.txt", (char*)"lab08_out_05.txt" }
};



/** Main program to test BST functions*/
int main()
{
	VS_MEM_CHECK				// enable memory leak check

	cout << endl << "Input File: " << tests[TEST_NUM].input;
	ifstream infile(tests[TEST_NUM].input);

	cout << endl << "Output File: " << tests[TEST_NUM].output << endl;
	std::ostream& out = (CONSOLE) ? std::cout : *(new std::ofstream(tests[TEST_NUM].output));

	BST<int> bst;					// instantiate BST
	//BST<string> bst;					// instantiate BST

									// process input strings
	for (string line; getline(infile, line);)
	{
		if (line.size() == 0) continue;
		istringstream iss(line);
		string item1;
		int data;
		//string data;
		iss >> item1;
		if (item1 == "Add")
		{
			iss >> data;
			out << endl << "Add " << data;
			if (bst.addNode(data)) out << " True";
			else  out << " False";
		}
		else if (item1 == "Remove")
		{
			iss >> data;
			out << endl << "Remove " << data;
			if (bst.removeNode(data)) out << " True";
			else  out << " False";
		}
		else if (item1 == "Clear")
		{
			out << endl << "Clear";
			if (bst.clearTree()) out << " True";
			else  out << " False";
		}
		else if (item1 == "PrintBST")
		{
			out << endl << "PrintBST" << bst;
		}
	}
	// delete tree (recover memory)
	//bst.clearTree();

	// close files (no memory leaks)
	if (&out != &std::cout)
	{
		//out->close();
		delete(&out);
	}
	return 0;
}
