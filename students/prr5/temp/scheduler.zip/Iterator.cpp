#include <iostream>
#include <string>
#include <sstream>
#include <fstream>
using namespace std;

enum myMode { SEQUENTIAL, PRIME, FIB };

template<typename T>
class myIterator
{
private:
	T* obj_;
	int size_;
	int pointer_;
	int mode_;

	bool isPrime(int num)
	{
		int i, count = 0;
		for (i = 2; i < num; i++)
		{
			if (num % i == 0) return false;
		}
		return true;
	}
	bool isFibonacci(int p, int size)
	{
		if (size < 3) return false;
		if (obj_[p + 0] == obj_[p - 1] + obj_[p - 2])
		{
			cout << " " << obj_[p - 1] << "+" << obj_[p - 2] << "=";
			return true;
		}
		return false;
	}

public:
	myIterator<T>(T* vec) :
		obj_(vec),
		size_(100),
		pointer_(0),
		mode_(0) {}
	myIterator<T>(T* vec, int size) :
		obj_(vec),
		size_(size),
		pointer_(0),
		mode_(0) {}
	myIterator(T* vec, int size, int pointer) :
		obj_(vec),
		size_(size),
		pointer_(pointer),
		mode_(0) {}
	myIterator(T* vec, int size, int pointer, int mode) :
		obj_(vec),
		size_(size),
		pointer_(pointer),
		mode_(mode) {}

	bool operator!=(const myIterator<T>& other) const
	{
		return !(*this == other);
	}

	bool operator==(const myIterator<T>& other) const
	{
		return pointer_ == other.pointer_;
	}

	myIterator<T>& operator++()
	{
		//++pointer_;
		switch (mode_)
		{
		default:
		case SEQUENTIAL:
			if (pointer_ != size_) ++pointer_;
			break;

		case PRIME:
			while (pointer_ != size_)
			{
				if (isPrime(obj_[++pointer_])) break;
			}
			break;

		case FIB:
			while (pointer_ != size_)
			{
				if (isFibonacci(++pointer_, size_)) break;
			}
			break;
		}
		return *this;
	}

	T operator*() const
	{
		return obj_[pointer_];
	}

	string toString() const
	{
		stringstream out;
		out << "array[" << pointer_ << "]=" << obj_[pointer_];
		out << " size=" << size_;
		out << " mode=" << mode_ << endl;
		return out.str();
	}

	friend std::ostream& operator<< (ostream& os, const myIterator<T>& iter)
	{
		os << iter.toString();
		return os;
	}
};

template<typename T, int array_size>
class MyArray
{
	int size_;
	T array[1000];
public:
	MyArray() :
		size_(0) {}
	void push_back(T item) { array[size_++] = item; };
	myIterator<T> begin()
	{
		return myIterator<T>(array, size_, 0);
	}
	myIterator<T> begin(myMode mode)
	{
		return myIterator<T>(array, size_, 0, mode);
	}
	myIterator<T> end()
	{
		return myIterator<T>(array, size_, size_);
	}
};

#include <iostream>
int main(int argc, char * argv[])
{
	cout << "argc=" << argc << endl;
	while (--argc > 0)
		cout << *++argv << ((argc > 1) ? " " : "");
	cout << endl;

	char filename[] = "C:\\Users\\Paul Roper\\Dropbox\\BYU\\CS 235\\public_html\\labs\\L03-Iterator\\data1.txt";
	MyArray<int, 1000> numbers;
	std::fstream myfile(filename, std::ios_base::in);
	int i;
	while (myfile >> i)
	{
		printf("%d ", i);
		numbers.push_back(i);
	}

	//for (int i = 0; i < 100; i++) numbers.push_back(i);
	//for (int i = 0; i < 1000; i++) numbers.push_back(rand() % 100);

	myIterator<int> iter = numbers.begin();
	cout << endl << "iter: " << iter;
	//cout << "iter: " << iter.toString() << endl;

	for (; iter != numbers.end(); ++iter)
		cout << *iter << ' ';
	cout << endl;

	myIterator<int> iter2 = numbers.begin(PRIME);
	cout << endl << "iter: " << iter2;

	for (; iter2 != numbers.end(); ++iter2)
		cout << *iter2 << ' ';
	cout << endl;

	myIterator<int> iter3 = numbers.begin(FIB);
	cout << endl << "iter: " << iter3;

	for (; iter3 != numbers.end(); ++iter3)
		cout << *iter3 << ' ';
	cout << endl;

	getchar();
}