{\rtf1\ansi\ansicpg1252\cocoartf1561\cocoasubrtf100
{\fonttbl\f0\fmodern\fcharset0 Courier;}
{\colortbl;\red255\green255\blue255;\red0\green0\blue0;}
{\*\expandedcolortbl;;\cssrgb\c0\c0\c0;}
\margl1440\margr1440\vieww10800\viewh8400\viewkind0
\deftab720
\pard\pardeftab720\sl280\partightenfactor0

\f0\fs24 \cf2 \expnd0\expndtw0\kerning0
\outl0\strokewidth0 \strokec2 #include <iostream>\
using namespace std;\
\
#ifdef _MSC_VER\
#define _CRTDBG_MAP_ALLOC  \
#include <crtdbg.h>\
#define VS_MEM_CHECK _CrtSetDbgFlag(_CRTDBG_ALLOC_MEM_DF | _CRTDBG_LEAK_CHECK_DF);\
#else\
#define VS_MEM_CHECK;\
#endif\
\
int main(int argc, char* argv[])\
\{\
	VS_MEM_CHECK			// check for memory leaks\
	cout << "Hello World!";\
\
	cout << endl << "argc = " << argc;\
	if (argc > 1) cout << endl << "argv[1] = " << argv[1];\
	if (argc > 2) cout << endl << "argv[2] = " << argv[2];\
\
	int* leak = new int;\
	return 0;\
\}\
}