#include "Grade.h"

Grade::Grade(){}

Grade::Grade(std::string a, std::string b, std::string c, std::string d, std::string e, std::string f)
{
	courseName = a;
	days = b;
	room = c;
	studentName = d;
	studentID = e;
	gradeLetter = f;
}

std::string Grade::toString()
{
	std::stringstream ss;
	ss << courseName << " " << days << ", " << room << " " << studentName << " " << studentID << ", " << gradeLetter;
	return ss.str();
}

std::string Grade::getCourseName()
{
	return courseName;
}

std::string Grade::getStudentID()
{
	return studentID;
}