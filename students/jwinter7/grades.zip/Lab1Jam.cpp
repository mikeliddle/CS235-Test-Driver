#include<iostream>
#include<iomanip>
#include<string>
#include<fstream>
#ifdef _MSC_VER
#define _CRTDBG_MAP_ALLOC  
#include <crtdbg.h>
#define VS_MEM_CHECK _CrtSetDbgFlag(_CRTDBG_ALLOC_MEM_DF | _CRTDBG_LEAK_CHECK_DF);
#else
#define VS_MEM_CHECK
#endif
using namespace std;

// By JimJam

// Writes to the file the name of the students, their exam scores and corresponding letter grades
void printStudentGrades(string* studentName, int** studentGrades, char** letterArray, int numExams, int numStudents, ifstream &inFile, ofstream &outFile)
{
	outFile << endl;
	outFile<< endl;
	outFile << "Student Exam Grades:" << endl;
	for (int i = 0; i < numStudents; i++)
	{
		outFile << setw(20) << studentName[i] << " ";
		for (int j = 0; j < numExams; j++)
		{
			outFile << setiosflags(ios::fixed)<< setprecision(0) << setw(6) << studentGrades[i][j] << "(" << letterArray[i][j] << ")";
		}
		outFile << endl;
	}
	inFile.close();
	for (int i = 0; i < numStudents; ++i)
	{
		delete[] letterArray[i];
	}
	delete[] letterArray;

	for (int i = 0; i < numStudents; ++i)
	{
		delete[] studentGrades[i];
	}
	delete[] studentGrades;

	delete[] studentName;
}

// COunts the number of grades for each exam
int numberOfGrades(int i, char** letterArray, char grade, int numStudents)
{
	int countGrade = 0;

	for (int j = 0; j < numStudents; j++)
	{
		if (grade == letterArray[j][i])
		{
			countGrade = countGrade + 1;
		}
	}
	return countGrade;
}


// Writes to the file the averages and how many of each grades there were
void printAverage(double* examAverages, int numExams, int numStudents, char** letterArray, string* studentName, int** studentGrades, ifstream &inFile, ofstream &outFile)
{
	outFile << "Exam Averages:" << endl;
	for (int i = 0; i < numExams; i++)
	{
		outFile << "Exam " << i + 1 << " " << "average ="<<  setiosflags(ios::showpoint)<< setprecision(3)<<examAverages[i] << setw(4) 
			<< numberOfGrades(i, letterArray, 'A', numStudents) << "(A)" << setw(4) << numberOfGrades(i, letterArray, 'B', numStudents) << "(B)"
		    << setw(4) << numberOfGrades(i, letterArray, 'C', numStudents) << "(C)" << setw(4) << numberOfGrades(i, letterArray, 'D', numStudents) << "(D)" 
			<< setw(4) << numberOfGrades(i, letterArray, 'E', numStudents) << "(E)" << endl;
	}

	printStudentGrades(studentName, studentGrades, letterArray, numExams, numStudents, inFile,outFile);

	delete[]examAverages;
	
}


// Assigns letter grades to the individual scores and put those letter grades into an array
void gradeArray(int** studentGrades, int numStudents, int numExams, double* examAverages, string* studentName, ifstream &inFile, ofstream &outFile)
{
	int theGrade = 0;
	double theExam = 0.0;
	double total = 0.0;
	char **letterArray = new char*[numStudents];

	for (int i = 0; i < numStudents; ++i)
	{
		letterArray[i] = new char[numExams];
	}

	for (int i = 0; i < numExams; i++)
	{
		theGrade = 0;
		theExam = 0.0;
		total = 0.0;
		for (int j = 0; j < numStudents; j++)
		{
			theGrade = studentGrades[j][i];
			theExam = examAverages[i];
			total = theGrade - theExam;

			if (total <= 5 && total > -5)
			{
				letterArray[j][i] = 'C';
			}
			else if (total > 5 && total < 15)
			{
				letterArray[j][i] = 'B';
			}
			else if (total < -5 && total > -15)
			{
				letterArray[j][i] = 'D';
			}
			else if (total > 15)
			{
				letterArray[j][i] = 'A';
			}
			else
			{
				letterArray[j][i] = 'E';
			}
		}
	}

	printAverage(examAverages, numExams, numStudents, letterArray,studentName,studentGrades, inFile,outFile);
}

// Creates an array that holds the averages of the exams
void averageArray(int** studentGrades, int numStudents, int numExams, string* studentName, ifstream &inFile, ofstream &outFile)
{
	double* examAverages = new double[numExams];
	double totalAverage = 0.0;

	for (int i = 0; i < numExams; i++)
	{
		totalAverage = 0;
		for (int j = 0; j < numStudents; j++)
		{
			totalAverage = totalAverage + studentGrades[j][i];
		}

		examAverages[i] = totalAverage/ numStudents;
	}

	gradeArray(studentGrades, numStudents, numExams, examAverages,studentName, inFile,outFile);

}

// Populates the arrays that hold the names and the scores
void setArray(ifstream &inFile, int numStudents, int numExams, ofstream &outFile)
{
	string lastName;
	string firstName;
	int examScore;
	string* studentName = new string[numStudents];
	int **studentGrades = new int*[numStudents];

	for (int i = 0; i < numStudents; i++)
	{
		studentGrades[i] = new int[numExams];
	}

	for (int i = 0; i < numStudents; i++)
	{
		inFile >> firstName >> lastName;
		studentName[i] = firstName +  " " + lastName;

		for (int j = 0; j < numExams; j++)
		{
			inFile >> examScore;
			studentGrades[i][j] = examScore;
		}
	}
	averageArray(studentGrades, numStudents, numExams, studentName, inFile,outFile);
}



	int main(int argc, char * argv[]) {
		
	VS_MEM_CHECK
	
	int numStudents = 0;
	int numExams = 0;
	
	
	if (argc < 3)  
	{
		cerr << "Please provide name of input and output files\n";
		return 1;
	}
	cout << "Input file: " << argv[1] << endl;  

	 ifstream inFile(argv[1]); 

	if (!inFile)
	{
		cerr << "Unable to open " << argv[1] << " for input\n";
		return 1; 
	}

	cout << "Output file: " << argv[2] << endl;

	ofstream outFile(argv[2]);
	if (!outFile)
	{
		inFile.close();
		cerr << "Unable to open " << argv[2] << " for output";
		return 1;
	}

	// Send number of students and exams into the functions
	inFile >> numStudents >> numExams;
	setArray(inFile,numStudents,numExams,outFile);

	
	return 0;
}