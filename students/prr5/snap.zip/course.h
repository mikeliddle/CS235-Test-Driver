#ifndef COURSE_H
#define COURSE_H
#include <string>
using namespace std;

class Course
{
private:
	string courseName;
public:
	Course() : courseName("") { }
	Course(string courseName) { this->courseName = courseName; }
	void setCourseName(string courseName) { this->courseName = courseName; }
	string getCourseName() const { return this->courseName; }
};

#endif // COURSE_H
