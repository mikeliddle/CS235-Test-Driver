/* Lab 01 - Grades */

#ifdef _MSC_VER
#define _CRTDBG_MAP_ALLOC  
#include <crtdbg.h>
#define VS_MEM_CHECK _CrtSetDbgFlag(_CRTDBG_ALLOC_MEM_DF | _CRTDBG_LEAK_CHECK_DF);
#else
#define VS_MEM_CHECK
#endif

#include <iostream>
#include <iomanip>
#include <fstream>
#include <string>
#include <math.h>

using namespace std;

/**
Returns the letter grade a student receives based on the following criteria:
difference		above average		below average
<=5						C						C
5 - 15					B						D
>=15						A						E
@param scoreDifference Difference of (actual score) - (average score)
@return A character representing the letter grade.
*/

char assignGrade(double scoreDifference) 
	{
	char examGrade;
	bool isPassing = scoreDifference >= 0;
	scoreDifference = fabs(scoreDifference);

	if (scoreDifference <= 5) 
	{
		examGrade = 'C';
	}

	else if (scoreDifference > 5 && scoreDifference < 15) 
	{
		if (isPassing) 
		{
			examGrade = 'B';
		}
		else 
		{
			examGrade = 'D';
		}
	}

	// Else is different by more than 15
	else 
	{
		if (isPassing) 
		{
			examGrade = 'A';
		}
		else 
		{
			examGrade = 'E';
		}
	}
	return examGrade;
}

/**
Returns the average of an array of doubles.
@param arraySize How large the passed in array is.
@param arrayToAverage[] Array of type double to sum and average.
@return Computed average value.
*/

double calculateAverage(int arraySize, double arrayToAverage[]) 
	{
	double averageValue = 0.0;
	for (int i = 0; i < arraySize; ++i) 
	{
		averageValue += arrayToAverage[i];
	}
	return averageValue / arraySize;
}

/**
Returns the average of an array of integers.
@param arraySize How large the passed in array is.
@param arrayToAverage[] Array of type int to sum and average.
@return Computed average value.
*/

double calculateAverage(int arraySize, int arrayToAverage[]) 
	{
	double averageValue = 0.0;
	for (int i = 0; i < arraySize; ++i) 
	{
		averageValue += arrayToAverage[i];
	}
	return averageValue / arraySize;
}

int main(int argc, char * argv[]) 
	{
	const int PLACES_PAST_DECIMAL = 1;
	const int NAME_TABLE_WIDTH = 20;
	const int EXAM_GRADE_TABLE_WIDTH = 5;
	const int SCORE_TABLE_WIDTH = 6;
	VS_MEM_CHECK          // enable memory leak check

	// Create a dynamic array
	string* studentNames = NULL;
	int** studentScores = NULL;
	double* examAverages = NULL;
	int numStudents = 0;
	int numExams = 0;

	if (argc < 3) 
	{
		cerr << "Please provide name of input and output files";
		return 1;
	}
	cout << "Input file: " << argv[1] << endl;

	ifstream inFile(argv[1]);
	
	if (!inFile) 
	{
		cerr << "Unable to open " << argv[1] << " for input";
		return 1;
	}
	cout << "Output file: " << argv[2] << endl;
	
	ofstream outFile(argv[2]);

	if (!outFile) 
	{
		inFile.close();
		cerr << "Unable to open " << argv[2] << " for output";
	}

	inFile >> numStudents;
	studentNames = new string[numStudents];
	inFile >> numExams;

	// Create dynamic 2D array
	studentScores = new int*[numStudents];
	for (int i = 0; i < numStudents; ++i) 
	{
		studentScores[i] = new int[numExams];
	}

	// Read input from the file and store in proper places.
	for (int i = 0; i < numStudents; ++i) 
	{
		string firstName;
		inFile >> firstName;
		string lastName;
		inFile >> lastName;
		studentNames[i] = firstName + " " + lastName;
		for (int j = 0; j < numExams; ++j) 
		{
			inFile >> studentScores[i][j];
		}
	}

	// Output properly

	examAverages = new double[numExams];

	outFile << "Exam Averages:" << endl;
	
	for (int i = 0; i < numExams; ++i) 
	{
		// Calculate average per exam
		double averageScore = 0.0;
		for (int j = 0; j < numStudents; ++j) 
		{
			averageScore += studentScores[j][i];
		}
		averageScore /= double(numStudents);
		examAverages[i] = averageScore;
		outFile << "Exam  " << i + 1 << " average =" << fixed << setprecision(PLACES_PAST_DECIMAL) << averageScore;

		int countA = 0;
		int countB = 0;
		int countC = 0;
		int countD = 0;
		int countE = 0;
		for (int j = 0; j < numStudents; ++j) 
		{
			switch (assignGrade(double(studentScores[j][i]) - averageScore)) 
			{
			case 'A':
				countA++;
				break;
			case 'B':
				countB++;
				break;
			case 'C':
				countC++;
				break;
			case 'D':
				countD++;
				break;
			case 'E':
				countE++;
				break;
			default:
				break;
			}
		}

		outFile << setw(EXAM_GRADE_TABLE_WIDTH) << countA << "(A)"
			<< setw(EXAM_GRADE_TABLE_WIDTH) << countB << "(B)"
			<< setw(EXAM_GRADE_TABLE_WIDTH) << countC << "(C)"
			<< setw(EXAM_GRADE_TABLE_WIDTH) << countD << "(D)"
			<< setw(EXAM_GRADE_TABLE_WIDTH) << countE << "(E)"
			<< endl;
	}

	outFile << endl;

	outFile << "Student Exam Grades:" << endl;
	for (int i = 0; i < numStudents; ++i) 
	{
		outFile << setw(NAME_TABLE_WIDTH) << studentNames[i];
		// j represents the exam number
		for (int j = 0; j < numExams; ++j) 
		{
			// Check and assign grade.
			outFile << setw(SCORE_TABLE_WIDTH) << studentScores[i][j] 
				<< "(" << assignGrade(studentScores[i][j] - examAverages[j]) << ")";
		}
		outFile << endl;
	}

	// BONUS MATERIAL
	double classAverage = calculateAverage(numExams, examAverages);

	outFile << endl;
	outFile << "**BONUS**" << endl;
	outFile << "Class Average = " << setprecision(PLACES_PAST_DECIMAL) << classAverage << endl;
	outFile << "Student Final Exam Grade:" << endl;
	for (int i = 0; i < numStudents; ++i) 
	{
		double studentAverage = calculateAverage(numExams, studentScores[i]);
		outFile << setw(NAME_TABLE_WIDTH) << studentNames[i] << right << setw(SCORE_TABLE_WIDTH) << studentAverage
			<< "(" << assignGrade(studentAverage - classAverage) << ")" << endl;
	}

	outFile.close();
	inFile.close();

	// Free Memory before closing
	delete[] studentNames;
	for (int i = 0; i < numStudents; ++i) 
	{
		delete[] studentScores[i];
	}
	delete[] studentScores;
	delete[] examAverages;
	studentNames = NULL;
	studentScores = NULL;
	examAverages = NULL;

	return 0;
}