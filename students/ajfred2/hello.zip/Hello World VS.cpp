/*
Aleah Fredrickson, Section 2, aleah.fredrickson@gmail.com
Do the Hello World lab in Visual Studio
*/

#include <iostream>
#include <string>
using namespace std;

int main() {
	cout << "Hello world!" << endl;
	cout << "How are you?" << endl;
	cout << "   (I'm fine)." << endl;

	system("pause");

	return 0;
}