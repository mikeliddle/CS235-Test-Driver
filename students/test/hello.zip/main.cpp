/*
 * main.cpp
 *
 *  Created on: Sep 15, 2016
 *      Author: mike.liddle
 */

#include <iostream>
#include "Arena.h"

using namespace std;

int main() {
	Arena* test = new Arena();
	test->addFighter("name c 100 100 100 100");

	return 0;
}


