#include <iostream>
using namespace std;

int main() {
	cout << "Hello, I am a beautiful, beautiful creature trapped inside your computer" << endl;

	return 0;
}