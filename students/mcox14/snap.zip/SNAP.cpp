#include "SNAP.h"



SNAP::SNAP(string ID = "", string name = "", string address = "", string phone = "")
{
	studentID = ID;
	studentName = name;
	studentAddress = address;
	studentPhone = phone;
}


SNAP::~SNAP()
{
}

string SNAP::toString() {
	stringstream out;
	out << "snap(" << studentID << "," << studentName << "," << studentAddress << "," << studentPhone << ")";
	return out.str();

}
