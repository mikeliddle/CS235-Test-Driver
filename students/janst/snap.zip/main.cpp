/** Program to output a school schedule */
#include <iostream>
#include <fstream>
#include <string>
#include <sstream>
#include <vector>
#include <limits>
#include "Cr.h"
#include "Snap.h"
#include "Cdh.h"
#include "Csg.h"
#include "Schedule.h"
#include "Grade.h"

using std::string;
using std::ifstream;
using std::ofstream;
using std::istringstream;

using std::cerr;
using std::endl;
using std::cout;

void findDays(string& days, string day)
{
	if (day == "M")
	{
		days[0] = 'M';
	}
	else if (day == "T")
	{
		days[1] = 'T';
	}
	else if (day == "W")
	{
		days[2] = 'W';
	}
	else if (day == "Th")
	{
		days[3] = 'T';
		days[4] = 'h';

	}
	else if (day == "F")
	{
		days[5] = 'F';
	}
	else throw ("Invalid Day in Input");
}

int main(int argc, char* argv[]) 
{
	if (argc < 3)
	{
		cerr << "Please provide name of input and output files\n";
		return 1;
	}
	cout << "Input file: " << argv[1] << endl;
	ifstream in(argv[1]);
	if (!in)
	{
		cerr << "Unable to open " << argv[1] << " for input\n";
		return 1;
	}
	cout << "Output file: " << argv[2] << endl;
	ofstream out(argv[2]);
	if (!out)
	{
		in.close();
		cerr << "Unable to open " << argv[2] << " for output\n";
	}

	std::vector<Snap> snaps;
	std::vector<Cr> crs;
	std::vector<Cdh> cdhs;
	std::vector<Csg> csgs;

	out << "Input Strings:" << endl;
	try
	{
		for (string line; getline(in, line);)	// Read until EOF
		{

			if ("sna" == line.substr(0, 3))
			{
				string id = line.substr(5, line.find(',') - 5);
				string rest = line.substr(line.find(',') + 1);
				string name = rest.substr(0, rest.find(','));
				rest = rest.substr(rest.find(',') + 1);
				string address = rest.substr(0, rest.find(','));
				rest = rest.substr(rest.find(',') + 1);
				string number = rest.substr(0, rest.find(')'));
				snaps.push_back(Snap(id, name, address, number));
				out << line << endl;
			}
			else if ("csg" == line.substr(0, 3))
			{
				string courseName = line.substr(4, line.find(',') - 4);
				string rest = line.substr(line.find(',') + 1);
				string studentID = rest.substr(0, rest.find(','));
				rest = rest.substr(rest.find(',') + 1);
				string studentGrade = rest.substr(0, rest.find(')'));
				csgs.push_back(Csg(courseName, studentID, studentGrade));
				out << line << endl;
			}
			else if ("cdh" == line.substr(0, 3))
			{
				string courseName = line.substr(4, line.find(',') - 4);
				string rest = line.substr(line.find(',') + 1);
				string day = rest.substr(0, rest.find(','));
				rest = rest.substr(rest.find(',') + 1);
				string time = rest.substr(0, rest.find(')'));
				cdhs.push_back(Cdh(courseName, day, time));
				out << line << endl;
			}
			else if ("cr(" == line.substr(0, 3))
			{
				string courseName = line.substr(3, line.find(',') - 3);
				string rest = line.substr(line.find(',') + 1);
				string room = rest.substr(0, rest.find(')'));
				crs.push_back(Cr(courseName, room));
				out << line << endl;
			}
			else throw("Exception: Invalid input");
		}
	}
	catch (...)
	{
		cerr << "Exception Occured";
	}
	
	out << endl << "Vectors:" << endl;
	for (unsigned int i = 0; i < snaps.size(); i++)
	{
		out << snaps[i] << endl;
	}
	for (unsigned int i = 0; i < csgs.size(); i++)
	{
		out << csgs[i] << endl;
	}
	for (unsigned int i = 0; i < cdhs.size(); i++)
	{
		out << cdhs[i] << endl;
	}
	for (unsigned int i = 0; i < crs.size(); i++)
	{
		out << crs[i] << endl;
	}

	//Snap has - a studentID, studentName, studentAddress, and studentPhone.
	//Csg is - a Course and has - a studentID and studentGrade.
	//Cdh is - a Course and has - a day and time.
	//Cr is - a Course and has - a room.
	//Course has - a courseName.
	std::vector<Schedule> mySchedules;
	std::vector<Grade> myGrades;

	//store schedules first in vector
	try
	{
		for (unsigned int i = 0; i < snaps.size(); i++)
		{
			for (int j = 0; j < csgs.size(); j++)
			{
				if (snaps[i].getStudentID() == csgs[j].getStudentID())//this orders grades according to student id
				{
					Snap snap = snaps[i];
					Csg csg = csgs[j];
					//Ex. Carlie Brown, 12345, Manager, 555-1234, CS101 MWF 9AM, 1170 TMCB
					string name, id, address, phone, course, weekdays, hour, location;// for schedules
					string letter; // additional for Grades
					id = snap.getStudentID();
					name = snap.getStudentName();
					address = snap.getStudentAddress();
					phone = snap.getStudentPhone();
					course = csg.getCourseName();

					for (int k = 0; k < cdhs.size(); k++)
					{
						if (csg.getCourseName() == cdhs[k].getCourseName())
						{
							Cdh cdh = cdhs[k];
							string days = "      ";
							findDays(days, cdh.getDay());
							for (int l = 0; l < days.size(); l++)
							{
								if (days[l] != ' ')
								{
									weekdays += days[l];
								}
							}

							hour = cdh.getTime();
							letter = csg.getStudentGrade();
							//TODO: short circuit checking every course in csg
						}
					}
					for (int k = 0; k < crs.size(); k++)
					{
						if (crs[k].getCourseName() == csg.getCourseName())
						{
							Cr cr = crs[k];
							location = cr.getRoom();
						}
					}
					//Store Grades in vector now
					myGrades.push_back(Grade(course, weekdays, location, name, id, letter));
					
					//Store Schedules
					mySchedules.push_back(Schedule(course, id, name, address, phone, weekdays, hour, location));
				}
			}
			mySchedules.push_back(Schedule());
		}
	}
	catch (...)
	{
		cerr << "Invalid Input from file";
	}

	out << endl << "Course Grades:" << endl << endl;
	//std::vector<Grade> reorderedGrades;
	string curCourse;
	string oldCourse = csgs[0].getCourseName();
	for (int i = 0; i < csgs.size(); i++)
	{
		curCourse = csgs[i].getCourseName();
		for (int j = 0; j < myGrades.size(); j++)
		{
			if (csgs[i].getCourseName() == myGrades[j].getCourseName() && csgs[i].getStudentID() == myGrades[j].getStudentID())
			{
				//push to reorderedGrades
				//TODO: shortcircuit by removing grades from the vector.
				if (curCourse != oldCourse)
				{
					oldCourse = curCourse;
					out << endl;
				}
				out << myGrades[j] << endl;
			}
		}
	}

	out << endl << "Student Schedules:" << endl << endl;
	for (unsigned int i = 0; i < mySchedules.size(); i++)
	{
		out << mySchedules[i] << endl;
	}


	//use polymorphism
	std::vector<Course*> polymorphism;
	for (int i = 0; i < csgs.size(); i++)
	{
		Course* course = &csgs[i];
		polymorphism.push_back(course);

		//uncomment the below lines to view the polymorphic inner class.
		//std::cout << polymorphism[i]->toString();
		//system("PAUSE");
	}

	return 0;
	}