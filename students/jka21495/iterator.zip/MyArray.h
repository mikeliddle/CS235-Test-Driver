#include <string>

using std::string;

class MyArray
{
public:
	enum Mode { SEQUENTIAL, PRIME, COMPOSITE, FIBINOCCI };
	class Iterator {
	public:
		Iterator();
		Iterator(int* array, int size, int index, Mode mode);
		~Iterator();
		string toString() const;
		friend std::ostream& operator<< (std::ostream& os, Iterator& myclass);
		bool isValidIndex();
		void operator++();
		void operator--();
		int operator* ();
		bool operator==(const Iterator& that);
		bool operator!=(const Iterator& that);
		int& operator[](const int ind);

	private:
		int* array;
		int size;
		int index;
		Mode mode;
	};

	MyArray();
	~MyArray();
	void push_back(int insert);
	string toString() const;
	friend std::ostream& operator<< (std::ostream& os, MyArray& myclass);
	Iterator begin();
	Iterator end();
	Mode incrementMode();
	

private:
	int* array;
	int size;
	Mode currentMode;
};

