#include <iostream>

using namespace std;

int main() {

	cout << "Hello wrld!" << endl;
	cout << "How are you?" << endl;
	cout << "   (I'm fine)." << endl;

	system("pause");
	return 0;
}
