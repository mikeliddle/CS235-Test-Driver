#include "CDH.h"



CDH::CDH(string name = "", string day = "", string time = "") : Course(name)
{
	classDay = day;
	classTime = time;
}


CDH::~CDH()
{
}

string CDH::toString() {
	stringstream out;
	out << "cdh(" << courseName << "," << classDay << "," << classTime << ")";
	return out.str();
}
