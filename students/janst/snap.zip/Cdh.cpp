#include "Cdh.h"

Cdh::Cdh() {};

Cdh::Cdh(std::string a, std::string b, std::string c) : Course(a)
{
	day = b;
	time = c;
}

//Ex. cdh(EE200,Th,10AM)
std::string Cdh::toString() {
	return "cdh(" + courseName + "," + day + "," + time + ")";
}

std::string Cdh::getDay()
{
	return day;
}

std::string Cdh::getTime()
{
	return time;
}