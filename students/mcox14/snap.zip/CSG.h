#ifndef CSG_H
#define CSG_H
#include "Course.h"
#include <sstream>
class CSG :
	public Course
{
public:
	CSG(string name, string ID, string grade);
	~CSG();

	string getStudentID() {
		return studentID;
	}

	string getStudentGrade() {
		return studentGrade;
	}
	string toString();
private:
	string studentID;
	string studentGrade;

};

#endif