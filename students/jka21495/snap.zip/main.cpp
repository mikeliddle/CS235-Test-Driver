#include <fstream>
#include <string>
#include <iostream>
#include "School.h"

using namespace std;

int main(int argc, char** argv) {
	if (argc < 3) {
		cout << "Not enough arguments." << endl;
		return 0;
	}

	string inFileName = argv[1];
	string outFileName = argv[2];
	ifstream inFile(inFileName);
	ofstream outFile(outFileName);

	if (!inFile.is_open() || !outFile.is_open()) {
		cout << "Failed to open one of requested files. Please check directory setup." << endl;
		char c;
		cin >> c;
		return 0;
	}

	School school;
	string line;

	outFile << "Input Strings:\n";
	while (getline(inFile, line)) {
		outFile << school.processLine(line) << "\n";
	}
	inFile.close();
	school.initializeCourses();

	outFile << "\nVectors:\n" << school.getVectors() << "\n";

	outFile << "Course Grades:\n\n" << school.getCourseGrades();

	outFile << "Student Schedules:\n\n" << school.getSchedules();

	outFile.close();


	return 0;
}