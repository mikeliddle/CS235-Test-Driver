#include "Csg.h"

Csg::Csg() {}

Csg::Csg(std::string a, std::string b, std::string c) : Course(a)
{
	studentID = b;
	studentGrade = c;
}

//Ex. csg(CS101,12345,A)
std::string Csg::toString() {
	return "csg(" + courseName + "," + studentID + "," + studentGrade + ")";
}

std::string Csg::getStudentID()
{
	return studentID;
}

std::string Csg::getStudentGrade()
{
	return studentGrade;
}