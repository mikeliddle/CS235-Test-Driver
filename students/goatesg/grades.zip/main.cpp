/*
The Goate - Lab 01 - Grades

Input files must be named input.txt or you can change the name by going into the
settings of this program.
This program will create an output file called output.txt in the same folder as
this program.

########################################################################################################################
120 char check
*/
#include <iostream>
#include <string>
#include <iomanip>
#include <fstream>
#include <istream>
#include <sstream>
#include <limits>
#include <array>


using namespace std;

#ifdef _MSC_VER
#define _CRTDBG_MAP_ALLOC  
#include <crtdbg.h>
#define VS_MEM_CHECK _CrtSetDbgFlag(_CRTDBG_ALLOC_MEM_DF | _CRTDBG_LEAK_CHECK_DF);
#else
#define VS_MEM_CHECK
#endif

string FndLetter(int grade, double classAvg) {

	if (grade <= (classAvg + 5) && grade >= (classAvg - 5))
	{
		return "(C)";
	}
	else if (grade > (classAvg + 5) && grade <= (classAvg + 15))
	{
		return "(B)";
	}
	else if (grade < (classAvg - 5) && grade >=(classAvg - 15))
	{
		return "(D)";
	}
	else if (grade > (classAvg + 15))
	{
		return "(A)";
	}
	else if (grade < (classAvg - 15))
	{
		return "(E)";
	}
	return "ERROR!";
}

// finds the a's, b's, c's, d's, and e's for the given test from the student's grades
void FindGrades(int& a, int& b, int& c, int& d, int& e, double avgGrade, int** studentsGrades,
	int cycle , int rows) 
{
	a = 0;
	b = 0;
	c = 0;
	d = 0;
	e = 0;
	string temp = "i am mormon";
	
	for (int i = 0; i < rows; i++) 
	{
		temp = FndLetter(studentsGrades[i][cycle], avgGrade);
		if (temp == "(A)") 
		{
			a++;
		}
		if (temp == "(B)")
		{
			b++;
		}
		if (temp == "(C)")
		{
			c++;
		}
		if (temp == "(D)")
		{
			d++;
		}
		if (temp == "(E)")
		{
			e++;
		}
	}

}

int main(int argc, char* argv[])
{
	int rows = 0;
	int cols = 0;
	int temp = 0;
	int numOfA = 0;
	int numOfB = 0;
	int numOfC = 0;
	int numOfD = 0;
	int numOfE = 0;
	double classAverage = 0.0;
	double tempDouble = 0.0;
	string line = "";
	string firstName = "";
	string lastName = "";
	const string GRADE_A = "(A)";
	const string GRADE_B = "(B)";
	const string GRADE_C = "(C)";
	const string GRADE_D = "(D)";
	const string GRADE_E = "(E)";

	// check for memory errors
	VS_MEM_CHECK;

	// open the input and output files and check if they open
	ifstream in;
	in.open(argv[1]);
	if (!in)
	{
		cerr << "Unable to open " << argv[1];
		return 1;
	}
	ofstream out(argv[2]);
	if (!out)
	{
		in.close();
		cerr << "Unable to open " << argv[2];
		return 1;
	}

	// get the rows and columns from the input
	in >> rows;
	in >> cols;
	in.ignore(256, '\n');

	// create arrays and initalize them
	int** testScores = new int*[rows];
	for (int i = 0; i < rows; i++)
	{
		testScores[i] = new int[cols];
	}
	string* studentsNames = new string[rows];
	double* examAverages = new double[cols];
	double* studentAverages = new double[rows];

	// get rest of information out of the input.txt file
	for (int i = 0; i < rows; i++)
	{
		getline(in, line);
		istringstream lineParts(line);
		lineParts >> firstName;
		lineParts >> lastName;
		studentsNames[i] = firstName + " " + lastName;
		for (int j = 0; j < cols; j++)
		{
			lineParts >> temp;
			testScores[i][j] = temp;
		}
		temp = 0; // reset temp to zero
	}

	//Find test averages and store them in an array
	for (int i = 0; i < cols; i++)
	{
		for (int j = 0; j < rows; j++)
		{
			temp += testScores[j][i];
		}
		examAverages[i] = (static_cast<double>(temp) / static_cast<double>(rows));
		temp = 0; // reset temp to be used for next loop
	}

	//Find test average
	for (int i = 0; i < cols; i++)
	{
		tempDouble += examAverages[i];
	}
	classAverage = (tempDouble / static_cast<double>(cols));

	//Find student averages
	for (int i = 0; i < rows; i++) 
	{
		for (int j = 0; j < cols; j++)
		{
			temp += testScores[i][j];
		}
		studentAverages[i] = (static_cast<double>(temp) / static_cast<double>(cols));
		temp = 0; // reset temp to be used for next loop
	}

	//Print out the Exam Averages
	out << "Exam Averages:" << endl;
	for (int i = 0; i < cols; i++) 
	{
		FindGrades(numOfA, numOfB, numOfC, numOfD, numOfE, examAverages[i], testScores , i, rows);
		out << "Exam " << setw(2) << i + 1 << " average = " << fixed << setprecision(1) << examAverages[i]
			<< setprecision(0) << setw(5) << numOfA << GRADE_A << setw(5) << numOfB << GRADE_B << setw(5) 
			<< numOfC << GRADE_C << setw(5) << numOfD << GRADE_D << setw(5) << numOfE << GRADE_E << endl;
	}
	out << endl;

	//Print out Student exam grades
	out << "Student Exam Grades:" << endl;
	for (int i = 0; i < rows; i++) 
	{
		out << setw(20) << studentsNames[i];
		for (int j = 0; j < cols; j++)
		{
			out << setw(6) << testScores[i][j] << FndLetter(testScores[i][j], examAverages[j]);
		}
		out << endl;
	}
	out << endl;

	// Bonus
	out << "**BONUS**" << endl;
	out << "Class Average = " << fixed << setprecision(1) << classAverage << endl;
	out << "Student Final Exam Grade:" << endl;
	for (int i = 0; i < rows; i++) 
	{
		out << setw(20) << studentsNames[i] << setw(6) << studentAverages[i] 
			<< FndLetter(studentAverages[i], classAverage) << endl;
	}

	// close files
	in.close();
	out.close();

	//return memory to the stack
	for (int i = 0; i < rows; i++) 
	{
		delete[] testScores[i];
	}
	delete[] testScores;
	delete[] studentsNames;
	delete[] examAverages;
	delete[] studentAverages;

	return 1;
}