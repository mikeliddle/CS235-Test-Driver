#include <iostream>
using namespace std;

#ifdef _MSC_VER
#define _CRTDBG_MAP_ALLOC  
#include <crtdbg.h>
#define VS_MEM_CHECK _CrtSetDbgFlag(_CRTDBG_ALLOC_MEM_DF | _CRTDBG_LEAK_CHECK_DF);
#else
#define VS_MEM_CHECK;
#endif

int main(int argc, char* argv[])
{
	VS_MEM_CHECK			// check for memory leaks
		cout << "Hello World!";


	cout << endl << "argc = " << argc;
	if (argc > 1) cout << endl << "argv[1] = " << argv[1];
	if (argc > 2) cout << endl << "argv[2] = " << argv[2];

	int* leak = new int;
	return 0;
}