#include <iostream>
#include <vector>
#include <string>
#include <map>
#include <set>
#include <ctime>
using namespace std;
int main() {
	srand(time(NULL));
	map<string, vector<string>> sets;
	string oldString = "a";
	for (int b = 0; b < (100 + rand() % 50); b++) {
		string randString;
		for (int a = 0; a < (4 + (rand() % 4)); a++) {
			char randChar = 'a' + rand() % 26;
			randString += randChar;
		}
		sets[oldString].push_back(randString);
		oldString = randString;
	}
	for (auto i : sets) {
		cout << i.first << ": " << i.second.size() << endl;
	}
	getchar();
	return 0;
}