#ifndef CSG_H
#define CSG_H
#include <string>
using namespace std;

class Csg : public Course
{
private:
	//	string course;
	string studentId;
	string studentGrade;
public:
	Csg() : studentId(""), studentGrade("") { }
	Csg(const string courseName,
		const string studentId,
		const string studentGrade)
	{
		setCourseName(courseName);
		this->studentId = studentId;
		this->studentGrade = studentGrade;
	}

	//	string getCourse() const { return this->course; }
	//	void setCourse(string course) { this->course = course; }

	string getStudentId() const { return this->studentId; }
	void setStudentId(string studentId) { this->studentId = studentId; }

	string getStudentGrade() const { return this->studentGrade; }
	void setStudentGrade(string studentGrade) { this->studentGrade = studentGrade; }

	string toString() const
	{
		stringstream out;
		out << "csg(" << getCourseName();
		out << "," << this->studentId;
		out << "," << this->studentGrade << ")";
		return out.str();
	}

	friend std::ostream& operator<< (ostream& os, const Csg& csg)
	{
		os << csg.toString();
		return os;
	}
};
#endif // CSG_H
