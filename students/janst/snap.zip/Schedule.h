#pragma once
#include <string>
#include <iostream>
#include "Snap.h"
#include "Cdh.h"
#include "Cr.h"
#include <sstream>

class Schedule: public Snap, public Cdh, public Cr
{

public:
	Schedule();

	Schedule(std::string, std::string, std::string, std::string, std::string, std::string, std::string, std::string);

	std::string toString();

	friend std::ostream& operator<< (std::ostream& os, Schedule& myclass)
	{
		os << myclass.toString();
		return os;
	}

};