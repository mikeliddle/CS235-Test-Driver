#include <iostream>
#include <fstream>
#include <string>
#include <iomanip>
#include <cmath>
#include <map>
#include <vector>

#ifdef _MSC_VER
#define _CRTDBG_MAP_ALLOC
#include <crtdbg.h>
#define VS_MEM_CHECK _CrtSetDbgFlag(_CRTDBG_ALLOC_MEM_DF | _CRTDBG_LEAK_CHECK_DF);
#else
#define VS_MEM_CHECK;
#endif

using namespace std;

int numStudents = 0;
int numScores = 0;
int** scores;
string* studentNames;
char** studentLetterGrades;

void readScores(string filename);
void writeTestAverages(ofstream* file);
void writeStudentGrades(ofstream* file);
void cleanUp();

int main(int argc, char* argv[]) {
	VS_MEM_CHECK;
	if (argc != 3) {
		std::cout << "Invalid Arguments" << std::endl;
		return 0;
	}

	try {
		readScores(argv[1]);
	}
	catch (void* error) {
		cout << "File not found." << endl;
		return 0;
	}
	ofstream outFile(argv[2]);
	writeTestAverages(&outFile);
	writeStudentGrades(&outFile);
	outFile.close();
	cout << "File Write Complete." << endl;
	cleanUp();
}


/**
* Read scores and student names from a specified input file and load them into
	dynamically allocated arrays of scores and student names.
**/
void readScores(string filename) {
	ifstream inStream(filename);
	if (!inStream.is_open()) {
		throw("File not found.");
	}
	else {
		inStream >> numStudents >> numScores;

		scores = new int*[numStudents];
		for (int i = 0; i < numStudents; ++i) {
			scores[i] = new int[numScores];
		}
		studentNames = new string[numStudents];
		string data;
		int studentCounter = 0;
		int scoreCounter = 0;
		while (inStream >> data) {
			if (isdigit(data[0])) {
				scores[studentCounter][scoreCounter] = stoi(data);
				scoreCounter++;
			}
			else {
				if (studentNames[studentCounter] == "") {
					studentNames[studentCounter] = data;
				}
				else {
					studentNames[studentCounter] += (" " + data);
				}
			}
			if (scoreCounter == numScores) {
				scoreCounter = 0;
				studentCounter++;
			}

		}
	}
}

/**
* Calculate and write test averages to the specified output stream.
**/
void writeTestAverages(ofstream* file) {
	studentLetterGrades = new char*[numStudents];
	for (int i = 0; i < numStudents; ++i) {
		studentLetterGrades[i] = new char[numScores];
	}
	(*file) << "Exam Averages:" << endl;
	for (int x = 0; x < numScores; x++) {
		double average = 0;
		for (int y = 0; y < numStudents; y++) {
			average += scores[y][x];
		}
		average /= numStudents;

		map<char, int> gradeDistribution;
		char grade = '\0';
		for (int y = 0; y < numStudents; y++) {
			if (abs(average - scores[y][x]) <= 5) {
				grade = 'C';
			}
			else if (scores[y][x] > average) {
				if ((scores[y][x] - average) <= 15) {
					grade = 'B';
				}
				else {
					grade = 'A';
				}
			}
			else {
				if ((average - scores[y][x]) < 15) {
					grade = 'D';
				}
				else {
					grade = 'F';
				}
			}
			gradeDistribution[grade]++;
			studentLetterGrades[y][x] = grade;
		}
		(*file) << std::fixed <<setprecision(1) << setw(5) << "Exam " << x + 1 << " average = " << average << setw(5) << " " << gradeDistribution['A'] << "(A)" <<
			setw(5) << " " << gradeDistribution['B'] << "(B)" << setw(5) << " " << gradeDistribution['C'] << "(C)" << setw(5) << " " << gradeDistribution['D'] << "(D)"
			<< setw(5) << " " << gradeDistribution['F'] << "(F)" << endl;


	}
}

/**
* Write student grades to the specifed output stream.
**/
void writeStudentGrades(ofstream* file) {
	(*file) << endl << "Student Exam Grades:" << endl;
	for (int x = 0; x < numStudents; x++) {
		(*file) << setw(20) << right << studentNames[x] << " ";
		for (int y = 0; y < numScores; y++) {
			(*file) << setw(5) << scores[x][y] << "(" << studentLetterGrades[x][y] << ")";
		}
		(*file) << endl;
	}
}


/*
* Frees the memory allocated for the dynamically-allocated arrays.
*/
void cleanUp() {
	for (int x = 0; x < numStudents; x++) {
		delete[] scores[x];
		delete[] studentLetterGrades[x];
	}
	delete[] scores;
	delete[] studentLetterGrades;
	delete[] studentNames;

}