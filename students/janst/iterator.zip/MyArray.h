#pragma once
#include "stdio.h"
#include "stdlib.h"
#include <ostream>
#include <string>
#include <iostream>
#include <sstream>

template <class T>
class MyArray {
private:
	T* myArray;
	int size;
	int max_size;

public:
	struct Iterator//this class doesn't define STL typedefs to make itself STL compatable
	{
		Iterator(T* array)
		{
			current = array;
			beginning = current;
		}

		~Iterator()
		{
			//TODO:
		}

		T& operator* (/*const int index*/)
		{
			return *current;
			//if (index >= 0 && index < max_size)
			//	return *current[index];
			////throw out of bounds
		}

		const T& operator* (/*const int index*/) const // for const objects (read only)
		{
			return *current;
			//if (index >= 0 && index < max_size)
			//	return *current[index];
			////throw out of bounds
		}

		Iterator& operator++()
		{
			Iterator i = *this;
			current++;
			return i;
		}

		Iterator& operator+(int iterate)
		{
			Iterator i = *this;
			current = &current[iterate];
			return i;
		}

		const bool operator!=(const Iterator& rhs)
		{
			return current != rhs.current;
		}

		T operator[](const int index)//could return T& to give write access
		{
			return beginning[index];
		}

		friend std::ostream& operator<< (std::ostream& os, const Iterator& myclass)
		{
			os << myclass.toString();
			return os;
		}

		std::string toString() const
		{
			std::stringstream ss;
			ss << *current;
			return ss.str();
		}
		
	private: 
		T* current;
		T* beginning;
		//int at;
		
	};

	Iterator begin()//overload to move to next prime ...
	{
		return Iterator(myArray);
	}

	Iterator end()
	{
		return Iterator(&myArray[size]); 
	}

	MyArray() 
	{
		myArray = /*new T[1000];*/(T *)malloc(1000 * sizeof(int));
		size = 0;
		max_size = 1000;
	}

	~MyArray()
	{
		free(myArray);
		myArray = nullptr;
	}

	int getSize()
	{
		return size;
	}

	void push_back(T const& data)
	{
		myArray[size] = data;
		size++;
	}		

	std::string toString() const
	{
		std::stringstream ss;
		for (int i = 0; i < size; i++)
		{
			if (i != 0) {
				if (i % 10 == 0)
				{
					ss << endl;
				}
			}
			ss << myArray[i] << " ";
		}
		return ss.str();
	}

	template<typename T> friend std::ostream& operator<< (std::ostream& os, const MyArray<T>& myclass)
	{
		os << myclass.toString();
		return os;
	}

};