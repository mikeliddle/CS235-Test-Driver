#include "Gradebook.h"
#include <sstream>
#include <iomanip>

const int Gradebook::NUM_LETTER_GRADES = 5;

Gradebook::Gradebook()
{
}

/*
Parametized constructor
*/
Gradebook::Gradebook(std::string* students, int** scores, int numStudents, int numScores) {
	this->students = students;
	this->scores = scores;
	this->numStudents = numStudents;
	this->numScores = numScores;
}


Gradebook::~Gradebook()
{
}


/*
Computes the average score for a given exam
@param examNumber - the specific exam to get the averave score of
@return the average score for an exam
*/
const double Gradebook::calcAverage(int examNumber) const {
	double sum = 0;
	for (int i = 0; i < numStudents; i++) {
		sum += scores[i][examNumber];
	}
	return sum / numStudents;
}

/*
Rounds a double to an int
@param d a double to round
@return an int
*/
const int Gradebook::round(const double d) const {
	return static_cast<int>(d + 0.5);
}

/*
This function converts a score into a letter grade base on the distance from an average score
@param score the score on an exma
@param avg the average score for that exam
@return the letter representing the grade a student received 
*/
const char Gradebook::letterGradeFromScore(double score, double avg) const {
	if (score >= avg + 15) {
		return 'A';
	}
	else if (score < avg + 15 && score > avg + 5) {
		return 'B';
	}
	else if (score <= avg + 5 && score >= avg - 5) {
		return 'C';
	}
	else if (score < avg - 5 && score > avg - 15) {
		return 'D';
	}
	else return 'E';
}

/*
Creates a string with the number and letter component of a grade
@param score the score on an exam
@param letter the letter grade associated with that score
@return a string in the form of <score>(<letter>)
*/
const std::string Gradebook::stringifyGrade(int score, char letter) const {
	std::stringstream ss;
	ss << score << "(" << letter << ")";
	return ss.str();
}

/*
This function returns the grade breakdown for a given exam
@param examNumber the exam to get the breakdown for
@return a string representing the grade breakdown for an exam
*/
const std::string Gradebook::getGradeBreakdownForExam(int examNumber) const {
	std::stringstream ss;
	const int WIDTH = 8;
	int gradeBreakdown[NUM_LETTER_GRADES];
	char letterGrades[NUM_LETTER_GRADES] = { 'A', 'B', 'C', 'D', 'E' };
	double avg = calcAverage(examNumber);

	//initialize array
	for (int i = 0; i < NUM_LETTER_GRADES; i++) {
		gradeBreakdown[i] = 0;
	}

	//calculate the grade breakdown for the exam
	int score;
	char letterGrade;
	for (int i = 0; i < numStudents; i++) {
		score = scores[i][examNumber];
		letterGrade = letterGradeFromScore(score, avg);
		gradeBreakdown[letterGrade - 'A']++;
	}

	//build the result string
	std::string grade;
	for (int i = 0; i < NUM_LETTER_GRADES; i++) {
		grade = stringifyGrade(gradeBreakdown[i], letterGrades[i]);
		ss << std::setw(WIDTH) << grade;
	}

	return ss.str();
}

/*
Returns the gradebreak down for all exams taken by a student
@param studentNumber the student to get the breakdown for
@return a string representing the gradebreakdown
*/
const std::string Gradebook::getGradeBreakdownForStudent(int studentNumber) const {
	std::stringstream ss;
	const int STUDENT_COL = 20, GRADE_COL = 9;
	ss << std::setw(STUDENT_COL) << students[studentNumber];
	int score;
	double avg;
	std::string grade;
	for (int i = 0; i < numScores; i++) {
		score = scores[studentNumber][i];
		avg = calcAverage(i);
		grade = stringifyGrade(score, letterGradeFromScore(score, avg));
		ss << std::setw(GRADE_COL) << grade;
	}

	return ss.str();
}

/*
Calculates the average exam score for the entire class
@return the average exam score
*/
const double Gradebook::calcClassAverage() const {
	double sum = 0;
	for (int i = 0; i < numStudents; i++) {
		for (int j = 0; j < numScores; j++) {
			sum += scores[i][j];
		}
	}
	return sum / (numStudents * numScores);
}

/*
Generates a string representing the students final grade
@param studentNumber the student to get the final grade for
@return a string representing the student's final grade
*/
const std::string Gradebook::getFinalGradeForStudent(int studentNumber) const {
	std::stringstream ss;
	const int STUDENT_COL = 20, GRADE_COL = 9, PREC = 1;
	double sum = 0, final = 0;
	ss << std::setw(STUDENT_COL) << students[studentNumber];
	for (int i = 0; i < numScores; i++) {
		sum += scores[studentNumber][i];
	}
	final = sum / numScores;
	ss << "  " << std::fixed << std::setprecision(1) << final;
	ss << "(" << letterGradeFromScore(final, calcClassAverage()) << ")";

	return ss.str();
}