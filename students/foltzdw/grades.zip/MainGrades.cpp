#include <iostream>
#include <iomanip>
#include <string>
#include <fstream>
#include <limits>


using namespace std;

//leak code here
#ifdef _MSC_VER
#define _CRTDBG_MAP_ALLOC  
#include <crtdbg.h>
#define VS_MEM_CHECK _CrtSetDbgFlag(_CRTDBG_ALLOC_MEM_DF | _CRTDBG_LEAK_CHECK_DF);
#else
#define VS_MEM_CHECK
#endif

//function declarations
string getStudentName(ifstream & theInStream);
void getExamAverages(int ** examGrades, float *theExamAverages, int numExams, int numStudents);
float getStudentAverage(int ** examGrades, int numExams, int whichStudent);
char determineGrade(float gradeToDetermine, float average);
void sorter(ofstream & theOutStream, int ** examGrades, int whichExam, int numStudents, float average);

//global constants
#define C_BOUNDARY 5
#define BD_BOUNDARY 15
#define A_GRADE 'A' 
#define B_GRADE 'B' 
#define C_GRADE 'C'
#define D_GRADE 'D'
#define E_GRADE 'E' 
#define F_GRADE 'F'

//*********************switch to F grade instead of E grade**********************
#define F_NOT_E false      
//********************do bonus code*********************
#define BONUS_GRADES true



int main(int argc, char * argv[])
{
	VS_MEM_CHECK		//check leaks

	//open in and out file streams
	if (argc != 3)
	{
		cerr << "Hey!  I need the input and output files!" << endl;
		return 1;
	}

	cout << "The input file is: " << argv[1] << endl;
	ifstream inny( argv[1] );

	if(!inny)
	{
		cerr << "I can't open this-->" << argv[1] << endl;
		return 1;
	}

	cout << "The output file is: " << argv[2] << endl;
	ofstream outy(argv[2]);

	if(!outy)
	{
		inny.close();
		cerr << "I can't out to this-->" << argv[2] << endl;
		return 1;
	}
    
	//format streams
	cout << fixed;
	outy << fixed;
	cout.precision(1);
	outy.precision(1);
	

	//variable declarations
	int studentCount = 0, examCount = 0;
	float studentAverage = 0;

#if BONUS_GRADES
	float classroomAverage = 0;
#endif

	inny >> studentCount >> examCount;
	inny.ignore(numeric_limits<int>::max(), '\n');  //ignore up to next line

	string *classroomNames = new string[studentCount]; //make names array
	float *theExamAverages = new float[examCount];     //make exam averages array
	int **classroomGrades = new int*[studentCount];    //make the header row of grades as long as student count

	/*
	concept:

	student exam------------->
	   |
	   |   [stu_0][exa_0] [stu_0][exa_1]
	   |   [stu_1][exa_0] [stu_1][exa_1]
	   |
	  \/
	 specify student co-ordinate first
	*/

	for(int stu = 0; stu < studentCount; stu++)
	{
		//use same for_loop for initializing name and grade arrays.

		classroomNames[stu] = getStudentName(inny);   //get the student name

		classroomGrades[stu] = new int[examCount];  //creating row of grades as long as examCount

		for(int exa = 0; exa < examCount; exa++)
		{
			inny >> classroomGrades[stu][exa];
			//cout << classroomGrades[stu][exa] << ", ";
		}
		
		inny.ignore(numeric_limits<int>::max(), '\n');  //ignore up to next line

		//cout << endl;
	}
	
	//done with initialization

	//get exam averages
	outy << "Exam Averages:" << endl;
	cout << "Exam Averages: " << endl;

	getExamAverages(classroomGrades, theExamAverages, examCount, studentCount); //well...*now* get them

	//print and sort
	for(int exa = 0; exa < examCount; exa++)
	{
		outy << "Exam  " << exa + 1 << " average = ";  //the plus one is correct for the 0 index
		cout << "Exam  " << exa + 1 << " average = ";

		outy << theExamAverages[exa];
		cout << theExamAverages[exa];

		//sort, tally and print scores
		sorter(outy, classroomGrades, exa, studentCount, theExamAverages[exa]);		
	}

	cout << endl << "Student Exam Grades: " << endl;
	outy << endl << "Student Exam Grades: " << endl;
	
	//get the grades, and sort them.

	for(int stu = 0; stu < studentCount; stu++)
	{
		cout << setw(25) << classroomNames[stu];
		outy << setw(25) << classroomNames[stu];

		for(int exa = 0; exa < examCount; exa++)
		{
			//typecasting the int at classroomGrades[stu][exa] to a float to avoid compiler warnings
			cout << setw(8) << classroomGrades[stu][exa];
			cout << '(' << determineGrade((float) classroomGrades[stu][exa], theExamAverages[exa]) << ')';

			outy << setw(8) << classroomGrades[stu][exa];
			outy << '(' << determineGrade((float) classroomGrades[stu][exa], theExamAverages[exa]) << ')';
		}
		cout << endl;
		outy << endl;
	}

	cout << endl;
	outy << endl;

	//Bonus Code

	

#if BONUS_GRADES

	cout << "***********B*O*N*U*S*******************" << endl;
	outy << "***********B*O*N*U*S*******************" << endl;

	for(int exa = 0; exa < examCount; exa++)
	{
		classroomAverage += theExamAverages[exa];  //add averages from all exams
	}

	classroomAverage /= examCount;   //divide them to average them
	cout << "Class Average: " << classroomAverage << endl;
	outy << "Class Average: " << classroomAverage << endl;
	cout << "Student Final Exam Grade: " << endl;
	outy << "Student Final Exam Grade: " << endl;

	for(int stu = 0; stu < studentCount; stu++)  //for each student...
	{
		studentAverage = getStudentAverage(classroomGrades, examCount, stu);//average the students scores across all exams taken
	
       //print it
		cout << setw(25) << classroomNames[stu];
		cout << setw(8) << studentAverage << '(' << determineGrade(studentAverage, classroomAverage);
		cout << ')';
		cout << endl;

		outy << setw(25) << classroomNames[stu];
		outy << setw(8) << studentAverage << '(' << determineGrade(studentAverage, classroomAverage);
		outy << ')';
		outy << endl;
	}
	

#endif
	//end bonus code

	//now to put stuff to normal
	cout << "Closing Streams." << endl;
	if(inny.is_open())
		inny.close();

	if(outy.is_open())
		outy.close();

	cout << "Deleting the exam averages." << endl;
	delete[] theExamAverages;

	cout << "Deleting the names." << endl;
	delete [] classroomNames;

	cout << "Deleting grade row: ";
	for(int i = 0; i < studentCount; i++)
	{
		cout << i << ", ";
		//clear the sub-arrays first
		delete [] classroomGrades[i];
	}
	cout << "and header row." << endl;
	delete[] classroomGrades;


	return 0;
}



//takes the address of the stream, and gets the name of the student; allows for the mid-name-space. (:P)
//returns the string of the name

string getStudentName(ifstream & theInStream)
{
	string fullName, lastName;

	theInStream >> fullName;
	fullName += ' ';
	theInStream >> lastName;
	fullName += lastName;
	
	return fullName;
}


//takes the examGrades array, the exam averages array, and number of exams and students
//averages all the results from an exam, stores it in examAverages, and then goes to next exam
//returns void (aka nothing)

void getExamAverages(int ** examGrades, float *theExamAverages, int numExams, int numStudents)
{
	float thisExamAverage = 0;

	for(int exa = 0; exa < numExams; exa++)  //for exam "exa"
	{
		for(int stu = 0; stu < numStudents; stu++) //add all students' results from that exam
		{
			thisExamAverage += examGrades[stu][exa];
		}
		thisExamAverage /= numStudents;  //average it accross the students
		theExamAverages[exa] = thisExamAverage; //store it in the array
		thisExamAverage = 0; //reset the average variable
	}

}


//similar to get Exam average, scans through the array of grades, this time averaging all the scores that "whichStudent" made for all exams.
//returns a float of the average scores for that student.

float getStudentAverage(int ** examGrades, int numExams, int whichStudent)
{
	float average = 0;

	for(int exa= 0; exa < numExams; exa++)
	{
		average += examGrades[whichStudent][exa];
	}
	average /= numExams;

	return average;
}

//determines the letter grade as per a certain score against the average score.
//Be specific about which average you use!
//ALERT!!!***************THERE IS A #DEFINE THAT YOU CAN USE TO CHANGE WHETHER IT USES E OR F AS A GRADE
//returns the letter grade as a character

char determineGrade(float gradeToDetermine, float average)
{

	char finalGrade = 'x';

	if(gradeToDetermine == average)
	{
		finalGrade = C_GRADE;
	}
	else if(gradeToDetermine > average)
	{
		
		if(gradeToDetermine <= average + C_BOUNDARY)
		{
			finalGrade = C_GRADE;
		}
		else if(gradeToDetermine < average + BD_BOUNDARY)
		{
			finalGrade = B_GRADE;
		}
		else
		{
			finalGrade = A_GRADE;
		}
	
	}
	else if(gradeToDetermine < average)
	{
		if(gradeToDetermine > average - C_BOUNDARY)
		{
			finalGrade = C_GRADE;
		}
		else if(gradeToDetermine > average - BD_BOUNDARY)
		{
			finalGrade = D_GRADE;
		}
		else
		{
#if F_NOT_E
			finalGrade = F_GRADE;
#else
			finalGrade = E_GRADE;
#endif
		}

	}

	return finalGrade;
}


//needs the output stream (to print), the exam grades, which exam is being looked at, the number of students, and the average score
//pay attention to which average is used! Normally that would be the average of the class, for that specific "whichExam"
//tallies the lettered scores (uses determineGrade for that) and then prints the results to "theOutStream"
//returns void.

void sorter(ofstream & theOutStream, int ** examGrades, int whichExam, int numStudents, float average)
{
	//string sorted = " ";
	int ATally = 0, BTally = 0, CTally = 0, DTally = 0;
	int ETally = 0, FTally = 0;

	for(int stu = 0; stu < numStudents; stu++)
	{
		//typecasting result at examGrades[stu][whichExam] to avoid compiler warnings
		switch(determineGrade((float) examGrades[stu][whichExam], average))
		{
			case A_GRADE:
				ATally++;
				break;
			case B_GRADE:
				BTally++;
				break;
			case C_GRADE:
				CTally++;
				break;
			case D_GRADE:
				DTally++;
				break;
			case E_GRADE:  //Equipped either way to deal with E or F grade, just change the #define F_NOT_E above
				ETally++;
				break;
			case F_GRADE:
				FTally++;
				break;
			default:
				cerr << "This should be impossible!!" << endl;
				//really, it is.
				break;
		}
	}


	cout << setw(8) << ATally << '(' << A_GRADE << ')';
	cout << setw(8) << BTally << '(' << B_GRADE << ')';
	cout << setw(8) << CTally << '(' << C_GRADE << ')';
	cout << setw(8) << DTally << '(' << D_GRADE << ')';

#if F_NOT_E 
	cout << setw(8) << FTally << '(' << F_GRADE << ')';
#else
	cout << setw(8) << ETally << '(' << E_GRADE << ')';
#endif

	cout << endl;

	theOutStream << setw(8) << ATally << '(' << A_GRADE << ')';
	theOutStream << setw(8) << BTally << '(' << B_GRADE << ')';
	theOutStream << setw(8) << CTally << '(' << C_GRADE << ')';
	theOutStream << setw(8) << DTally << '(' << D_GRADE << ')';

#if F_NOT_E	
	theOutStream << setw(8) << ETally << '(' << F_GRADE << ')';
#else	
	theOutStream << setw(8) << FTally << '(' << E_GRADE << ')';	
#endif
	
	theOutStream << endl;
	//return sorted;
}

