#include <fstream>
#include <string>
#include <map>
#include <iostream>
#include "MyArray.h"

#ifdef _MSC_VER
#define _CRTDBG_MAP_ALLOC  
#include <crtdbg.h>
#define VS_MEM_CHECK _CrtSetDbgFlag(_CRTDBG_ALLOC_MEM_DF | _CRTDBG_LEAK_CHECK_DF);
#else
#define VS_MEM_CHECK;
#endif

using namespace std;

const int MODE_TYPES = 4;
const map<int, string> MODE_CONVERTER = { {0, "SEQUENTIAL"}, {1, "PRIME"}, {2, "COMPOSITE"}, {3, "FIBINOCCI"} };

int main(int argc, char** argv) {
	VS_MEM_CHECK;
	if (argc < 3) {
		cout << "Not enough arguments." << endl;
		return 0;
	}

	string inFileName = argv[1];
	string outFileName = argv[2];
	ifstream inFile(inFileName);
	ofstream outFile(outFileName);

	if (!inFile.is_open() || !outFile.is_open()) {
		cout << "Failed to open one of requested files. Please check directory setup." << endl;
		char c;
		cin >> c;
		return 0;
	}

	MyArray array;

	int number;
	while (inFile >> number) {
		array.push_back(number);
	}

	outFile << "myArray\n" << array;
	
	for (int i = 0; i < MODE_TYPES-1; i++) {
		MyArray::Iterator itr = array.begin();
		outFile << endl << MODE_CONVERTER.at(i) << "\niter" << i+1 << ": " << itr << endl;
		for (; itr != array.end(); ++itr) {
			outFile << *itr << " ";
		}
		outFile << endl;
	}

	MyArray::Iterator itr = array.begin();
	outFile << endl << MODE_CONVERTER.at(MODE_TYPES-1) << "\niter" << MODE_TYPES << ": " << itr << endl;
	for (; itr != array.end(); ++itr) {
		int value = *itr;
		--itr;
		int oneBefore = *itr;
		--itr;
		int twoBefore = *itr;
		while (*itr != value) ++itr;
		outFile << value << "=" << twoBefore << "+" << oneBefore << " ";
	}
	outFile << endl;
	//char c;
	//cin >> c;

	inFile.close();
	outFile.close();
	return 0;
}