#ifndef STUDENTS_H
#define STUDENTS_H

using namespace std;

class Student {
	public:

	private:

};

#endif STUDENTS_H