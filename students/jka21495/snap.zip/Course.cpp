#include "Course.h"

const string DEFAULT_COURSE_NAME = "";

Course::Course()
{
	this->courseName = DEFAULT_COURSE_NAME;
}

Course::Course(string courseName)
{
	this->courseName = courseName;
}

string Course::getCourseName()
{
	return this->courseName;
}

void Course::setCourseName(const string courseName)
{
	this->courseName = courseName;
}


Course::~Course()
{
}

string Course::toString()
{
	return courseName;
}

std::ostream & operator<<(ostream & os, Course & myclass)
{
	os << myclass.toString();
	return os;
}
